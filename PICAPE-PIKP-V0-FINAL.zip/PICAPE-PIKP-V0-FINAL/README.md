# PICAPE — πkp V0

A PICAPE é a bancada/observador. O πkp é o núcleo experimental.

Fluxo observado:

CAMPO DE POSSIBILIDADES → ENCONTRO → SELEÇÃO → TRAJETÓRIA

## Arquitetura

`core/` contém o acontecimento: entidades, relação, campo, decisão, trajetória, evento e observador.

`renderers/` apenas interpreta o mesmo estado. A V0 já possui PICAPE 2D e SVG estrutural; isométrico e 3D são pontos de extensão.

## Controles

Arraste A/B para mudar a relação espacial. PASSO executa uma decisão. RODAR repete. Influência, ruído e horizonte alteram o experimento. O seletor de observador altera a manifestação do campo. EXPORTAR salva o estado/eventos em JSON.

## Abrindo localmente

Por usar ES Modules, alguns navegadores bloqueiam `file://`. Sirva a pasta com qualquer servidor estático; por exemplo:

`python -m http.server 8000`

e abra `http://localhost:8000`.

## Regra

Não colocar a lógica do mundo nos renderers. O mesmo estado deve alimentar PICAPE 2D, SVG, isométrico e 3D.
