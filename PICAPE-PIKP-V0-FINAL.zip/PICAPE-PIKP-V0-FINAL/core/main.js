import {createState,serialize} from './state.js';
import {stepWorld} from './engine.js';
import {relationBetween} from './relation.js';
import {renderPICAPE} from '../renderers/picape2d.js';
import {renderSVG} from '../renderers/svg.js';
import {OBSERVERS} from './observer.js';

const s=createState(),$=id=>document.getElementById(id),stage=$('stage'),svg=$('fieldSvg');
function render(){
 const r=relationBetween(s.entities.A,s.entities.B); s.relation=r.contact?'contato':r.encounter?'encontro':'distante';
 renderPICAPE(svg,s); renderSVG(svg,s);
 $('stepReadout').textContent=`T ${String(s.step).padStart(3,'0')}`;
 $('stateReadout').textContent=s.relation.toUpperCase();
 const sig=new Set(['A','B'].map(id=>s.entities[id].trajectory.map(x=>x.option).join('>')).filter(Boolean)).size;
 $('metrics').textContent=`eventos ${s.events.length} · encontros ${s.events.filter(e=>e.tipo==='encontro_selecao').length} · trajetórias ${sig}`;
 $('eventLog').innerHTML=s.events.slice(-7).reverse().map(e=>`<div>T${String(e.passo).padStart(3,'0')} · ${e.tipo} · A:${e.selecao.A} B:${e.selecao.B} · ${e.relacao}</div>`).join('');
 $('observationText').textContent=OBSERVERS[s.observer].description;
}
[['influence','influenceOut'],['noise','noiseOut'],['horizon','horizonOut']].forEach(([id,out])=>{
 $(id).oninput=e=>{s.config[id]=+e.target.value;$(out).textContent=id==='horizon'?e.target.value:Math.round(+e.target.value*100)+'%';render()}
});
$('stepBtn').onclick=()=>{stepWorld(s);render()};
let timer=null;
$('runBtn').onclick=()=>{s.running=!s.running;$('runBtn').textContent=s.running?'Ⅱ PARAR':'▶ RODAR';
 if(s.running)timer=setInterval(()=>{stepWorld(s);render()},650);else clearInterval(timer)};
$('resetBtn').onclick=()=>{clearInterval(timer);const n=createState();Object.assign(s,n);$('runBtn').textContent='▶ RODAR';render()};
$('exportBtn').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([serialize(s)],{type:'application/json'}));a.download=`pIkp-v0-${String(s.step).padStart(4,'0')}.json`;a.click()};
document.querySelectorAll('.observer-btn').forEach(b=>b.onclick=()=>{document.querySelectorAll('.observer-btn').forEach(x=>x.classList.remove('active'));b.classList.add('active');s.observer=b.dataset.observer;render()});

let drag=null,longPress=null;
function pos(e){const r=stage.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*1000,y:(e.clientY-r.top)/r.height*620}}
stage.onpointerdown=e=>{const p=pos(e);drag=Object.values(s.entities).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];
 if(Math.hypot(drag.x-p.x,drag.y-p.y)>58){drag=null;return} stage.setPointerCapture(e.pointerId);
 longPress=setTimeout(()=>{drag.state='observado';s.selected=drag.id;render()},520)};
stage.onpointermove=e=>{if(!drag)return;clearTimeout(longPress);const p=pos(e);drag.x=Math.max(40,Math.min(960,p.x));drag.y=Math.max(50,Math.min(570,p.y));render()};
stage.onpointerup=()=>{clearTimeout(longPress);drag=null}; stage.onpointercancel=stage.onpointerup; render();