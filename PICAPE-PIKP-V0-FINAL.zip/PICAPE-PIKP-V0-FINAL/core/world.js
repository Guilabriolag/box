export const WORLD={width:1000,height:620,optionRadius:220,encounterRadius:145};
export const OPTIONS=[['O1','A',-Math.PI/2],['O2','B',-Math.PI/4],['O3','C',0],['O4','D',Math.PI/4],['O5','E',Math.PI/2],['O6','F',3*Math.PI/4],['O7','G',Math.PI],['O8','H',-3*Math.PI/4]].map(([id,label,angle])=>({id,label,angle}));
export const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
export const optionPosition=(e,o,r=WORLD.optionRadius)=>({x:e.x+Math.cos(o.angle)*r,y:e.y+Math.sin(o.angle)*r});