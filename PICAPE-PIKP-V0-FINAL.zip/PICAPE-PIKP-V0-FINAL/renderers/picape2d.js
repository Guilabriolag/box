import{OPTIONS,optionPosition}from'../core/world.js';const NS='http://www.w3.org/2000/svg';const E=(t,a={})=>{const n=document.createElementNS(NS,t);for(const[k,v]of Object.entries(a))n.setAttribute(k,v);return n};
export function renderPICAPE(svg,s){while(svg.firstChild)svg.removeChild(svg.firstChild);const A=s.entities.A,B=s.entities.B,d=Math.hypot(A.x-B.x,A.y-B.y),r=Math.max(70,Math.min(260,230-d*.18));
svg.appendChild(E('ellipse',{cx:(A.x+B.x)/2,cy:(A.y+B.y)/2,rx:r*1.45,ry:r*.72,class:'relation-field'}));
for(const e of[A,B])for(const o of OPTIONS){const p=optionPosition(e,o),v=s.fields[e.id]?.find(x=>x.id===o.id);svg.appendChild(E('line',{x1:e.x,y1:e.y,x2:p.x,y2:p.y,class:'possibility-line',opacity:v?.1+v.weight*.48:.045}))}
for(const e of[A,B]){const pts=e.trajectory;if(pts.length)svg.appendChild(E('path',{d:pts.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' '),class:'trajectory'}))}
svg.appendChild(E('line',{x1:A.x,y1:A.y,x2:B.x,y2:B.y,class:'encounter-line'}));
for(const e of[A,B])for(const o of OPTIONS){const p=optionPosition(e,o),v=s.fields[e.id]?.find(x=>x.id===o.id);svg.appendChild(E('circle',{cx:p.x,cy:p.y,r:(v?.weight||0)*8+3,class:'option-node'}))}
for(const e of[A,B]){const o=OPTIONS.find(x=>x.id===e.choice);if(o){const p=optionPosition(e,o);svg.appendChild(E('line',{x1:e.x,y1:e.y,x2:p.x,y2:p.y,class:'selected-line'}))}
svg.appendChild(E('circle',{cx:e.x,cy:e.y,r:32,class:'entity '+e.id}));svg.appendChild(E('circle',{cx:e.x,cy:e.y,r:42,class:'entity-ring'}));const t=E('text',{x:e.x,y:e.y+6,class:'entity-label','text-anchor':'middle'});t.textContent=e.id;svg.appendChild(t)}
const m={x:(A.x+B.x)/2,y:(A.y+B.y)/2};svg.appendChild(E('circle',{cx:m.x,cy:m.y,r:s.relation==='encontro'?18:9,class:'encounter-point'}))}
