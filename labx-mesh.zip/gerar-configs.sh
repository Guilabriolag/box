#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
#  LAB-X MESH — Gerador de wrangler.toml para todos os workers
#  Execute: bash gerar-configs.sh
#  Depois edite o KV_ID em cada arquivo gerado.
# ════════════════════════════════════════════════════════════════

KV_ID="${LABX_KV_ID:-SEU_KV_ID_AQUI}"
ADMIN_SECRET="${LABX_ADMIN_SECRET:-TROQUE-ISSO-EM-PRODUCAO}"
ORIGIN="${ALLOWED_ORIGIN:-https://labriolag.shop}"

# ── GATEWAY ──────────────────────────────────────────────────────
cat > gateway/wrangler.toml <<TOML
name               = "labx-gateway"
main               = "src/index.js"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "LABX_KV"
id      = "${KV_ID}"

[[services]]
binding = "WORKER_AUTH"
service = "labx-w1-auth"

[[services]]
binding = "WORKER_CARDAPIO"
service = "labx-w2-cardapio"

[[services]]
binding = "WORKER_PEDIDOS"
service = "labx-w3-pedidos"

[[services]]
binding = "WORKER_FINANCE"
service = "labx-w4-finance"

[[services]]
binding = "WORKER_INSIGHTS"
service = "labx-w5-insights"

[vars]
ALLOWED_ORIGIN    = "${ORIGIN}"
LABX_ADMIN_SECRET = "${ADMIN_SECRET}"
TOML

# ── w1-auth ───────────────────────────────────────────────────────
cat > w1-auth/wrangler.toml <<TOML
name               = "labx-w1-auth"
main               = "src/index.js"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "LABX_KV"
id      = "${KV_ID}"

[vars]
LABX_ADMIN_SECRET = "${ADMIN_SECRET}"
TOML

# ── w2-cardapio ───────────────────────────────────────────────────
cat > w2-cardapio/wrangler.toml <<TOML
name               = "labx-w2-cardapio"
main               = "src/index.js"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "LABX_KV"
id      = "${KV_ID}"

[vars]
LABX_ADMIN_SECRET = "${ADMIN_SECRET}"
TOML

# ── w3-pedidos ────────────────────────────────────────────────────
cat > w3-pedidos/wrangler.toml <<TOML
name               = "labx-w3-pedidos"
main               = "src/index.js"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "LABX_KV"
id      = "${KV_ID}"

[vars]
LABX_ADMIN_SECRET = "${ADMIN_SECRET}"
TOML

# ── w4-finance ────────────────────────────────────────────────────
cat > w4-finance/wrangler.toml <<TOML
name               = "labx-w4-finance"
main               = "src/index.js"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "LABX_KV"
id      = "${KV_ID}"

[vars]
LABX_ADMIN_SECRET = "${ADMIN_SECRET}"
TOML

# ── w5-insights ───────────────────────────────────────────────────
cat > w5-insights/wrangler.toml <<TOML
name               = "labx-w5-insights"
main               = "src/index.js"
compatibility_date = "2024-01-01"

[[kv_namespaces]]
binding = "LABX_KV"
id      = "${KV_ID}"

[vars]
LABX_ADMIN_SECRET = "${ADMIN_SECRET}"
TOML

echo "✅ Configs gerados. Próximo passo: wrangler deploy em cada pasta."
echo "   Ordem: w1 → w2 → w3 → w4 → w5 → gateway"
