# LAB-X Mesh — Migração do v9 sem downtime

## Estrutura entregue

```
labx-mesh/
├── MIGRACAO.md          ← este arquivo
├── w10-gateway/         ← deploy primeiro
│   ├── index.js
│   └── wrangler.toml
├── w1-auth/             ← identidade, API keys, rate limit
│   ├── index.js
│   └── wrangler.toml
├── w2-cardapio/         ← core do produto (menu + QR)
│   ├── index.js
│   └── wrangler.toml
├── w3-pedidos/          ← motor de retenção (tempo real)
│   ├── index.js
│   └── wrangler.toml
├── w4-finance/          ← economia interna (vouchers)
│   ├── index.js
│   └── wrangler.toml
└── w5-insights/         ← produto premium (16D + BCB + IBGE)
    ├── index.js
    └── wrangler.toml
```

---

## Passo 0 — KV ID (pré-requisito)

Todos os workers (w1–w5) compartilham o **mesmo** KV namespace do v9.
Pegue o ID no seu wrangler atual e substitua em cada `wrangler.toml`:

```toml
[[kv_namespaces]]
binding = "LABX_KV"
id      = "SEU-KV-ID-REAL-AQUI"
```

---

## Passo 1 — Gateway (dia 1)

```bash
cd w10-gateway
wrangler deploy
```

Nesse momento os service bindings (W1_AUTH…W5_INSIGHTS) não existem,
então o gateway devolve 503. Isso é esperado — **o v9 continua no ar**.

Teste: `curl https://labx-w10-gateway.SEU-SUBDOMINIO.workers.dev/health`

---

## Passo 2 — w2 Cardápio (core)

```bash
cd w2-cardapio && wrangler deploy
```

Adicione ao `w10-gateway/wrangler.toml`:
```toml
[[services]]
binding = "W2_CARDAPIO"
service = "labx-w2-cardapio"
```

Redeploy do gateway:
```bash
cd w10-gateway && wrangler deploy
```

Agora `/menu/*` e `/cardapio/*` vão para o w2. Tudo mais continua no v9.

---

## Passo 3 — w1 Auth

```bash
cd w1-auth && wrangler deploy
```

Adicione e redeploy do gateway:
```toml
[[services]]
binding = "W1_AUTH"
service = "labx-w1-auth"
```

`/me`, `/admin/keys*`, `/admin/stats` → w1.

---

## Passo 4 — w3 Pedidos

```bash
cd w3-pedidos && wrangler deploy
```

```toml
[[services]]
binding = "W3_PEDIDOS"
service = "labx-w3-pedidos"
```

`/pedido/enviar`, `/pedidos/*`, `/admin/pedidos` → w3.

---

## Passo 5 — w4 Finance

```bash
cd w4-finance && wrangler deploy
```

```toml
[[services]]
binding = "W4_FINANCE"
service = "labx-w4-finance"
```

`/voucher/*`, `/admin/vouchers*` → w4.

---

## Passo 6 — w5 Insights

```bash
cd w5-insights && wrangler deploy
```

```toml
[[services]]
binding = "W5_INSIGHTS"
service = "labx-w5-insights"
```

`/feed`, `/ibge/*`, `/calcular`, `/salvar`, `/historico`, `/analise/*` → w5.

---

## Passo Final — Migrar rota para o gateway

Com todos os workers no ar e testados, no Cloudflare Dashboard:
- Workers & Pages → seu domínio → mude a rota para apontar pro `labx-w10-gateway`

Os frontends **não mudam nada**. Todas as URLs são idênticas ao v9.

---

## Rollback em qualquer passo

Se algo quebrar, remova o binding do gateway e redeploy:
```toml
# Comente ou remova o [[services]] com problema
```
```bash
wrangler deploy  # gateway volta a retornar 503 para aquela rota
                 # v9 continua servindo via URL direta
```

---

## Tabela de roteamento — Compat v9

| Método | URL                          | Worker       |
|--------|------------------------------|--------------|
| GET    | `/me`                        | w1-auth      |
| *      | `/admin/keys*`               | w1-auth      |
| GET    | `/admin/stats`               | w1-auth      |
| GET    | `/menu/:slug`                | w2-cardapio  |
| POST   | `/cardapio/salvar`           | w2-cardapio  |
| POST   | `/cardapio/ativar-qr`        | w2-cardapio  |
| GET    | `/cardapio/meu`              | w2-cardapio  |
| GET    | `/cardapio/qr-url`           | w2-cardapio  |
| POST   | `/pedido/enviar`             | w3-pedidos   |
| GET    | `/pedidos/feed`              | w3-pedidos   |
| PATCH  | `/pedidos/:id/status`        | w3-pedidos   |
| GET    | `/pedidos/historico`         | w3-pedidos   |
| GET    | `/admin/pedidos`             | w3-pedidos   |
| POST   | `/voucher/resgatar`          | w4-finance   |
| POST   | `/admin/vouchers/gerar`      | w4-finance   |
| GET    | `/admin/vouchers`            | w4-finance   |
| DELETE | `/admin/vouchers/:codigo`    | w4-finance   |
| GET    | `/feed`                      | w5-insights  |
| GET    | `/ibge/:cod`                 | w5-insights  |
| POST   | `/calcular`                  | w5-insights  |
| POST   | `/salvar`                    | w5-insights  |
| GET    | `/historico`                 | w5-insights  |
| *      | `/analise/:id`               | w5-insights  |

## Rotas novas (/api/*) — use nos próximos frontends

| URL nova                      | Worker destino |
|-------------------------------|----------------|
| `GET /api/auth/me`            | w1-auth        |
| `GET /api/cardapio/menu/:slug`| w2-cardapio    |
| `POST /api/cardapio/salvar`   | w2-cardapio    |
| `GET /api/pedidos/feed`       | w3-pedidos     |
| `POST /api/finance/resgatar`  | w4-finance     |
| `GET /api/insights/feed`      | w5-insights    |
| `POST /api/insights/calcular` | w5-insights    |

---

## Variáveis de ambiente obrigatórias

| Worker       | Variável            | Valor                        |
|--------------|---------------------|------------------------------|
| w1–w5        | `LABX_KV` (binding) | ID do KV namespace do v9     |
| w1, w3, w4   | `LABX_ADMIN_SECRET` | Mesmo segredo do v9          |
| w10-gateway  | `ALLOWED_ORIGIN`    | `https://labriolag.shop`     |
| w10-gateway  | `LABX_ADMIN_SECRET` | Mesmo segredo                |
