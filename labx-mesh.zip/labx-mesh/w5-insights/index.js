/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  LAB-X · w5 — INSIGHTS                                          ║
 * ║  Responsabilidade: inteligência econômica — Motor 16D + BCB + IBGE ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 *  KV:
 *    feed:macro:v6           → cache BCB (TTL 4h)
 *    ibge:{cod}              → cache IBGE por município (TTL 24h)
 *    analise:{apiKey}:{id}   → análise salva (TTL 90d)
 *    auth:{apiKey}           → lido/escrito para descontar créditos
 *
 *  Rotas públicas:
 *    GET /health
 *    GET /feed                → dados BCB (SELIC, IPCA, IBC-Br, câmbio)
 *
 *  Rotas autenticadas (X-API-Key):
 *    GET    /ibge/:cod        → dados IBGE do município (7 dígitos)
 *    POST   /calcular         → Motor 16D — consome 1 crédito
 *    POST   /salvar           → salva análise
 *    GET    /historico        → lista análises salvas
 *    GET    /analise/:id      → busca análise por ID
 *    DELETE /analise/:id      → remove análise
 */

const TTL = {
  BCB:     60 * 60 * 4,
  IBGE:    60 * 60 * 24,
  ANALISE: 60 * 60 * 24 * 90,
  PROFILE: 60 * 60 * 24 * 365,
};

const BCB_SERIES = { SELIC: 11, IPCA: 433, IBCBR: 24363, CAMBIO: 1 };
const BOUNDS = {
  SELIC: { min: 2.0,  max: 15.0  },
  IPCA:  { min: 0.0,  max: 1.5   },
  IBCBR: { min: 95.0, max: 145.0 },
};

function ok(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}
function err(msg, status = 400) {
  return new Response(JSON.stringify({ error: msg }), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}

// ── Motor 16D ──────────────────────────────────────────────────────────────
const minmax = (v, min, max) => Math.max(0, Math.min(1, (v - min) / (max - min)));
const clamp  = v => Math.max(0, Math.min(10, v));
const r2     = v => Number(v.toFixed(2));
const avg    = arr => arr.reduce((s, v) => s + v, 0) / arr.length;

function calcularVetores({ renda, cnpjs, populacao, pib, modo = 1.0, bcbData = {}, ibgeData = {} }) {
  const { selic = 10.5, ipca = 0.44, ibcbr = 118 } = bcbData;
  const rN=Math.min(renda/5000,1), dN=Math.min(cnpjs/200,1), pN=Math.min(populacao/500000,1), gN=Math.min(pib/200,1);
  const selicN=minmax(selic,BOUNDS.SELIC.min,BOUNDS.SELIC.max), ipcaN=minmax(ipca,0,1.5), ibcN=minmax(ibcbr,BOUNDS.IBCBR.min,BOUNDS.IBCBR.max);
  const sat=dN>0.7?(dN-0.7)*3:0, liq=(rN+gN)/2, inovFator=ibcN>0.5?1.1:0.9;
  const N=clamp((gN*8+pN*2)*modo), S=clamp((dN*5+(ibgeData.pessoal?Math.min(ibgeData.pessoal/50000,1):dN)*3+rN*2)*modo);
  const L=clamp(((1-sat)*6+liq*3+ibcN*1)*modo), O=clamp((rN*4+gN*4+(1-selicN)*2)*modo);
  const NE=clamp(((N+L)/2*0.9)*modo), SE=clamp((gN*6+ibcN*2+rN*2)*0.9*modo);
  const SO=clamp((sat*4+selicN*4+(1-liq)*2)*0.8*modo), NO=clamp(((N+O)/2*0.9)*modo);
  const NNE=clamp(((NE+N)/2*0.85)*modo), ENE=clamp((liq*6+pN*2+(1-ipcaN)*2)*0.8*modo);
  const ESE=clamp((dN*4+rN*3+ibcN*3)*0.8*modo), SSE=clamp(((ibcN*7+(1-ipcaN)*3)*0.85)*modo);
  const SSO=clamp((selicN*5+sat*3+(1-gN)*2)*0.8*modo), OSO=clamp((sat*8+dN*2)*0.8*modo);
  const ONO=clamp(((NO+NE)/2*inovFator*0.85)*modo), NNO=clamp(((N*0.5+pN*3+ibcN*1.5)*0.8)*modo);
  const v={N:r2(N),S:r2(S),L:r2(L),O:r2(O),NE:r2(NE),SE:r2(SE),SO:r2(SO),NO:r2(NO),NNE:r2(NNE),ENE:r2(ENE),ESE:r2(ESE),SSE:r2(SSE),SSO:r2(SSO),OSO:r2(OSO),ONO:r2(ONO),NNO:r2(NNO)};
  const card=[N,S,L,O], cola=[NE,SE,SO,NO], sub=[NNE,ENE,ESE,SSE,SSO,OSO,ONO,NNO];
  const iac=r2(avg(card)*0.5+avg(cola)*0.3+avg(sub)*0.2);
  const entries=Object.entries(v);
  return {
    vetores: v, iac,
    dom:  [...entries].sort((a,b)=>b[1]-a[1])[0][0],
    neg:  entries.filter(([,x])=>x<4).map(([k])=>k),
    crit: entries.filter(([k,x])=>['N','S','L','O','NE','SE','SO','NO'].includes(k)&&x<5).map(([k])=>k),
    mediaGeral: r2(avg(Object.values(v))),
  };
}

// ── BCB / IBGE ─────────────────────────────────────────────────────────────
async function fetchBCB(serie) {
  const r = await fetch(
    `https://api.bcb.gov.br/dados/serie/bcdata.sgs.${serie}/dados/ultimos/1?formato=json`,
    { cf: { cacheTtl: TTL.BCB, cacheEverything: true } }
  );
  if (!r.ok) throw new Error(`BCB ${serie}: ${r.status}`);
  const d = await r.json();
  return d[d.length - 1];
}

async function fetchIBGEEmpresas(cod) {
  const r = await fetch(
    `https://apisidra.ibge.gov.br/values/t/6321/n6/${cod}/v/allxp/p/last%201/f/u`,
    { cf: { cacheTtl: TTL.IBGE, cacheEverything: true } }
  );
  if (!r.ok) throw new Error(`IBGE Empresas: ${r.status}`);
  const d   = await r.json();
  const row = d.find(x => x.V && x.V !== '-') || d[1];
  return row ? parseInt(row.V.replace(/\./g, ''), 10) || 0 : 0;
}

async function fetchIBGEPessoal(cod) {
  const r = await fetch(
    `https://apisidra.ibge.gov.br/values/t/6579/n6/${cod}/v/allxp/p/last%201/f/u`,
    { cf: { cacheTtl: TTL.IBGE, cacheEverything: true } }
  );
  if (!r.ok) throw new Error(`IBGE Pessoal: ${r.status}`);
  const d   = await r.json();
  const row = d.find(x => x.V && x.V !== '-') || d[1];
  return row ? parseInt(row.V.replace(/\./g, ''), 10) || 0 : 0;
}

async function fetchIBGEPopulacao(cod) {
  const r = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/municipios/${cod}`);
  if (!r.ok) return { nome: 'Município', pop: 50000 };
  const m = await r.json();
  return { nome: m.nome || 'Município', pop: 50000 };
}

async function getProfile(env, apiKey) {
  if (!apiKey?.startsWith('sk_lab_')) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  return raw ? JSON.parse(raw) : null;
}

async function saveProfile(env, apiKey, profile) {
  await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: TTL.PROFILE });
}

// ── Handler ────────────────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p   = url.pathname;
    if (request.method === 'OPTIONS') return new Response(null, { status: 204 });

    if (p === '/health') {
      return ok({ status: 'ok', worker: 'w5-insights', ts: new Date().toISOString() });
    }

    // ════════════════════════════════════════════════════════════════════
    //  PÚBLICA — GET /feed (BCB)
    // ════════════════════════════════════════════════════════════════════
    if (p === '/feed' && request.method === 'GET') {
      try {
        const cached = await env.LABX_KV.get('feed:macro:v6').catch(() => null);
        if (cached) return ok({ ...JSON.parse(cached), cached: true });
        const [s, i, b, c] = await Promise.all([
          fetchBCB(BCB_SERIES.SELIC), fetchBCB(BCB_SERIES.IPCA),
          fetchBCB(BCB_SERIES.IBCBR), fetchBCB(BCB_SERIES.CAMBIO),
        ]);
        const feed = { selic: s, ipca: i, ibcbr: b, cambio: c, capturedAt: new Date().toISOString() };
        await env.LABX_KV.put('feed:macro:v6', JSON.stringify(feed), { expirationTtl: TTL.BCB });
        return ok(feed);
      } catch (e) { return err('BCB indisponível: ' + e.message, 503); }
    }

    // ════════════════════════════════════════════════════════════════════
    //  AUTENTICADAS (X-API-Key)
    // ════════════════════════════════════════════════════════════════════
    const apiKey  = request.headers.get('X-API-Key');
    const profile = await getProfile(env, apiKey);
    if (!profile)        return err('API Key inválida. Obtenha em labriolag.shop', 401);
    if (!profile.active) return err('API Key revogada. Contate a Labriolag Holding.', 403);

    // GET /ibge/:cod
    if (p.startsWith('/ibge/') && request.method === 'GET') {
      const cod = p.replace('/ibge/', '').trim();
      if (!/^\d{7}$/.test(cod)) return err('Código IBGE inválido (7 dígitos)', 400);
      const cached = await env.LABX_KV.get(`ibge:${cod}`).catch(() => null);
      if (cached) return ok({ ...JSON.parse(cached), cached: true });
      try {
        const [empR, pesR, popR] = await Promise.allSettled([
          fetchIBGEEmpresas(cod), fetchIBGEPessoal(cod), fetchIBGEPopulacao(cod),
        ]);
        const data = {
          codMunicipio: cod,
          nome:      popR.status === 'fulfilled' ? popR.value.nome : 'Município',
          populacao: popR.status === 'fulfilled' ? popR.value.pop  : 50000,
          empresas:  empR.status === 'fulfilled' ? empR.value      : null,
          pessoal:   pesR.status === 'fulfilled' ? pesR.value      : null,
          fonte:     'IBGE CEMPRE/SIDRA',
          capturedAt: new Date().toISOString(),
        };
        await env.LABX_KV.put(`ibge:${cod}`, JSON.stringify(data), { expirationTtl: TTL.IBGE });
        return ok(data);
      } catch (e) { return err('IBGE indisponível: ' + e.message, 503); }
    }

    // POST /calcular — Motor 16D (consome 1 crédito)
    if (p === '/calcular' && request.method === 'POST') {
      if ((profile.credits || 0) <= 0) return err('Créditos 16D esgotados.', 402);
      const body = await request.json().catch(() => ({}));
      const { renda = 0, cnpjs = 0, populacao = 50000, pib = 35, modo = 1.0, codMunicipio } = body;

      let bcbData = {}, ibgeData = {};
      const [bcbRes, ibgeRes] = await Promise.allSettled([
        (async () => {
          const c = await env.LABX_KV.get('feed:macro:v6').catch(() => null);
          if (c) { const d = JSON.parse(c); return { selic: +d.selic.valor, ipca: +d.ipca.valor, ibcbr: +d.ibcbr.valor }; }
          const [s, i, b] = await Promise.all([fetchBCB(BCB_SERIES.SELIC), fetchBCB(BCB_SERIES.IPCA), fetchBCB(BCB_SERIES.IBCBR)]);
          return { selic: +s.valor, ipca: +i.valor, ibcbr: +b.valor };
        })(),
        codMunicipio && /^\d{7}$/.test(codMunicipio)
          ? (async () => {
              const c = await env.LABX_KV.get(`ibge:${codMunicipio}`).catch(() => null);
              if (c) return JSON.parse(c);
              const [e, ps] = await Promise.allSettled([fetchIBGEEmpresas(codMunicipio), fetchIBGEPessoal(codMunicipio)]);
              return { empresas: e.status === 'fulfilled' ? e.value : null, pessoal: ps.status === 'fulfilled' ? ps.value : null };
            })()
          : Promise.resolve({}),
      ]);
      if (bcbRes.status  === 'fulfilled') bcbData  = bcbRes.value;
      if (ibgeRes.status === 'fulfilled') ibgeData = ibgeRes.value;

      const resultado = calcularVetores({ renda: Number(renda), cnpjs: Number(cnpjs), populacao: Number(populacao), pib: Number(pib), modo: Number(modo), bcbData, ibgeData });

      profile.credits    = (profile.credits    || 0) - 1;
      profile.usageTotal = (profile.usageTotal || 0) + 1;
      profile.lastUsedAt = new Date().toISOString();
      await saveProfile(env, apiKey, profile);

      return ok({ ...resultado, creditsRestantes: profile.credits });
    }

    // POST /salvar
    if (p === '/salvar' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const id   = body.id || `LAB-${Date.now().toString(36).toUpperCase()}`;
      await env.LABX_KV.put(
        `analise:${apiKey}:${id}`,
        JSON.stringify({ ...body, id, savedAt: new Date().toISOString() }),
        { expirationTtl: TTL.ANALISE }
      );
      return ok({ ok: true, id });
    }

    // GET /historico
    if (p === '/historico' && request.method === 'GET') {
      const list = await env.LABX_KV.list({ prefix: `analise:${apiKey}:` });
      const meta = await Promise.all(list.keys.slice(0, 50).map(async k => {
        const r = await env.LABX_KV.get(k.name).catch(() => null);
        if (!r) return null;
        const d = JSON.parse(r);
        return { id: d.id, name: d.name, timestamp: d.timestamp };
      }));
      return ok({ total: list.keys.length, analyses: meta.filter(Boolean) });
    }

    // GET /analise/:id
    if (p.startsWith('/analise/') && request.method === 'GET') {
      const id  = p.replace('/analise/', '');
      const raw = await env.LABX_KV.get(`analise:${apiKey}:${id}`).catch(() => null);
      if (!raw) return err('Análise não encontrada', 404);
      return ok(JSON.parse(raw));
    }

    // DELETE /analise/:id
    if (p.startsWith('/analise/') && request.method === 'DELETE') {
      await env.LABX_KV.delete(`analise:${apiKey}:${p.replace('/analise/', '')}`);
      return ok({ ok: true });
    }

    return err('Rota não encontrada', 404);
  },
};
