/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  LAB-X · w4 — FINANCE                                           ║
 * ║  Responsabilidade: economia interna — vouchers + créditos QR    ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 *  KV:
 *    voucher:{codigo}      → { valor, status, revendedor, criadoEm }
 *    v_log:{apiKey}:{ts}   → log de resgate (TTL 2 anos)
 *    auth:{apiKey}         → lido/escrito para creditar qrCredits
 *
 *  Rotas autenticadas (X-API-Key):
 *    GET  /health
 *    POST /voucher/resgatar             → lojista resgata → credita qrCredits
 *
 *  Rotas admin (X-Admin-Secret):
 *    POST   /admin/vouchers/gerar       → gera lote de vouchers
 *    GET    /admin/vouchers             → lista vouchers (?status=)
 *    DELETE /admin/vouchers/:codigo     → cancela voucher
 */

const TTL_PROFILE = 60 * 60 * 24 * 365;
const TTL_VOUCHER = 60 * 60 * 24 * 365;
const TTL_V_LOG   = 60 * 60 * 24 * 730;
const QR_PRECO    = 2.50;

function ok(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}
function err(msg, status = 400) {
  return new Response(JSON.stringify({ error: msg }), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}

function gerarCodigo(prefixo = 'LAB', valor = 0) {
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefixo}-${valor}-${rand}`;
}

async function getProfile(env, apiKey) {
  if (!apiKey?.startsWith('sk_lab_')) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  return raw ? JSON.parse(raw) : null;
}

async function saveProfile(env, apiKey, profile) {
  await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: TTL_PROFILE });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p   = url.pathname;
    if (request.method === 'OPTIONS') return new Response(null, { status: 204 });

    if (p === '/health') {
      return ok({ status: 'ok', worker: 'w4-finance', ts: new Date().toISOString() });
    }

    // ════════════════════════════════════════════════════════════════════
    //  ADMIN (X-Admin-Secret)
    // ════════════════════════════════════════════════════════════════════
    const isAdmin = env.LABX_ADMIN_SECRET &&
                    request.headers.get('X-Admin-Secret') === env.LABX_ADMIN_SECRET;

    if (p.startsWith('/admin/vouchers')) {
      if (!isAdmin) return err('Não autorizado', 401);

      // POST /admin/vouchers/gerar
      if (p === '/admin/vouchers/gerar' && request.method === 'POST') {
        const { quantidade = 1, valor = 1, revendedor = 'Holding', observacao = '' } =
          await request.json().catch(() => ({}));
        if (quantidade < 1 || quantidade > 200) return err('quantidade: 1–200', 400);
        if (valor < 1)                          return err('valor mínimo: 1', 400);

        const gerados = [];
        for (let i = 0; i < quantidade; i++) {
          const codigo = gerarCodigo('LAB', valor);
          await env.LABX_KV.put(`voucher:${codigo}`, JSON.stringify({
            valor: parseInt(valor), status: 'disponivel',
            revendedor, observacao, criadoEm: new Date().toISOString(),
          }), { expirationTtl: TTL_VOUCHER });
          gerados.push(codigo);
        }
        return ok({ ok: true, gerados, quantidade, valor, revendedor, valorTotalBRL: (quantidade * valor * QR_PRECO).toFixed(2) }, 201);
      }

      // GET /admin/vouchers?status=disponivel|usado|cancelado
      if (p === '/admin/vouchers' && request.method === 'GET') {
        const filtro  = url.searchParams.get('status') || null;
        const list    = await env.LABX_KV.list({ prefix: 'voucher:' });
        const vouchers = await Promise.all(list.keys.slice(0, 500).map(async k => {
          const raw = await env.LABX_KV.get(k.name).catch(() => null);
          if (!raw) return null;
          return { codigo: k.name.replace('voucher:', ''), ...JSON.parse(raw) };
        }));
        const filtrado = vouchers.filter(v => v && (!filtro || v.status === filtro));
        return ok({ total: filtrado.length, vouchers: filtrado });
      }

      // DELETE /admin/vouchers/:codigo
      if (p.startsWith('/admin/vouchers/LAB-') && request.method === 'DELETE') {
        const codigo = p.replace('/admin/vouchers/', '');
        const raw    = await env.LABX_KV.get(`voucher:${codigo}`).catch(() => null);
        if (!raw) return err('Voucher não encontrado', 404);
        const v = JSON.parse(raw);
        if (v.status === 'usado') return err('Voucher já utilizado, não pode ser cancelado', 400);
        v.status      = 'cancelado';
        v.canceladoEm = new Date().toISOString();
        await env.LABX_KV.put(`voucher:${codigo}`, JSON.stringify(v), { expirationTtl: TTL_VOUCHER });
        return ok({ ok: true, codigo, status: 'cancelado' });
      }

      return err('Rota admin não encontrada', 404);
    }

    // ════════════════════════════════════════════════════════════════════
    //  AUTENTICADAS (X-API-Key)
    // ════════════════════════════════════════════════════════════════════
    const apiKey  = request.headers.get('X-API-Key');
    const profile = await getProfile(env, apiKey);
    if (!profile)        return err('API Key inválida. Obtenha em labriolag.shop', 401);
    if (!profile.active) return err('API Key revogada. Contate a Labriolag Holding.', 403);

    // POST /voucher/resgatar
    if (p === '/voucher/resgatar' && request.method === 'POST') {
      const { codigo } = await request.json().catch(() => ({}));
      if (!codigo) return err('Código do voucher é obrigatório', 400);

      const vKey = `voucher:${codigo.trim().toUpperCase()}`;
      const vRaw = await env.LABX_KV.get(vKey).catch(() => null);
      if (!vRaw) return err('Voucher inválido ou inexistente', 404);

      const voucher = JSON.parse(vRaw);
      if (voucher.status !== 'disponivel') {
        return err(`Voucher ${voucher.status === 'usado' ? 'já utilizado' : 'cancelado'}`, 400);
      }

      const saldoAnterior = profile.qrCredits || 0;
      profile.qrCredits   = saldoAnterior + voucher.valor;
      voucher.status       = 'usado';
      voucher.resgatadoPor = apiKey;
      voucher.resgatadoEm  = new Date().toISOString();

      await Promise.all([
        saveProfile(env, apiKey, profile),
        env.LABX_KV.put(vKey, JSON.stringify(voucher), { expirationTtl: TTL_VOUCHER }),
        env.LABX_KV.put(
          `v_log:${apiKey}:${Date.now()}`,
          JSON.stringify({ codigo, valor: voucher.valor, saldoAnterior, novoSaldo: profile.qrCredits, owner: profile.owner }),
          { expirationTtl: TTL_V_LOG }
        ),
      ]);

      return ok({ ok: true, msg: `+${voucher.valor} créditos adicionados!`, novoSaldo: profile.qrCredits, valorBRL: (voucher.valor * QR_PRECO).toFixed(2) });
    }

    return err('Rota não encontrada', 404);
  },
};
