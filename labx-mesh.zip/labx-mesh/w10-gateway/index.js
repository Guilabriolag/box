/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  LAB-X · w10 — API GATEWAY                                      ║
 * ║  Responsabilidade: roteamento, CORS, health. Zero lógica.       ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 *  Service bindings (wrangler.toml):
 *    W1_AUTH, W2_CARDAPIO, W3_PEDIDOS, W4_FINANCE, W5_INSIGHTS
 *
 *  Rotas novas (/api/*):
 *    /api/auth/*      → W1_AUTH
 *    /api/cardapio/*  → W2_CARDAPIO
 *    /api/pedidos/*   → W3_PEDIDOS
 *    /api/finance/*   → W4_FINANCE
 *    /api/insights/*  → W5_INSIGHTS
 *
 *  Compat v9 (frontends não mudam nada):
 *    /me /admin/keys* /admin/stats  → W1_AUTH
 *    /menu/* /cardapio/*            → W2_CARDAPIO
 *    /pedido/enviar /pedidos/*      → W3_PEDIDOS
 *    /voucher/* /admin/vouchers*    → W4_FINANCE
 *    /feed /ibge/* /calcular …      → W5_INSIGHTS
 */

function cors(env, req) {
  const allowed = env.ALLOWED_ORIGIN || '*';
  const origin  = req.headers.get('Origin') || '';
  const use     = allowed === '*' ? '*' : (origin === allowed ? origin : allowed);
  return {
    'Access-Control-Allow-Origin':  use,
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-API-Key, X-Admin-Secret',
    'Content-Type': 'application/json',
  };
}

// Encaminha para service binding (zero latência — mesma edge).
async function proxy(binding, request, newPath, CH) {
  if (!binding) return new Response(
    JSON.stringify({ error: 'Serviço não configurado — verifique wrangler.toml' }),
    { status: 503, headers: CH }
  );
  const orig = new URL(request.url);
  const dest = new URL(newPath, orig.origin);
  orig.searchParams.forEach((v, k) => dest.searchParams.set(k, v));
  try {
    return await binding.fetch(new Request(dest.toString(), {
      method:  request.method,
      headers: request.headers,
      body:    ['GET', 'HEAD'].includes(request.method) ? undefined : request.body,
    }));
  } catch (e) {
    return new Response(
      JSON.stringify({ error: `Serviço indisponível: ${e.message}` }),
      { status: 503, headers: CH }
    );
  }
}

export default {
  async fetch(request, env) {
    const { pathname: p } = new URL(request.url);
    const CH = cors(env, request);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CH });

    if (p === '/health') return new Response(
      JSON.stringify({ status: 'ok', version: 'w10-gateway', ts: new Date().toISOString() }, null, 2),
      { status: 200, headers: CH }
    );

    // ── /api/* (interface nova — use nos frontends futuros) ────────────
    if (p.startsWith('/api/auth/'))     return proxy(env.W1_AUTH,     request, p.replace('/api/auth', ''),     CH);
    if (p.startsWith('/api/cardapio/')) return proxy(env.W2_CARDAPIO, request, p.replace('/api/cardapio', ''), CH);
    if (p.startsWith('/api/pedidos/'))  return proxy(env.W3_PEDIDOS,  request, p.replace('/api/pedidos', ''),  CH);
    if (p.startsWith('/api/finance/'))  return proxy(env.W4_FINANCE,  request, p.replace('/api/finance', ''),  CH);
    if (p.startsWith('/api/insights/')) return proxy(env.W5_INSIGHTS, request, p.replace('/api/insights', ''), CH);

    // ── Compat v9 (mesmas URLs do v9 — zero mudança nos frontends) ─────
    if (p === '/me')                     return proxy(env.W1_AUTH,     request, '/me',          CH);
    if (p === '/admin/stats')            return proxy(env.W1_AUTH,     request, '/admin/stats', CH);
    if (p.startsWith('/admin/keys'))     return proxy(env.W1_AUTH,     request, p,              CH);
    if (p.startsWith('/menu/'))          return proxy(env.W2_CARDAPIO, request, p,              CH);
    if (p.startsWith('/cardapio/'))      return proxy(env.W2_CARDAPIO, request, p,              CH);
    if (p === '/pedido/enviar')          return proxy(env.W3_PEDIDOS,  request, p,              CH);
    if (p.startsWith('/pedidos/'))       return proxy(env.W3_PEDIDOS,  request, p,              CH);
    if (p === '/admin/pedidos')          return proxy(env.W3_PEDIDOS,  request, p,              CH);
    if (p.startsWith('/voucher/'))       return proxy(env.W4_FINANCE,  request, p,              CH);
    if (p.startsWith('/admin/vouchers')) return proxy(env.W4_FINANCE,  request, p,              CH);
    if (p === '/feed')                   return proxy(env.W5_INSIGHTS, request, p,              CH);
    if (p.startsWith('/ibge/'))          return proxy(env.W5_INSIGHTS, request, p,              CH);
    if (p === '/calcular')               return proxy(env.W5_INSIGHTS, request, p,              CH);
    if (p === '/salvar' || p === '/historico' || p.startsWith('/analise/'))
                                         return proxy(env.W5_INSIGHTS, request, p,              CH);

    return new Response(JSON.stringify({ error: 'Rota não encontrada' }), { status: 404, headers: CH });
  },
};
