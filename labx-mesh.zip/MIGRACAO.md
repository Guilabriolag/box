# LAB-X MESH — Guia de Migração sem Downtime

## Estrutura de pastas

```
labx-mesh/
├── gateway/
│   ├── src/index.js
│   └── wrangler.toml        ← gerado pelo gerar-configs.sh
├── w1-auth/
│   ├── src/index.js
│   └── wrangler.toml
├── w2-cardapio/
│   ├── src/index.js
│   └── wrangler.toml
├── w3-pedidos/
│   ├── src/index.js
│   └── wrangler.toml
├── w4-finance/
│   ├── src/index.js
│   └── wrangler.toml
├── w5-insights/
│   ├── src/index.js
│   └── wrangler.toml
└── gerar-configs.sh
```

---

## Passo 0 — Gerar os wrangler.toml

```bash
cd labx-mesh
LABX_KV_ID="seu_kv_id_real" \
LABX_ADMIN_SECRET="sua_senha_admin" \
ALLOWED_ORIGIN="https://labriolag.shop" \
bash gerar-configs.sh
```

---

## Ordem de deploy (SEM downtime)

### Passo 1 — Deploy dos workers filhos PRIMEIRO

O gateway depende dos workers. Deploy na ordem abaixo:

```bash
cd w1-auth     && npx wrangler deploy && cd ..
cd w2-cardapio && npx wrangler deploy && cd ..
cd w3-pedidos  && npx wrangler deploy && cd ..
cd w4-finance  && npx wrangler deploy && cd ..
cd w5-insights && npx wrangler deploy && cd ..
```

### Passo 2 — Deploy do gateway

```bash
cd gateway && npx wrangler deploy
```

> O v9 continua rodando. O gateway ainda não recebe tráfego.

### Passo 3 — Testar o gateway em paralelo

```bash
# Saúde do gateway e todos os workers
curl https://labx-gateway.SEU_SUBDOMINIO.workers.dev/health

# Teste de autenticação
curl https://labx-gateway.SEU_SUBDOMINIO.workers.dev/me \
  -H "X-API-Key: sk_lab_SUAKEY"

# Cardápio público
curl https://labx-gateway.SEU_SUBDOMINIO.workers.dev/menu/moraes-grill
```

### Passo 4 — Migrar o tráfego dos frontends

Nos arquivos `index.html`, `menu.html` e `admin-cardapio.html`, troque:

```js
// ANTES
const WORKER_URL = 'https://labx-worker-v9.SEU.workers.dev'

// DEPOIS
const WORKER_URL = 'https://labx-gateway.SEU.workers.dev'
```

> As rotas legado (`/me`, `/menu/*`, `/cardapio/*`, etc.) são
> **100% compatíveis** — o gateway as redireciona sem mudar nada.

### Passo 5 — Monitorar 24h

Verifique os logs de cada worker em:
```
Cloudflare Dashboard → Workers & Pages → labx-w1-auth → Logs
```

### Passo 6 — Desligar o v9

Só depois de confirmar que ZERO tráfego ainda vai para o v9:

```bash
# No dashboard ou via CLI:
npx wrangler delete labx-worker-v9
```

---

## KV compartilhado — ponto crítico

Todos os workers usam o **mesmo KV namespace** (`LABX_KV_ID`).

Isso é intencional: as chaves `auth:{apiKey}` são lidas por
w1, w2 (para qrCredits) e w5 (para créditos de análise).

**Não crie KVs separados por worker** ou a auth vai quebrar.

---

## Resumo de responsabilidades

| Worker       | O que faz                              | Admin? |
|--------------|----------------------------------------|--------|
| gateway      | Roteia, nenhuma lógica                 | —      |
| w1-auth      | Perfis, keys, rate limit, resgata voucher | ✅  |
| w2-cardapio  | Cardápio, slug, QR, views             | —      |
| w3-pedidos   | Pedidos ao vivo, feed, status          | ✅     |
| w4-finance   | Gera/lista/cancela vouchers            | ✅     |
| w5-insights  | BCB, IBGE, Motor 16D, análises         | —      |

---

## Variáveis de ambiente necessárias

| Var                | Onde                      |
|--------------------|---------------------------|
| `LABX_KV`          | todos os workers (binding)|
| `LABX_ADMIN_SECRET`| gateway, w1, w3, w4       |
| `ALLOWED_ORIGIN`   | gateway                   |
