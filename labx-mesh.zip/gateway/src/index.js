/**
 * LAB-X GATEWAY — Worker 10
 * Roteia, valida, monitora. NÃO tem lógica de negócio.
 */
function corsHeaders(env, request) {
  const allowed   = env.ALLOWED_ORIGIN || '*';
  const origin    = request.headers.get('Origin') || '';
  const useOrigin = (allowed === '*') ? '*' : (origin === allowed ? origin : allowed);
  return {
    'Access-Control-Allow-Origin':  useOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-API-Key, X-Admin-Secret',
    'Content-Type': 'application/json',
  };
}

function ok(data, status = 200, headers = {})  { return new Response(JSON.stringify(data, null, 2), { status, headers }); }
function err(msg, status = 400, headers = {})  { return new Response(JSON.stringify({ error: msg }), { status, headers }); }

async function proxy(binding, request, overridePath) {
  if (!binding) return new Response(JSON.stringify({ error: 'Serviço não configurado' }), { status: 503, headers: { 'Content-Type': 'application/json' } });
  const original   = new URL(request.url);
  const targetPath = overridePath || original.pathname;
  const targetUrl  = `https://internal${targetPath}${original.search}`;
  const headers    = new Headers(request.headers);
  headers.set('X-Gateway', 'labx-worker-10');
  headers.set('X-Forwarded-For', request.headers.get('CF-Connecting-IP') || '');
  try {
    return await binding.fetch(new Request(targetUrl, {
      method:  request.method,
      headers,
      body: (request.method !== 'GET' && request.method !== 'HEAD') ? request.body : undefined,
    }));
  } catch (e) {
    return new Response(JSON.stringify({ error: `Serviço indisponível: ${e.message}` }), { status: 503, headers: { 'Content-Type': 'application/json' } });
  }
}

async function pingBinding(binding) {
  if (!binding) return 'not-configured';
  try {
    const r = await binding.fetch(new Request('https://internal/health', { method: 'GET' }));
    return r.ok ? 'online' : 'degraded';
  } catch { return 'offline'; }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const CH  = corsHeaders(env, request);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CH });

    // Health
    if (url.pathname === '/health' && request.method === 'GET') {
      const [w1, w2, w3, w4, w5] = await Promise.all([
        pingBinding(env.WORKER_AUTH),
        pingBinding(env.WORKER_CARDAPIO),
        pingBinding(env.WORKER_PEDIDOS),
        pingBinding(env.WORKER_FINANCE),
        pingBinding(env.WORKER_INSIGHTS),
      ]);
      return ok({ status: 'ok', version: 'gateway-10', ts: new Date().toISOString(), workers: { 'w1-auth': w1, 'w2-cardapio': w2, 'w3-pedidos': w3, 'w4-finance': w4, 'w5-insights': w5 } }, 200, CH);
    }

    // Rotas /api/* (novo padrão)
    if (url.pathname.startsWith('/api/auth/'))     return proxy(env.WORKER_AUTH,     request, url.pathname.replace('/api/auth', ''));
    if (url.pathname.startsWith('/api/cardapio/')) return proxy(env.WORKER_CARDAPIO, request, url.pathname.replace('/api/cardapio', ''));
    if (url.pathname.startsWith('/api/pedidos/'))  return proxy(env.WORKER_PEDIDOS,  request, url.pathname.replace('/api/pedidos', ''));
    if (url.pathname.startsWith('/api/finance/'))  return proxy(env.WORKER_FINANCE,  request, url.pathname.replace('/api/finance', ''));
    if (url.pathname.startsWith('/api/insights/')) return proxy(env.WORKER_INSIGHTS, request, url.pathname.replace('/api/insights', ''));

    // Compatibilidade v9 (rotas legado — clientes existentes não quebram)
    if (url.pathname === '/me')                          return proxy(env.WORKER_AUTH,     request, '/me');
    if (url.pathname.startsWith('/menu/'))               return proxy(env.WORKER_CARDAPIO, request);
    if (url.pathname.startsWith('/cardapio/'))           return proxy(env.WORKER_CARDAPIO, request);
    if (url.pathname === '/pedido/enviar')               return proxy(env.WORKER_PEDIDOS,  request, '/pedido/enviar');
    if (url.pathname.startsWith('/pedidos/'))            return proxy(env.WORKER_PEDIDOS,  request);
    if (url.pathname.startsWith('/voucher/'))            return proxy(env.WORKER_AUTH,     request); // resgate fica no w1
    if (url.pathname === '/feed')                        return proxy(env.WORKER_INSIGHTS, request, '/feed');
    if (url.pathname.startsWith('/ibge/'))               return proxy(env.WORKER_INSIGHTS, request);
    if (['/calcular','/salvar','/historico'].includes(url.pathname)) return proxy(env.WORKER_INSIGHTS, request);
    if (url.pathname.startsWith('/analise/'))            return proxy(env.WORKER_INSIGHTS, request);

    // Admin — distribui por sub-rota
    if (url.pathname.startsWith('/admin/')) {
      const adminSecret = request.headers.get('X-Admin-Secret');
      if (!env.LABX_ADMIN_SECRET || adminSecret !== env.LABX_ADMIN_SECRET) return err('Não autorizado', 401, CH);
      if (url.pathname.startsWith('/admin/keys') || url.pathname === '/admin/stats') return proxy(env.WORKER_AUTH,    request);
      if (url.pathname.startsWith('/admin/vouchers'))                                 return proxy(env.WORKER_FINANCE, request);
      if (url.pathname === '/admin/pedidos')                                          return proxy(env.WORKER_PEDIDOS, request);
      return err('Rota admin não encontrada', 404, CH);
    }

    return err('Rota não encontrada. Consulte /health.', 404, CH);
  },
};
