/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  LAB-X · w2 — CARDÁPIO                                          ║
 * ║  Responsabilidade: produto central — cardápio digital + QR      ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 *  KV:
 *    cardapio:{apiKey}       → JSON do cardápio completo
 *    cardapio_slug:{slug}    → apiKey do dono
 *    views:{slug}:{data}     → contador de views diário
 *    qr_log:{apiKey}:{ts}    → log de ativação QR (auditoria)
 *
 *  Rotas públicas:
 *    GET  /health
 *    GET  /menu/:slug              → cardápio público
 *    GET  /menu/:slug?mesa=N       → idem com parâmetro de mesa
 *
 *  Rotas autenticadas (X-API-Key):
 *    POST /cardapio/salvar
 *    POST /cardapio/ativar-qr      → consome 1 qrCredit (R$ 2,50)
 *    GET  /cardapio/meu
 *    GET  /cardapio/qr-url
 */

const TTL_CARDAPIO = 60 * 60 * 24 * 365;
const TTL_V_LOG    = 60 * 60 * 24 * 730;
const QR_PRECO     = 2.50;

function ok(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data, null, 2), {
    status, headers: { 'Content-Type': 'application/json', ...extra },
  });
}
function err(msg, status = 400, extra = {}) {
  return new Response(JSON.stringify({ error: msg }), {
    status, headers: { 'Content-Type': 'application/json', ...extra },
  });
}

function gerarSlug(nome) {
  return nome.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
    .substring(0, 40);
}

async function getProfile(env, apiKey) {
  if (!apiKey?.startsWith('sk_lab_')) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  return raw ? JSON.parse(raw) : null;
}

async function saveProfile(env, apiKey, profile) {
  await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: TTL_CARDAPIO });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const p   = url.pathname;
    if (request.method === 'OPTIONS') return new Response(null, { status: 204 });

    if (p === '/health') {
      return ok({ status: 'ok', worker: 'w2-cardapio', ts: new Date().toISOString() });
    }

    // ════════════════════════════════════════════════════════════════════
    //  PÚBLICAS
    // ════════════════════════════════════════════════════════════════════

    // GET /menu/:slug
    if (p.startsWith('/menu/') && request.method === 'GET') {
      const slug = decodeURIComponent(p.replace('/menu/', '').trim());
      if (!slug) return err('Slug não informado', 400);

      const apiKeyDono = await env.LABX_KV.get(`cardapio_slug:${slug}`).catch(() => null);
      if (!apiKeyDono)  return err('Cardápio não encontrado', 404);

      const raw = await env.LABX_KV.get(`cardapio:${apiKeyDono}`).catch(() => null);
      if (!raw)         return err('Cardápio não encontrado', 404);

      const cardapio = JSON.parse(raw);
      if (!cardapio.qrAtivado) {
        return err('Este cardápio ainda não foi ativado pelo comerciante.', 402, {
          'Cache-Control': 'no-store',
        });
      }

      // Analytics passivo — views diárias (TTL 35 dias)
      const vKey  = `views:${slug}:${new Date().toISOString().slice(0, 10)}`;
      const views = parseInt(await env.LABX_KV.get(vKey).catch(() => '0')) || 0;
      await env.LABX_KV.put(vKey, String(views + 1), { expirationTtl: 60 * 60 * 24 * 35 });

      const { _apiKey, ...publico } = cardapio;
      const mesa = url.searchParams.get('mesa') || url.searchParams.get('comanda') || null;
      return ok({ ...publico, mesa, ts: new Date().toISOString() }, 200, {
        'Cache-Control': 'public, max-age=30',
      });
    }

    // ════════════════════════════════════════════════════════════════════
    //  AUTENTICADAS
    // ════════════════════════════════════════════════════════════════════
    const apiKey = request.headers.get('X-API-Key');
    const profile = await getProfile(env, apiKey);
    if (!profile)        return err('API Key inválida. Obtenha em labriolag.shop', 401);
    if (!profile.active) return err('API Key revogada. Contate a Labriolag Holding.', 403);

    // POST /cardapio/salvar
    if (p === '/cardapio/salvar' && request.method === 'POST') {
      const TIERS = ['basic', 'pro', 'enterprise'];
      if (!TIERS.includes(profile.tier)) return err(`Tier "${profile.tier}" não permite cardápio.`, 403);

      const body = await request.json().catch(() => ({}));
      const {
        nomeLoja, descricao = '', telefone = '', endereco = '', instagram = '',
        corPrimaria = '#ff4040', logo = '', horarios = {}, categorias = [],
        entrega = { ativa: false, taxas: [] }, slug: slugSolicitado,
      } = body;

      if (!nomeLoja) return err('nomeLoja é obrigatório', 400);

      // Preserva dados existentes
      const existenteRaw = await env.LABX_KV.get(`cardapio:${apiKey}`).catch(() => null);
      const existente    = existenteRaw ? JSON.parse(existenteRaw) : null;
      let slug           = slugSolicitado ? gerarSlug(slugSolicitado) : (existente?.slug || gerarSlug(nomeLoja));

      // Resolve conflito de slug
      const slugDono = await env.LABX_KV.get(`cardapio_slug:${slug}`).catch(() => null);
      if (slugDono && slugDono !== apiKey) slug = slug + '-' + Date.now().toString(36).slice(-4);

      const cardapio = {
        nomeLoja, descricao, telefone, endereco, instagram, corPrimaria, logo,
        horarios, categorias, entrega, slug,
        updatedAt:    new Date().toISOString(),
        ownedBy:      profile.owner,
        qrAtivado:    existente?.qrAtivado    || false,
        qrAtivadoEm:  existente?.qrAtivadoEm  || null,
      };

      await Promise.all([
        env.LABX_KV.put(`cardapio:${apiKey}`,       JSON.stringify(cardapio), { expirationTtl: TTL_CARDAPIO }),
        env.LABX_KV.put(`cardapio_slug:${slug}`,    apiKey,                   { expirationTtl: TTL_CARDAPIO }),
      ]);

      const menuUrl = `${new URL(request.url).origin}/menu/${slug}`;
      return ok({ ok: true, slug, menuUrl, updatedAt: cardapio.updatedAt, qrAtivado: cardapio.qrAtivado, qrCredits: profile.qrCredits || 0 });
    }

    // POST /cardapio/ativar-qr — consome 1 qrCredit (R$ 2,50)
    if (p === '/cardapio/ativar-qr' && request.method === 'POST') {
      const TIERS = ['basic', 'pro', 'enterprise'];
      if (!TIERS.includes(profile.tier)) return err(`Tier "${profile.tier}" não permite ativação.`, 403);

      const cardapioRaw = await env.LABX_KV.get(`cardapio:${apiKey}`).catch(() => null);
      if (!cardapioRaw) return err('Salve o cardápio antes de ativar o QR Code.', 400);
      const cardapio = JSON.parse(cardapioRaw);

      // Já ativo — idempotente
      if (cardapio.qrAtivado) {
        const menuUrl = `${new URL(request.url).origin}/menu/${cardapio.slug}`;
        return ok({ ok: true, jaAtivado: true, slug: cardapio.slug, menuUrl, qrCredits: profile.qrCredits || 0, msg: 'QR Code já ativo. Nenhum crédito consumido.' });
      }

      const isEnterprise = profile.tier === 'enterprise';
      const creds        = profile.qrCredits ?? 0;
      if (!isEnterprise && creds < 1) {
        return err(`Saldo de QR insuficiente (${creds}). Cada ativação = R$ ${QR_PRECO}. Adquira créditos em labriolag.shop`, 402);
      }

      if (!isEnterprise) {
        profile.qrCredits = creds - 1;
        profile.qrTotal   = (profile.qrTotal || 0) + 1;
        profile.lastQrAt  = new Date().toISOString();
      }
      cardapio.qrAtivado   = true;
      cardapio.qrAtivadoEm = new Date().toISOString();

      await Promise.all([
        saveProfile(env, apiKey, profile),
        env.LABX_KV.put(`cardapio:${apiKey}`, JSON.stringify(cardapio), { expirationTtl: TTL_CARDAPIO }),
        env.LABX_KV.put(
          `qr_log:${apiKey}:${Date.now()}`,
          JSON.stringify({ slug: cardapio.slug, activatedAt: cardapio.qrAtivadoEm, owner: profile.owner, creditUsed: !isEnterprise }),
          { expirationTtl: TTL_V_LOG }
        ),
      ]);

      const menuUrl = `${new URL(request.url).origin}/menu/${cardapio.slug}`;
      return ok({
        ok: true, slug: cardapio.slug, menuUrl,
        qrCredits:  isEnterprise ? 'ilimitado' : profile.qrCredits,
        creditUsed: !isEnterprise,
        msg: isEnterprise
          ? 'QR Code ativado (Enterprise).'
          : `✅ QR Code ativado! 1 crédito (R$ ${QR_PRECO}) consumido.`,
      });
    }

    // GET /cardapio/meu
    if (p === '/cardapio/meu' && request.method === 'GET') {
      const raw = await env.LABX_KV.get(`cardapio:${apiKey}`).catch(() => null);
      if (!raw) return ok({ existe: false, qrCredits: profile.qrCredits || 0 });
      const cd      = JSON.parse(raw);
      const menuUrl = cd.qrAtivado ? `${new URL(request.url).origin}/menu/${cd.slug}` : null;
      return ok({ existe: true, qrCredits: profile.qrCredits || 0, menuUrl, ...cd });
    }

    // GET /cardapio/qr-url
    if (p === '/cardapio/qr-url' && request.method === 'GET') {
      const raw = await env.LABX_KV.get(`cardapio:${apiKey}`).catch(() => null);
      if (!raw) return err('Nenhum cardápio configurado.', 404);
      const { slug, qrAtivado } = JSON.parse(raw);
      return ok({ slug, menuUrl: `${new URL(request.url).origin}/menu/${slug}`, qrAtivado });
    }

    return err('Rota não encontrada', 404);
  },
};
