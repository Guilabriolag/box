/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  LAB-X · w3 — PEDIDOS                                           ║
 * ║  Responsabilidade: motor de retenção — pedidos em tempo real    ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 *  KV:
 *    pedidos:{apiKey}:{ts}   → pedido individual (TTL 7d)
 *    cardapio:{apiKey}       → lido para validar slug e pegar telefone
 *    cardapio_slug:{slug}    → lido para resolver slug → apiKey
 *
 *  Rotas públicas:
 *    GET  /health
 *    POST /pedido/enviar           → cliente envia pedido
 *
 *  Rotas autenticadas (X-API-Key):
 *    GET   /pedidos/feed           → últimos 20 (polling 2–5s)
 *    PATCH /pedidos/:id/status     → novo→preparando→pronto→entregue
 *    GET   /pedidos/historico      → todos últimos 7d
 *
 *  Rota admin (X-Admin-Secret):
 *    GET   /admin/pedidos          → todos pedidos do sistema (24h)
 */

const TTL_PEDIDO = 60 * 60 * 24 * 7;

function ok(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}
function err(msg, status = 400) {
  return new Response(JSON.stringify({ error: msg }), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}

async function getProfile(env, apiKey) {
  if (!apiKey?.startsWith('sk_lab_')) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  return raw ? JSON.parse(raw) : null;
}

export default {
  async fetch(request, env) {
    const { pathname: p } = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204 });

    if (p === '/health') {
      return ok({ status: 'ok', worker: 'w3-pedidos', ts: new Date().toISOString() });
    }

    // ════════════════════════════════════════════════════════════════════
    //  ADMIN
    // ════════════════════════════════════════════════════════════════════
    if (p === '/admin/pedidos' && request.method === 'GET') {
      const isAdmin = env.LABX_ADMIN_SECRET &&
                      request.headers.get('X-Admin-Secret') === env.LABX_ADMIN_SECRET;
      if (!isAdmin) return err('Não autorizado', 401);

      const list   = await env.LABX_KV.list({ prefix: 'pedidos:' });
      const cutoff = Date.now() - 24 * 60 * 60 * 1000;
      const pedidos = await Promise.all(list.keys.map(async k => {
        const raw = await env.LABX_KV.get(k.name).catch(() => null);
        if (!raw) return null;
        const ped = JSON.parse(raw);
        return new Date(ped.criadoEm).getTime() > cutoff ? ped : null;
      }));
      const filtrados = pedidos.filter(Boolean).sort((a, b) => new Date(b.criadoEm) - new Date(a.criadoEm));
      return ok({ total: filtrados.length, pedidos: filtrados });
    }

    // ════════════════════════════════════════════════════════════════════
    //  PÚBLICA — POST /pedido/enviar
    // ════════════════════════════════════════════════════════════════════
    if (p === '/pedido/enviar' && request.method === 'POST') {
      const body = await request.json().catch(() => null);
      if (!body) return err('Payload inválido', 400);

      const { slug, itens, identificacao, mesa, total, obs } = body;
      if (!slug)                  return err('slug obrigatório', 400);
      if (!itens?.length)         return err('Carrinho vazio', 400);
      if (!identificacao?.trim()) return err('Informe nome ou número da mesa', 400);

      const donoKey     = await env.LABX_KV.get(`cardapio_slug:${slug}`).catch(() => null);
      if (!donoKey)      return err('Loja não encontrada', 404);
      const cardapioRaw = await env.LABX_KV.get(`cardapio:${donoKey}`).catch(() => null);
      if (!cardapioRaw)  return err('Cardápio não encontrado', 404);
      const cardapio    = JSON.parse(cardapioRaw);
      if (!cardapio.qrAtivado) return err('Esta loja ainda não ativou o sistema de pedidos.', 403);

      const pedidoId = `PED-${Date.now().toString(36).toUpperCase()}`;
      const pedido   = {
        id: pedidoId, slug,
        nomeLoja:      cardapio.nomeLoja,
        identificacao: identificacao.trim(),
        mesa:          mesa || identificacao.trim(),
        itens,
        total,
        obs:      obs?.trim() || '',
        status:   'novo',
        criadoEm: new Date().toISOString(),
      };

      await env.LABX_KV.put(
        `pedidos:${donoKey}:${Date.now()}`,
        JSON.stringify(pedido),
        { expirationTtl: TTL_PEDIDO }
      );

      return ok({ ok: true, pedidoId, telefone: cardapio.telefone || '', nomeLoja: cardapio.nomeLoja }, 201);
    }

    // ════════════════════════════════════════════════════════════════════
    //  AUTENTICADAS
    // ════════════════════════════════════════════════════════════════════
    const apiKey = request.headers.get('X-API-Key');
    const profile = await getProfile(env, apiKey);
    if (!profile)        return err('API Key inválida. Obtenha em labriolag.shop', 401);
    if (!profile.active) return err('API Key revogada. Contate a Labriolag Holding.', 403);

    // GET /pedidos/feed — últimos 20 (polling ao vivo)
    if (p === '/pedidos/feed' && request.method === 'GET') {
      const list = await env.LABX_KV.list({ prefix: `pedidos:${apiKey}:` });
      const pedidos = await Promise.all(
        list.keys.slice(-20).reverse().map(async k => {
          const raw = await env.LABX_KV.get(k.name).catch(() => null);
          return raw ? JSON.parse(raw) : null;
        })
      );
      return ok({ pedidos: pedidos.filter(Boolean) });
    }

    // PATCH /pedidos/:id/status
    if (p.startsWith('/pedidos/') && p.endsWith('/status') && request.method === 'PATCH') {
      const pedidoId = p.replace('/pedidos/', '').replace('/status', '');
      const { status } = await request.json().catch(() => ({}));
      const VALIDOS = ['novo', 'preparando', 'pronto', 'entregue', 'cancelado'];
      if (!VALIDOS.includes(status)) return err(`Status inválido. Use: ${VALIDOS.join(', ')}`, 400);

      const list = await env.LABX_KV.list({ prefix: `pedidos:${apiKey}:` });
      for (const k of list.keys) {
        const raw = await env.LABX_KV.get(k.name).catch(() => null);
        if (!raw) continue;
        const ped = JSON.parse(raw);
        if (ped.id === pedidoId) {
          ped.status             = status;
          ped.statusAtualizadoEm = new Date().toISOString();
          await env.LABX_KV.put(k.name, JSON.stringify(ped), { expirationTtl: TTL_PEDIDO });
          return ok({ ok: true, id: pedidoId, status });
        }
      }
      return err('Pedido não encontrado', 404);
    }

    // GET /pedidos/historico — todos últimos 7d
    if (p === '/pedidos/historico' && request.method === 'GET') {
      const list = await env.LABX_KV.list({ prefix: `pedidos:${apiKey}:` });
      const pedidos = await Promise.all(list.keys.map(async k => {
        const raw = await env.LABX_KV.get(k.name).catch(() => null);
        return raw ? JSON.parse(raw) : null;
      }));
      const sorted = pedidos.filter(Boolean).sort((a, b) => new Date(b.criadoEm) - new Date(a.criadoEm));
      return ok({ total: sorted.length, pedidos: sorted });
    }

    return err('Rota não encontrada', 404);
  },
};
