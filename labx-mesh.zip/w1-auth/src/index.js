/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  LAB-X · w1 — AUTH                                              ║
 * ║  Responsabilidade: identidade, API Keys, rate limit, admin      ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 *  KV:
 *    auth:{apiKey}     → perfil do lojista
 *    rate:{key}:{min}  → rate limiting (TTL 60s)
 *    keys:idx:{ts}     → índice de chaves (admin)
 *
 *  Rotas:
 *    GET  /health
 *    GET  /me                      ← autenticado (X-API-Key)
 *    POST /admin/keys              ← admin (X-Admin-Secret)
 *    GET  /admin/keys              ← admin
 *    PATCH  /admin/keys/:key       ← admin
 *    DELETE /admin/keys/:key       ← admin
 *    GET  /admin/stats             ← admin
 */

const TTL_PROFILE = 60 * 60 * 24 * 365;
const TTL_RATE    = 60;
const QR_PRECO    = 2.50;

function ok(data, status = 200) {
  return new Response(JSON.stringify(data, null, 2), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}
function err(msg, status = 400) {
  return new Response(JSON.stringify({ error: msg }), {
    status, headers: { 'Content-Type': 'application/json' },
  });
}

async function getProfile(env, apiKey) {
  if (!apiKey?.startsWith('sk_lab_')) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  return raw ? JSON.parse(raw) : null;
}

async function saveProfile(env, apiKey, profile) {
  await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: TTL_PROFILE });
}

async function checkRateLimit(env, apiKey) {
  const key   = `rate:${apiKey}:${Math.floor(Date.now() / 60000)}`;
  const count = parseInt(await env.LABX_KV.get(key).catch(() => '0')) || 0;
  if (count >= 30) return false;
  await env.LABX_KV.put(key, String(count + 1), { expirationTtl: TTL_RATE });
  return true;
}

export default {
  async fetch(request, env) {
    const { pathname: p } = new URL(request.url);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204 });

    if (p === '/health') {
      return ok({ status: 'ok', worker: 'w1-auth', ts: new Date().toISOString() });
    }

    // ════════════════════════════════════════════════════════════════════
    //  ADMIN
    // ════════════════════════════════════════════════════════════════════
    const isAdmin = env.LABX_ADMIN_SECRET &&
                    request.headers.get('X-Admin-Secret') === env.LABX_ADMIN_SECRET;

    if (p.startsWith('/admin/')) {
      if (!isAdmin) return err('Não autorizado', 401);

      // POST /admin/keys
      if (p === '/admin/keys' && request.method === 'POST') {
        const { owner = 'Anônimo', tier = 'starter', credits = 0, qrCredits = 0 } =
          await request.json().catch(() => ({}));

        const key     = `sk_lab_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
        const profile = { owner, tier, credits, qrCredits, active: true, createdAt: new Date().toISOString(), usageTotal: 0, qrTotal: 0 };
        await env.LABX_KV.put(`auth:${key}`, JSON.stringify(profile), { expirationTtl: TTL_PROFILE });
        await env.LABX_KV.put(`keys:idx:${Date.now()}`, key, { expirationTtl: TTL_PROFILE });
        return ok({ ok: true, key, profile }, 201);
      }

      // GET /admin/keys
      if (p === '/admin/keys' && request.method === 'GET') {
        const list = await env.LABX_KV.list({ prefix: 'keys:idx:' });
        const keys = await Promise.all(list.keys.map(async k => {
          const apiKey = await env.LABX_KV.get(k.name).catch(() => null);
          if (!apiKey) return null;
          const raw    = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
          return raw ? { key: apiKey, ...JSON.parse(raw) } : null;
        }));
        return ok({ keys: keys.filter(Boolean) });
      }

      // PATCH /admin/keys/:key
      if (p.startsWith('/admin/keys/sk_lab_') && request.method === 'PATCH') {
        const key  = p.replace('/admin/keys/', '');
        const raw  = await env.LABX_KV.get(`auth:${key}`).catch(() => null);
        if (!raw) return err('Chave não encontrada', 404);
        const profile = JSON.parse(raw);
        const body    = await request.json().catch(() => ({}));
        if (body.credits   !== undefined) profile.credits   = (profile.credits   || 0) + body.credits;
        if (body.qrCredits !== undefined) profile.qrCredits = (profile.qrCredits || 0) + body.qrCredits;
        if (body.tier      !== undefined) profile.tier      = body.tier;
        if (body.active    !== undefined) profile.active    = body.active;
        await saveProfile(env, key, profile);
        return ok({ ok: true, profile });
      }

      // DELETE /admin/keys/:key
      if (p.startsWith('/admin/keys/sk_lab_') && request.method === 'DELETE') {
        const key  = p.replace('/admin/keys/', '');
        const raw  = await env.LABX_KV.get(`auth:${key}`).catch(() => null);
        if (!raw) return err('Chave não encontrada', 404);
        const profile  = JSON.parse(raw);
        profile.active = false;
        await saveProfile(env, key, profile);
        return ok({ ok: true, revoked: key });
      }

      // GET /admin/stats
      if (p === '/admin/stats' && request.method === 'GET') {
        const list = await env.LABX_KV.list({ prefix: 'keys:idx:' });
        let totalKeys = 0, activeKeys = 0, totalQR = 0, totalQRCredits = 0, cardapios = 0, pedidosTotal = 0;
        await Promise.all(list.keys.map(async k => {
          const apiKey = await env.LABX_KV.get(k.name).catch(() => null); if (!apiKey) return;
          const raw    = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null); if (!raw) return;
          const prof   = JSON.parse(raw);
          totalKeys++; if (prof.active) activeKeys++;
          totalQR += prof.qrTotal || 0; totalQRCredits += prof.qrCredits || 0;
          const c = await env.LABX_KV.get(`cardapio:${apiKey}`).catch(() => null);
          if (c) cardapios++;
          const pl = await env.LABX_KV.list({ prefix: `pedidos:${apiKey}:` });
          pedidosTotal += pl.keys.length;
        }));
        return ok({ totalKeys, activeKeys, cardapios, totalQRAtivados: totalQR, totalQRCreditsEmCirculacao: totalQRCredits, receitaBRL: (totalQR * QR_PRECO).toFixed(2), pedidosTotal, ts: new Date().toISOString() });
      }

      return err('Rota admin não encontrada', 404);
    }

    // ════════════════════════════════════════════════════════════════════
    //  AUTENTICADAS
    // ════════════════════════════════════════════════════════════════════
    const apiKey = request.headers.get('X-API-Key');
    const profile = await getProfile(env, apiKey);
    if (!profile)        return err('API Key inválida. Obtenha em labriolag.shop', 401);
    if (!profile.active) return err('API Key revogada. Contate a Labriolag Holding.', 403);
    if (!await checkRateLimit(env, apiKey)) return err('Rate limit: 30 req/min por chave.', 429);

    // GET /me
    if (p === '/me') {
      const cardapioRaw = await env.LABX_KV.get(`cardapio:${apiKey}`).catch(() => null);
      let slugAtual = null, qrAtivado = false;
      if (cardapioRaw) { const cd = JSON.parse(cardapioRaw); slugAtual = cd.slug || null; qrAtivado = cd.qrAtivado || false; }
      return ok({
        owner: profile.owner, tier: profile.tier,
        credits: profile.credits || 0,
        qrCredits: profile.tier === 'enterprise' ? 'ilimitado' : (profile.qrCredits || 0),
        qrTotal: profile.qrTotal || 0, usageTotal: profile.usageTotal || 0,
        active: profile.active, temCardapio: !!cardapioRaw, slugAtual, qrAtivado, precoPorQR: QR_PRECO,
      });
    }

    return err('Rota não encontrada', 404);
  },
};
