/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  LAB-X w5 — INSIGHTS SERVICE                                        ║
 * ║  Responsabilidade: Motor 16D, BCB, IBGE, análises                   ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * PÚBLICAS:
 *   GET /health
 *   GET /feed          → dados macro BCB (Selic, IPCA, IBCBR, Câmbio)
 *
 * AUTENTICADAS (X-API-Key):
 *   GET  /ibge/:cod    → dados IBGE por município (7 dígitos)
 *   POST /calcular     → Motor 16D (consome 1 crédito)
 *   POST /salvar       → salva análise no KV
 *   GET  /historico    → lista análises salvas
 *   GET  /analise/:id  → recupera análise por id
 *   DELETE /analise/:id
 *
 * KV:
 *   feed:macro:v6         → cache BCB (4h)
 *   ibge:{cod}            → cache IBGE (24h)
 *   analise:{apiKey}:{id} → análise salva (TTL 90d)
 *   auth:{apiKey}         → perfil (lido e escrito para débito de crédito)
 */

// ─── CONSTANTES ────────────────────────────────────────────────────────────
const TTL = {
  BCB:     60 * 60 * 4,
  IBGE:    60 * 60 * 24,
  ANALISE: 60 * 60 * 24 * 90,
  AUTH:    60 * 60 * 24 * 365,
};

const BCB_SERIES = { SELIC: 11, IPCA: 433, IBCBR: 24363, CAMBIO: 1 };
const BOUNDS = {
  SELIC: { min: 2.0,  max: 15.0  },
  IPCA:  { min: 0.0,  max: 1.5   },
  IBCBR: { min: 95.0, max: 145.0 },
};

// ─── HELPERS GERAIS ─────────────────────────────────────────────────────────
function ok(data, status = 200)  { return new Response(JSON.stringify(data, null, 2), { status, headers: { 'Content-Type': 'application/json' } }); }
function err(msg, status = 400)  { return new Response(JSON.stringify({ error: msg }), { status, headers: { 'Content-Type': 'application/json' } }); }

const minmax = (v, min, max) => Math.max(0, Math.min(1, (v - min) / (max - min)));
const clamp  = v => Math.max(0, Math.min(10, v));
const r2     = v => Number(v.toFixed(2));
const avg    = arr => arr.reduce((s, v) => s + v, 0) / arr.length;

// ─── AUTH ───────────────────────────────────────────────────────────────────
async function getProfile(env, apiKey) {
  if (!apiKey || !apiKey.startsWith('sk_lab_')) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  return raw ? JSON.parse(raw) : null;
}
async function saveProfile(env, apiKey, profile) {
  await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: TTL.AUTH });
}

// ─── BCB ────────────────────────────────────────────────────────────────────
async function fetchBCB(serie) {
  const url = `https://api.bcb.gov.br/dados/serie/bcdata.sgs.${serie}/dados/ultimos/1?formato=json`;
  const r   = await fetch(url, { cf: { cacheTtl: TTL.BCB, cacheEverything: true } });
  if (!r.ok) throw new Error(`BCB ${serie}: ${r.status}`);
  const d = await r.json();
  return d[d.length - 1];
}

// ─── IBGE ───────────────────────────────────────────────────────────────────
async function fetchIBGEEmpresas(cod) {
  const url = `https://apisidra.ibge.gov.br/values/t/6321/n6/${cod}/v/allxp/p/last%201/f/u`;
  const r   = await fetch(url, { cf: { cacheTtl: TTL.IBGE, cacheEverything: true } });
  if (!r.ok) throw new Error(`IBGE Empresas: ${r.status}`);
  const d   = await r.json();
  const row = d.find(x => x.V && x.V !== '-') || d[1];
  return row ? parseInt(row.V.replace(/\./g, ''), 10) || 0 : 0;
}

async function fetchIBGEPessoal(cod) {
  const url = `https://apisidra.ibge.gov.br/values/t/6579/n6/${cod}/v/allxp/p/last%201/f/u`;
  const r   = await fetch(url, { cf: { cacheTtl: TTL.IBGE, cacheEverything: true } });
  if (!r.ok) throw new Error(`IBGE Pessoal: ${r.status}`);
  const d   = await r.json();
  const row = d.find(x => x.V && x.V !== '-') || d[1];
  return row ? parseInt(row.V.replace(/\./g, ''), 10) || 0 : 0;
}

async function fetchIBGEPopulacao(cod) {
  const r = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/municipios/${cod}`);
  if (!r.ok) return { nome: 'Município', pop: 50000 };
  const m = await r.json();
  return { nome: m.nome || 'Município', pop: 50000 };
}

// ─── MOTOR 16D ──────────────────────────────────────────────────────────────
function calcularVetores({ renda, cnpjs, populacao, pib, modo = 1.0, bcbData = {}, ibgeData = {} }) {
  const { selic = 10.5, ipca = 0.44, ibcbr = 118 } = bcbData;

  const rN = Math.min(renda / 5000, 1);
  const dN = Math.min(cnpjs / 200, 1);
  const pN = Math.min(populacao / 500000, 1);
  const gN = Math.min(pib / 200, 1);

  const selicN  = minmax(selic, BOUNDS.SELIC.min, BOUNDS.SELIC.max);
  const ipcaN   = minmax(ipca,  0, 1.5);
  const ibcN    = minmax(ibcbr, BOUNDS.IBCBR.min, BOUNDS.IBCBR.max);

  const sat       = dN > 0.7 ? (dN - 0.7) * 3 : 0;
  const liq       = (rN + gN) / 2;
  const inovFator = ibcN > 0.5 ? 1.1 : 0.9;

  const N  = clamp((gN * 8 + pN * 2) * modo);
  const S  = clamp((dN * 5 + (ibgeData.pessoal ? Math.min(ibgeData.pessoal / 50000, 1) : dN) * 3 + rN * 2) * modo);
  const L  = clamp(((1 - sat) * 6 + liq * 3 + ibcN * 1) * modo);
  const O  = clamp((rN * 4 + gN * 4 + (1 - selicN) * 2) * modo);
  const NE = clamp(((N + L) / 2 * 0.9) * modo);
  const SE = clamp((gN * 6 + ibcN * 2 + rN * 2) * 0.9 * modo);
  const SO = clamp((sat * 4 + selicN * 4 + (1 - liq) * 2) * 0.8 * modo);
  const NO = clamp(((N + O) / 2 * 0.9) * modo);

  const NNE = clamp(((NE + N) / 2 * 0.85) * modo);
  const ENE = clamp((liq * 6 + pN * 2 + (1 - ipcaN) * 2) * 0.8 * modo);
  const ESE = clamp((dN * 4 + rN * 3 + ibcN * 3) * 0.8 * modo);
  const SSE = clamp(((ibcN * 7 + (1 - ipcaN) * 3) * 0.85) * modo);
  const SSO = clamp((selicN * 5 + sat * 3 + (1 - gN) * 2) * 0.8 * modo);
  const OSO = clamp((sat * 8 + dN * 2) * 0.8 * modo);
  const ONO = clamp(((NO + NE) / 2 * inovFator * 0.85) * modo);
  const NNO = clamp(((N * 0.5 + pN * 3 + ibcN * 1.5) * 0.8) * modo);

  const v = {
    N: r2(N), S: r2(S), L: r2(L), O: r2(O),
    NE: r2(NE), SE: r2(SE), SO: r2(SO), NO: r2(NO),
    NNE: r2(NNE), ENE: r2(ENE), ESE: r2(ESE), SSE: r2(SSE),
    SSO: r2(SSO), OSO: r2(OSO), ONO: r2(ONO), NNO: r2(NNO),
  };

  const card    = [N, S, L, O];
  const cola    = [NE, SE, SO, NO];
  const sub     = [NNE, ENE, ESE, SSE, SSO, OSO, ONO, NNO];
  const iac     = r2(avg(card) * 0.5 + avg(cola) * 0.3 + avg(sub) * 0.2);
  const entries = Object.entries(v);

  return {
    vetores:     v,
    iac,
    dom:         [...entries].sort((a, b) => b[1] - a[1])[0][0],
    neg:         entries.filter(([, x]) => x < 4).map(([k]) => k),
    crit:        entries.filter(([k, x]) => ['N', 'S', 'L', 'O', 'NE', 'SE', 'SO', 'NO'].includes(k) && x < 5).map(([k]) => k),
    mediaGeral:  r2(avg(Object.values(v))),
  };
}

// ─── HANDLER PRINCIPAL ─────────────────────────────────────────────────────
export default {
  async fetch(request, env) {
    const url    = new URL(request.url);
    const method = request.method;

    // ── Health ──────────────────────────────────────────────────────────────
    if (url.pathname === '/health') {
      return ok({ status: 'ok', service: 'w5-insights', ts: new Date().toISOString() });
    }

    // ── GET /feed — PÚBLICO ──────────────────────────────────────────────────
    if (url.pathname === '/feed' && method === 'GET') {
      try {
        const cached = await env.LABX_KV.get('feed:macro:v6').catch(() => null);
        if (cached) return ok({ ...JSON.parse(cached), cached: true });

        const [s, i, b, c] = await Promise.all([
          fetchBCB(BCB_SERIES.SELIC),
          fetchBCB(BCB_SERIES.IPCA),
          fetchBCB(BCB_SERIES.IBCBR),
          fetchBCB(BCB_SERIES.CAMBIO),
        ]);
        const feed = { selic: s, ipca: i, ibcbr: b, cambio: c, capturedAt: new Date().toISOString() };
        await env.LABX_KV.put('feed:macro:v6', JSON.stringify(feed), { expirationTtl: TTL.BCB });
        return ok(feed);
      } catch (e) {
        return err('BCB indisponível: ' + e.message, 503);
      }
    }

    // ── AUTENTICAÇÃO ────────────────────────────────────────────────────────
    const apiKey = request.headers.get('X-API-Key');
    const profile = await getProfile(env, apiKey);
    if (!profile)        return err('API Key inválida.', 401);
    if (!profile.active) return err('API Key revogada.', 403);

    // ── GET /ibge/:cod ───────────────────────────────────────────────────────
    if (url.pathname.startsWith('/ibge/') && method === 'GET') {
      const cod = url.pathname.replace('/ibge/', '').trim();
      if (!/^\d{7}$/.test(cod)) return err('Código IBGE inválido (7 dígitos)', 400);

      const cached = await env.LABX_KV.get(`ibge:${cod}`).catch(() => null);
      if (cached) return ok({ ...JSON.parse(cached), cached: true });

      try {
        const [empR, pesR, popR] = await Promise.allSettled([
          fetchIBGEEmpresas(cod),
          fetchIBGEPessoal(cod),
          fetchIBGEPopulacao(cod),
        ]);
        const data = {
          codMunicipio: cod,
          nome:         popR.status === 'fulfilled' ? popR.value.nome : 'Município',
          populacao:    popR.status === 'fulfilled' ? popR.value.pop  : 50000,
          empresas:     empR.status === 'fulfilled' ? empR.value : null,
          pessoal:      pesR.status === 'fulfilled' ? pesR.value : null,
          fonte:        'IBGE CEMPRE/SIDRA',
          capturedAt:   new Date().toISOString(),
        };
        await env.LABX_KV.put(`ibge:${cod}`, JSON.stringify(data), { expirationTtl: TTL.IBGE });
        return ok(data);
      } catch (e) {
        return err('IBGE indisponível: ' + e.message, 503);
      }
    }

    // ── POST /calcular — Motor 16D (consome 1 crédito) ───────────────────────
    if (url.pathname === '/calcular' && method === 'POST') {
      if ((profile.credits || 0) <= 0) return err('Créditos 16D esgotados.', 402);

      const body = await request.json().catch(() => ({}));
      const { renda = 0, cnpjs = 0, populacao = 50000, pib = 35, modo = 1.0, codMunicipio } = body;

      let bcbData = {}, ibgeData = {};
      const [bcbRes, ibgeRes] = await Promise.allSettled([
        (async () => {
          const c = await env.LABX_KV.get('feed:macro:v6').catch(() => null);
          if (c) { const d = JSON.parse(c); return { selic: +d.selic.valor, ipca: +d.ipca.valor, ibcbr: +d.ibcbr.valor }; }
          const [s, i, b] = await Promise.all([fetchBCB(BCB_SERIES.SELIC), fetchBCB(BCB_SERIES.IPCA), fetchBCB(BCB_SERIES.IBCBR)]);
          return { selic: +s.valor, ipca: +i.valor, ibcbr: +b.valor };
        })(),
        codMunicipio && /^\d{7}$/.test(codMunicipio)
          ? (async () => {
              const c = await env.LABX_KV.get(`ibge:${codMunicipio}`).catch(() => null);
              if (c) return JSON.parse(c);
              const [e, p] = await Promise.allSettled([fetchIBGEEmpresas(codMunicipio), fetchIBGEPessoal(codMunicipio)]);
              return { empresas: e.status === 'fulfilled' ? e.value : null, pessoal: p.status === 'fulfilled' ? p.value : null };
            })()
          : Promise.resolve({}),
      ]);

      if (bcbRes.status  === 'fulfilled') bcbData  = bcbRes.value;
      if (ibgeRes.status === 'fulfilled') ibgeData = ibgeRes.value;

      const resultado = calcularVetores({ renda: Number(renda), cnpjs: Number(cnpjs), populacao: Number(populacao), pib: Number(pib), modo: Number(modo), bcbData, ibgeData });

      profile.credits    = (profile.credits    || 0) - 1;
      profile.usageTotal = (profile.usageTotal || 0) + 1;
      profile.lastUsedAt = new Date().toISOString();
      await saveProfile(env, apiKey, profile);

      resultado.creditsRestantes = profile.credits;
      return ok(resultado);
    }

    // ── POST /salvar ─────────────────────────────────────────────────────────
    if (url.pathname === '/salvar' && method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const id   = body.id || `LAB-${Date.now().toString(36).toUpperCase()}`;
      await env.LABX_KV.put(
        `analise:${apiKey}:${id}`,
        JSON.stringify({ ...body, id, savedAt: new Date().toISOString() }),
        { expirationTtl: TTL.ANALISE }
      );
      return ok({ ok: true, id });
    }

    // ── GET /historico ───────────────────────────────────────────────────────
    if (url.pathname === '/historico' && method === 'GET') {
      const list = await env.LABX_KV.list({ prefix: `analise:${apiKey}:` });
      const meta = await Promise.all(
        list.keys.slice(0, 50).map(async k => {
          const r = await env.LABX_KV.get(k.name).catch(() => null);
          if (!r) return null;
          const d = JSON.parse(r);
          return { id: d.id, name: d.name, timestamp: d.timestamp };
        })
      );
      return ok({ total: list.keys.length, analyses: meta.filter(Boolean) });
    }

    // ── GET /analise/:id ─────────────────────────────────────────────────────
    if (url.pathname.startsWith('/analise/') && method === 'GET') {
      const id  = url.pathname.replace('/analise/', '');
      const raw = await env.LABX_KV.get(`analise:${apiKey}:${id}`).catch(() => null);
      if (!raw) return err('Análise não encontrada', 404);
      return ok(JSON.parse(raw));
    }

    // ── DELETE /analise/:id ──────────────────────────────────────────────────
    if (url.pathname.startsWith('/analise/') && method === 'DELETE') {
      await env.LABX_KV.delete(`analise:${apiKey}:${url.pathname.replace('/analise/', '')}`);
      return ok({ ok: true });
    }

    return err('Rota não encontrada', 404);
  },
};
