/**
 * LAB-X w4 — FINANCE SERVICE
 * Responsabilidade: Vouchers — geração, listagem, cancelamento
 */
const TTL_VOUCHER  = 60 * 60 * 24 * 365;
const QR_PRECO_BRL = 2.50;

function ok(data, status = 200)  { return new Response(JSON.stringify(data, null, 2), { status, headers: { 'Content-Type': 'application/json' } }); }
function err(msg, status = 400)  { return new Response(JSON.stringify({ error: msg }), { status, headers: { 'Content-Type': 'application/json' } }); }

function gerarCodigo(prefixo = 'LAB', valor = 0) {
  const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefixo}-${valor}-${rand}`;
}

export default {
  async fetch(request, env) {
    const url    = new URL(request.url);
    const method = request.method;

    if (url.pathname === '/health') return ok({ status: 'ok', service: 'w4-finance', ts: new Date().toISOString() });

    // Todas as rotas são admin-only
    const adminSecret = request.headers.get('X-Admin-Secret');
    if (!env.LABX_ADMIN_SECRET || adminSecret !== env.LABX_ADMIN_SECRET) return err('Não autorizado', 401);

    // POST /admin/vouchers/gerar
    if (url.pathname === '/admin/vouchers/gerar' && method === 'POST') {
      const { quantidade = 1, valor = 1, revendedor = 'Holding', observacao = '' } = await request.json().catch(() => ({}));
      if (quantidade < 1 || quantidade > 200) return err('quantidade: 1–200', 400);
      if (valor < 1) return err('valor mínimo: 1', 400);
      const gerados = [];
      for (let i = 0; i < quantidade; i++) {
        const codigo = gerarCodigo('LAB', valor);
        await env.LABX_KV.put(`voucher:${codigo}`, JSON.stringify({ valor: parseInt(valor), status: 'disponivel', revendedor, observacao, criadoEm: new Date().toISOString() }), { expirationTtl: TTL_VOUCHER });
        gerados.push(codigo);
      }
      return ok({ ok: true, gerados, quantidade, valor, revendedor, valorTotalBRL: (quantidade * valor * QR_PRECO_BRL).toFixed(2) }, 201);
    }

    // GET /admin/vouchers?status=
    if (url.pathname === '/admin/vouchers' && method === 'GET') {
      const filtro   = url.searchParams.get('status') || null;
      const list     = await env.LABX_KV.list({ prefix: 'voucher:' });
      const vouchers = await Promise.all(list.keys.slice(0, 500).map(async k => {
        const raw = await env.LABX_KV.get(k.name).catch(() => null);
        if (!raw) return null;
        return { codigo: k.name.replace('voucher:', ''), ...JSON.parse(raw) };
      }));
      const filtrado = vouchers.filter(v => v && (!filtro || v.status === filtro));
      return ok({ total: filtrado.length, vouchers: filtrado });
    }

    // DELETE /admin/vouchers/:codigo
    if (url.pathname.startsWith('/admin/vouchers/LAB-') && method === 'DELETE') {
      const codigo = url.pathname.replace('/admin/vouchers/', '');
      const raw    = await env.LABX_KV.get(`voucher:${codigo}`).catch(() => null);
      if (!raw) return err('Voucher não encontrado', 404);
      const v = JSON.parse(raw);
      if (v.status === 'usado') return err('Voucher já utilizado, não pode ser cancelado', 400);
      v.status = 'cancelado'; v.canceladoEm = new Date().toISOString();
      await env.LABX_KV.put(`voucher:${codigo}`, JSON.stringify(v), { expirationTtl: TTL_VOUCHER });
      return ok({ ok: true, codigo, status: 'cancelado' });
    }

    return err('Rota não encontrada', 404);
  },
};
