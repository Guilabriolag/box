# Territory Editor v2 — Phase 1 + Phase 2 Foundation

Mobile-first evolution of `territory-editor-modular-v1`.

## Phase 1
- Touch-first interaction foundation
- Large touch targets
- Select / move / transform foundation
- Mobile responsive layout
- Existing editor modules preserved

## Phase 2 foundation
- 2D / Isometric / 3D viewport tabs
- Shared-world architecture hook
- Viewport change events
- Pinch gesture event
- Touch drag/tap events

## Important
This package is intentionally a foundation, not a claim that the full isometric/3D engines are already complete.
The existing editor remains the starting point. The next implementation step is to connect each viewport to the same world state and add real transform handles.
