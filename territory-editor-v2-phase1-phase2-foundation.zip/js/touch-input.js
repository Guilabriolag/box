
/*
 * Territory Editor — mobile touch foundation
 * Phase 1: touch-first editing
 * Phase 2: viewport/preview foundation
 */
(() => {
  "use strict";

  const state = {
    activeViewport: "2d",
    selectedId: null,
    gesture: null,
    pinch: null,
    touchMode: "select"
  };

  const qs = (s, root=document) => root.querySelector(s);

  function setViewport(name) {
    state.activeViewport = name;
    document.querySelectorAll("[data-viewport]").forEach(btn => {
      btn.classList.toggle("is-active", btn.dataset.viewport === name);
    });
    document.querySelectorAll(".viewport-panel").forEach(panel => {
      panel.classList.toggle("is-active", panel.dataset.viewport === name);
    });
    document.dispatchEvent(new CustomEvent("territory:viewportchange", {
      detail: { viewport: name }
    }));
  }

  function bindViewportTabs() {
    document.querySelectorAll("[data-viewport]").forEach(btn => {
      btn.addEventListener("click", () => setViewport(btn.dataset.viewport));
      btn.addEventListener("touchend", e => {
        e.preventDefault();
        setViewport(btn.dataset.viewport);
      }, { passive: false });
    });
  }

  function distance(a, b) {
    return Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
  }

  function pointFromTouch(t) {
    return { x: t.clientX, y: t.clientY };
  }

  function bindTouchCanvas() {
    const surface = qs("[data-touch-surface]");
    if (!surface) return;

    surface.style.touchAction = "none";

    surface.addEventListener("touchstart", e => {
      if (!e.touches.length) return;
      if (e.touches.length === 2) {
        state.pinch = {
          startDistance: distance(e.touches[0], e.touches[1]),
          currentDistance: distance(e.touches[0], e.touches[1])
        };
        state.gesture = "pinch";
        return;
      }
      const p = pointFromTouch(e.touches[0]);
      state.gesture = "tap";
      state.touchStart = p;
      state.touchLast = p;
    }, { passive: false });

    surface.addEventListener("touchmove", e => {
      e.preventDefault();
      if (e.touches.length === 2 && state.pinch) {
        state.pinch.currentDistance = distance(e.touches[0], e.touches[1]);
        const scale = state.pinch.currentDistance / state.pinch.startDistance;
        document.dispatchEvent(new CustomEvent("territory:pinch", {
          detail: { scale }
        }));
        return;
      }
      if (e.touches.length !== 1 || !state.touchLast) return;
      const p = pointFromTouch(e.touches[0]);
      const dx = p.x - state.touchLast.x;
      const dy = p.y - state.touchLast.y;
      if (Math.abs(p.x - state.touchStart.x) + Math.abs(p.y - state.touchStart.y) > 8) {
        state.gesture = "drag";
      }
      state.touchLast = p;
      document.dispatchEvent(new CustomEvent("territory:touchdrag", {
        detail: { dx, dy, x: p.x, y: p.y }
      }));
    }, { passive: false });

    surface.addEventListener("touchend", e => {
      if (state.gesture === "tap" && state.touchStart) {
        document.dispatchEvent(new CustomEvent("territory:touchtap", {
          detail: state.touchStart
        }));
      }
      state.gesture = null;
      state.touchStart = null;
      state.touchLast = null;
      state.pinch = null;
    }, { passive: false });
  }

  function bindTouchTools() {
    document.querySelectorAll("[data-touch-tool]").forEach(btn => {
      btn.addEventListener("click", () => {
        state.touchMode = btn.dataset.touchTool;
        document.querySelectorAll("[data-touch-tool]").forEach(b =>
          b.classList.toggle("is-active", b === btn)
        );
      });
    });
  }

  window.TerritoryTouch = { state, setViewport };
  document.addEventListener("DOMContentLoaded", () => {
    bindViewportTabs();
    bindTouchCanvas();
    bindTouchTools();
    setViewport("2d");
  });
})();
