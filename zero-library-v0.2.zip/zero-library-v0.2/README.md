# Biblioteca Zero v0.2

## Fundamentais
core / state / interaction / events / provenance / space

## Extensões reservadas
entities / structures / objects / vehicles / time / environment / representation / resources / physics

## Futuras
 economy / communication / automation

`zero-library.json` é o índice. Os JSON individuais são definições semânticas reutilizáveis.
