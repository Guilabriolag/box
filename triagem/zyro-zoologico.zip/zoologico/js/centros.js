// ============================================================
// ZYRO — CENTROS.JS
// Pontos fixos dentro do bioma da Cria: centro de alimentação,
// centro de entretenimento, centro médico e centro de registro.
// Cada um é um marcador físico no mundo (não um botão de HUD solto)
// — o player anda até lá e interage, igual aos estandes do zoológico.
// Acopla em cima do que já existe em bioma.js/entities.js, sem
// mexer no loop delas.
// ============================================================

(() => {
  "use strict";

  const CENTROS = [
    {
      id: "alimentacao", nome: "Centro de Alimentação", icon: "🍎",
      pos: { x: 6, z: -4 }, cor: 0xff9f5a,
      desc: "Interagir para alimentar sua Cria",
      onInteract() { window.ZYRO_BIOMA?.feed(); }
    },
    {
      id: "entretenimento", nome: "Centro de Entretenimento", icon: "🎾",
      pos: { x: 0, z: -9 }, cor: 0x7fd8ff,
      desc: "Interagir para brincar com sua Cria",
      onInteract() { window.ZYRO_BIOMA?.play(); }
    },
    {
      id: "medico", nome: "Centro Médico", icon: "⚕️",
      pos: { x: -9, z: 5 }, cor: 0xff6f6f,
      desc: "Interagir para cuidar da saúde da sua Cria",
      onInteract() { window.ZYRO_BIOMA?.heal(); }
    },
    {
      id: "registro", nome: "Centro de Registro", icon: "🗂️",
      pos: { x: 9, z: 5 }, cor: 0xffd76b,
      desc: "Interagir para ver a ficha da sua Cria",
      onInteract() { window.ZYRO_BIOMA?.toggleFicha(); }
    },
  ];

  const INTERACT_RADIUS = 3.0;
  let placed = false;

  function iconSprite(icon) {
    const canvas = document.createElement("canvas");
    canvas.width = 128; canvas.height = 128;
    const ctx = canvas.getContext("2d");
    ctx.font = "84px sans-serif";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.fillText(icon, 64, 70);
    const tex = new THREE.CanvasTexture(canvas);
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true }));
    sprite.scale.set(1.1, 1.1, 1.1);
    return sprite;
  }

  function buildMarker(c) {
    const g = new THREE.Group();
    const base = new THREE.Mesh(
      new THREE.CylinderGeometry(0.9, 0.95, 0.18, 16),
      new THREE.MeshStandardMaterial({ color: c.cor, roughness: 0.5, metalness: 0.15 })
    );
    base.position.y = 0.09;
    g.add(base);
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.06, 0.06, 1.5, 8),
      new THREE.MeshStandardMaterial({ color: 0x333333 })
    );
    pole.position.y = 0.85;
    g.add(pole);
    const sprite = iconSprite(c.icon);
    sprite.position.y = 1.75;
    g.add(sprite);
    g.position.set(c.pos.x, 0, c.pos.z);
    g.userData.phase = Math.random() * Math.PI * 2;
    return g;
  }

  function tryPlace() {
    if (placed) return;
    const group = window.ZYRO_BIOMA?.getGroup?.();
    if (!group) return;
    CENTROS.forEach(c => {
      c.mesh = buildMarker(c);
      group.add(c.mesh);
    });
    placed = true;
  }

  function loop() {
    requestAnimationFrame(loop);

    const ZYRO = window.ZYRO;
    const BIOMA = window.ZYRO_BIOMA;
    if (!ZYRO || !ZYRO.player || !BIOMA || !BIOMA.isActive()) return;

    tryPlace();
    if (!placed) return;

    const t = performance.now() / 1000;
    CENTROS.forEach(c => {
      if (c.mesh) c.mesh.position.y = Math.sin(t * 1.4 + c.mesh.userData.phase) * 0.05;
    });

    const player = ZYRO.player;
    let nearest = null, nearestDist = Infinity;
    CENTROS.forEach(c => {
      const d = Math.hypot(player.x - c.pos.x, player.z - c.pos.z);
      if (d < INTERACT_RADIUS && d < nearestDist) { nearest = c; nearestDist = d; }
    });

    const titleEl = document.getElementById("interaction-title");
    const descEl = document.getElementById("interaction-description");

    if (nearest) {
      if (titleEl) titleEl.textContent = nearest.nome;
      if (descEl) descEl.textContent = nearest.desc;
      if (ZYRO.input.action) {
        nearest.onInteract();
        ZYRO.input.action = false;
      }
    } else {
      if (titleEl) titleEl.textContent = "Nada por perto";
      if (descEl) descEl.textContent = "Explore o bioma";
    }
  }

  requestAnimationFrame(loop);

  window.ZYRO_CENTROS = { list: CENTROS };

})();
