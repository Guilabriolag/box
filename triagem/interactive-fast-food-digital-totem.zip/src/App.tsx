import { useState, useEffect, useCallback, useRef } from 'react';
import RestaurantScene from './components/RestaurantScene';
import TotemMenu from './components/TotemMenu';
import Joystick from './components/Joystick';

interface NPC {
  x: number;
  y: number;
  color: string;
  direction: number;
  type: string;
  speed: number;
  minX: number;
  maxX: number;
  targetX: number;
  pauseTimer: number;
}

interface Car {
  x: number;
  color: string;
  speed: number;
}

interface Motorcycle {
  x: number;
  y: number;
  speed: number;
  direction: number;
}

// NPC colors defined inline in initial state

function App() {
  const [isNight, setIsNight] = useState(true);
  const [playerPos, setPlayerPos] = useState({ x: 600, y: 470 });
  const [totemOpen, setTotemOpen] = useState(false);
  const [totemGlow, setTotemGlow] = useState(false);
  const [showInstructions, setShowInstructions] = useState(true);
  const [gameStarted, setGameStarted] = useState(false);

  const [npcs, setNpcs] = useState<NPC[]>([
    { x: 350, y: 475, color: '#e74c3c', direction: 1, type: 'customer', speed: 0.5, minX: 200, maxX: 800, targetX: 500, pauseTimer: 0 },
    { x: 700, y: 478, color: '#2ecc71', direction: -1, type: 'customer', speed: 0.4, minX: 250, maxX: 850, targetX: 400, pauseTimer: 0 },
    { x: 500, y: 472, color: '#9b59b6', direction: 1, type: 'worker', speed: 0.3, minX: 300, maxX: 750, targetX: 600, pauseTimer: 0 },
    { x: 250, y: 480, color: '#e67e22', direction: 1, type: 'customer', speed: 0.6, minX: 150, maxX: 900, targetX: 700, pauseTimer: 0 },
    { x: 820, y: 476, color: '#1abc9c', direction: -1, type: 'customer', speed: 0.35, minX: 200, maxX: 870, targetX: 300, pauseTimer: 0 },
  ]);

  const [cars, setCars] = useState<Car[]>([
    { x: 1000, color: '#c0392b', speed: 0.8 },
    { x: 1150, color: '#2c3e50', speed: 0.6 },
  ]);

  const [motorcycle, setMotorcycle] = useState<Motorcycle>({ x: 50, y: 555, speed: 1.5, direction: 1 });

  const keysRef = useRef<Set<string>>(new Set());
  const animFrameRef = useRef<number>(0);
  const totemGlowRef = useRef(totemGlow);
  totemGlowRef.current = totemGlow;

  const handleInteract = useCallback(() => {
    if (totemGlowRef.current) {
      setTotemOpen(true);
    }
  }, []);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current.add(e.key.toLowerCase());
      if (e.key.toLowerCase() === 'e') {
        handleInteract();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current.delete(e.key.toLowerCase());
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleInteract]);

  // Check totem proximity
  useEffect(() => {
    const totemX = 170;
    const totemY = 420;
    const dist = Math.sqrt(Math.pow(playerPos.x - totemX, 2) + Math.pow(playerPos.y - totemY, 2));
    setTotemGlow(dist < 60);
  }, [playerPos]);

  const movePlayer = useCallback((dx: number, dy: number) => {
    setPlayerPos(prev => ({
      x: Math.max(30, Math.min(1170, prev.x + dx)),
      y: Math.max(400, Math.min(580, prev.y + dy))
    }));
  }, []);

  // Game loop
  useEffect(() => {
    let lastTime = performance.now();
    
    const gameLoop = (time: number) => {
      const delta = Math.min(time - lastTime, 50);
      lastTime = time;
      const dt = delta / 16;

      // Keyboard movement
      const keys = keysRef.current;
      const speed = 2.5 * dt;
      if (keys.has('arrowleft') || keys.has('a')) movePlayer(-speed, 0);
      if (keys.has('arrowright') || keys.has('d')) movePlayer(speed, 0);
      if (keys.has('arrowup') || keys.has('w')) movePlayer(0, -speed * 0.6);
      if (keys.has('arrowdown') || keys.has('s')) movePlayer(0, speed * 0.6);

      // Update NPCs
      setNpcs(prev => prev.map(npc => {
        let { x, direction, targetX, pauseTimer } = npc;
        
        if (pauseTimer > 0) {
          return { ...npc, pauseTimer: pauseTimer - dt };
        }

        const distToTarget = Math.abs(x - targetX);
        if (distToTarget < 5) {
          // Pick new target
          targetX = npc.minX + Math.random() * (npc.maxX - npc.minX);
          pauseTimer = 60 + Math.random() * 120; // Pause
          direction = targetX > x ? 1 : -1;
          return { ...npc, targetX, pauseTimer, direction };
        }

        direction = targetX > x ? 1 : -1;
        x += direction * npc.speed * dt;
        
        return { ...npc, x, direction, targetX, pauseTimer };
      }));

      // Update cars (drive-thru loop)
      setCars(prev => prev.map(car => {
        let x = car.x - car.speed * dt;
        if (x < -80) x = 1250 + Math.random() * 200;
        return { ...car, x };
      }));

      // Update motorcycle
      setMotorcycle(prev => {
        let { x, direction, speed } = prev;
        x += direction * speed * dt;
        if (x > 1250) {
          direction = -1;
          x = 1250;
        }
        if (x < -50) {
          direction = 1;
          x = -50;
        }
        return { ...prev, x, direction };
      });

      animFrameRef.current = requestAnimationFrame(gameLoop);
    };

    animFrameRef.current = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [movePlayer]);

  // Auto hide instructions
  useEffect(() => {
    const t = setTimeout(() => setShowInstructions(false), 8000);
    return () => clearTimeout(t);
  }, []);

  if (!gameStarted) {
    return (
      <div className="w-screen h-screen overflow-hidden bg-black relative select-none flex items-center justify-center">
        {/* Background scene preview */}
        <div className="absolute inset-0 opacity-30">
          <RestaurantScene
            isNight={true}
            playerPos={{ x: 600, y: 470 }}
            npcs={[]}
            cars={[]}
            motorcycle={{ x: -100, y: 555, direction: 1 }}
            totemGlow={false}
          />
        </div>
        
        <div className="relative z-10 text-center px-6 max-w-lg">
          {/* Logo */}
          <div className="mb-6 animate-bounce">
            <span className="text-7xl sm:text-8xl">🍔</span>
          </div>
          
          <h1 className="text-5xl sm:text-7xl font-black text-white tracking-wider mb-2">
            Mc<span className="text-yellow-400">TONNY</span>
          </h1>
          <p className="text-xl sm:text-2xl font-black text-red-500 uppercase tracking-widest mb-1">WORLD</p>
          <p className="text-white/50 text-sm sm:text-base mb-8">
            Explore o restaurante, interaja com NPCs e faça seu pedido no Totem Digital!
          </p>
          
          <button
            onClick={() => setGameStarted(true)}
            className="bg-gradient-to-r from-red-600 to-red-700 text-white font-black text-lg sm:text-xl px-10 py-4 rounded-full border-2 border-yellow-400 hover:from-red-500 hover:to-red-600 transition transform hover:scale-105 shadow-2xl shadow-red-500/30"
          >
            🎮 JOGAR
          </button>
          
          <div className="mt-6 grid grid-cols-3 gap-3 text-center">
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <p className="text-2xl mb-1">🕹️</p>
              <p className="text-white/60 text-xs font-bold">Mover</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <p className="text-2xl mb-1">📱</p>
              <p className="text-white/60 text-xs font-bold">Totem</p>
            </div>
            <div className="bg-white/5 rounded-xl p-3 border border-white/10">
              <p className="text-2xl mb-1">🌙</p>
              <p className="text-white/60 text-xs font-bold">Dia/Noite</p>
            </div>
          </div>
          
          <p className="text-white/30 text-xs mt-6">Toque ou use WASD / Setas para mover • E para interagir</p>
        </div>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen overflow-hidden bg-black relative select-none">
      {/* Day/Night Toggle */}
      <div className="fixed top-3 right-3 z-50 flex items-center gap-2">
        <button
          onClick={() => setIsNight(!isNight)}
          className="flex items-center gap-2 bg-black/50 border border-white/20 backdrop-blur-md px-4 py-2 rounded-full text-sm font-bold text-white hover:bg-black/70 transition"
        >
          {isNight ? '🌙' : '☀️'}
          <span className="hidden sm:inline">{isNight ? 'Noite' : 'Dia'}</span>
          <div className={`w-10 h-5 rounded-full relative transition-colors ${isNight ? 'bg-indigo-800' : 'bg-yellow-400'}`}>
            <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${isNight ? 'left-0.5' : 'left-[22px]'}`} />
          </div>
        </button>
      </div>

      {/* Brand Header */}
      <div className="fixed top-3 left-3 z-50">
        <div className="bg-black/50 border border-white/20 backdrop-blur-md px-4 py-2 rounded-full flex items-center gap-2">
          <span className="text-2xl">🍔</span>
          <span className="font-black text-white tracking-wider text-sm sm:text-base">McTONNY</span>
          <span className="text-yellow-400 text-xs font-bold hidden sm:inline">WORLD</span>
        </div>
      </div>

      {/* Instructions overlay */}
      {showInstructions && (
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 pointer-events-none">
          <div className="bg-black/80 border border-yellow-500/50 backdrop-blur-xl rounded-3xl px-8 py-6 text-center animate-pulse max-w-sm mx-auto">
            <p className="text-yellow-400 font-black text-lg mb-2">🎮 CONTROLES</p>
            <div className="space-y-2 text-white/80 text-sm">
              <p>🕹️ <span className="text-white font-bold">Joystick</span> ou <span className="text-white font-bold">WASD / Setas</span> para mover</p>
              <p>🟡 Botão <span className="text-yellow-400 font-bold">E</span> para interagir com o Totem</p>
              <p>🌙 Alterne entre <span className="text-blue-400 font-bold">Dia</span> e <span className="text-indigo-400 font-bold">Noite</span></p>
            </div>
            <p className="text-white/40 text-xs mt-3">Aproxime-se do totem e pressione E</p>
          </div>
        </div>
      )}

      {/* Mini-map / status */}
      <div className="fixed top-14 left-3 z-40">
        <div className="bg-black/40 border border-white/10 backdrop-blur-sm rounded-xl px-3 py-2 text-xs space-y-1">
          <p className="text-white/60">
            📍 <span className="text-white font-bold">
              {playerPos.x < 200 ? 'Estacionamento' : playerPos.x < 900 ? 'Frente da Loja' : 'Drive Thru'}
            </span>
          </p>
          {totemGlow && (
            <p className="text-yellow-400 font-bold animate-pulse">
              📱 Totem disponível! Pressione E
            </p>
          )}
        </div>
      </div>

      {/* SVG Scene */}
      <div className="w-full h-full">
        <RestaurantScene
          isNight={isNight}
          playerPos={playerPos}
          npcs={npcs.map(n => ({ x: n.x, y: n.y, color: n.color, direction: n.direction, type: n.type }))}
          cars={cars}
          motorcycle={motorcycle}
          totemGlow={totemGlow}
        />
      </div>

      {/* Virtual Joystick */}
      <Joystick onMove={movePlayer} onInteract={handleInteract} />

      {/* Totem Menu */}
      <TotemMenu isOpen={totemOpen} onClose={() => setTotemOpen(false)} />

      {/* NPC speech bubbles */}
      {npcs.map((npc, i) => {
        const dist = Math.sqrt(Math.pow(playerPos.x - npc.x, 2) + Math.pow(playerPos.y - npc.y, 2));
        if (dist > 80) return null;
        const messages = npc.type === 'worker'
          ? ['Bem-vindo ao McTonny!', 'Posso ajudar?', 'Peça no totem!']
          : ['Que fome! 🍔', 'Os lanches são ótimos!', 'Adoro o X-Tudo!', 'Já pediu?'];
        const msg = messages[i % messages.length];
        
        // Calculate approximate screen position
        const sceneWidth = window.innerWidth;
        const sceneHeight = window.innerHeight;
        const scaleX = sceneWidth / 1200;
        const scaleY = sceneHeight / 700;
        const screenX = npc.x * scaleX;
        const screenY = (npc.y - 50) * scaleY;
        
        return (
          <div
            key={`bubble-${i}`}
            className="fixed z-30 pointer-events-none"
            style={{ left: screenX, top: screenY, transform: 'translate(-50%, -100%)' }}
          >
            <div className="bg-white text-black px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap shadow-lg relative">
              {msg}
              <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white rotate-45" />
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default App;
