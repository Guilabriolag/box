export interface MenuItem {
  id: string;
  n: string;
  p: number;
  d: string;
}

export interface Category {
  label: string;
  items: MenuItem[];
}

export interface Cardapio {
  [key: string]: Category;
}

export const cardapio: Cardapio = {
  lanches: {
    label: "Lanches / Dogs",
    items: [
      { id: "dog-simples", n: "1 - DOG SIMPLES", p: 16, d: "Salsicha, queijo, milho, batata palha, ketchup, maionese e pão de banha." },
      { id: "dog-egg", n: "2 - DOG EGG", p: 21, d: "Salsicha, ovo, queijo, milho, batata palha, ketchup, maionese e pão de banha." },
      { id: "dog-calabresa", n: "3 - DOG CALABRESA", p: 21, d: "Salsicha, calabresa, queijo, milho, batata palha, ketchup, maionese e pão de banha." },
      { id: "dog-catupiry", n: "4 - DOG CATUPIRY", p: 21, d: "Salsicha, catupiry, queijo, milho, batata palha e pão de banha." },
      { id: "dog-bacon", n: "5 - DOG BACON", p: 21, d: "Salsicha, bacon, queijo, milho, batata palha, ketchup, maionese e pão de banha." },
      { id: "dog-salame", n: "6 - DOG SALAME", p: 21, d: "Salsicha, salame, queijo, milho, batata palha, ketchup, maionese e pão de banha." },
      { id: "dog-cheddar", n: "7 - DOG CHEDDAR", p: 21, d: "Salsicha, cheddar, queijo, milho, batata palha e pão de banha." },
      { id: "dog-salada", n: "8 - DOG SALADA", p: 21, d: "Salsicha, alface, tomate, queijo, milho, batata palha, ketchup, maionese e pão de banha." },
      { id: "dog-frango", n: "9 - DOG FRANGO", p: 21, d: "Salsicha, frango, queijo, milho, batata palha, maionese e pão de banha." },
      { id: "misto-quente", n: "10 - MISTO QUENTE", p: 14, d: "Queijo, presunto, maionese e pão francês." },
      { id: "bauru", n: "11 - BAURU", p: 14, d: "Queijo, presunto, tomate, orégano, maionese e pão francês." },
      { id: "americano", n: "12 - AMERICANO", p: 23, d: "Hambúrguer, queijo, presunto, alface, tomate, ovo, maionese e ketchup." },
      { id: "calabresa-vinagrete", n: "13 - CALABRESA VINAGRETE", p: 24, d: "Calabresa, vinagrete, queijo e pão francês." },
      { id: "churrasco-vinagrete", n: "14 - CHURRASCO VINAGRETE", p: 32, d: "Contrafilé, vinagrete, queijo, maionese e pão francês." },
      { id: "x-maionese", n: "15 - X-MAIONESE", p: 20, d: "Hambúrguer, queijo, maionese e pão de hambúrguer." },
      { id: "x-burguer", n: "16 - X-BURGUER", p: 20, d: "Hambúrguer, queijo, presunto, maionese e ketchup." },
      { id: "x-egg", n: "17 - X-EGG", p: 21, d: "Hambúrguer, ovo, queijo, presunto, maionese e ketchup." },
      { id: "x-calabresa", n: "18 - X-CALABRESA", p: 24, d: "Hambúrguer, calabresa, queijo, maionese e ketchup." },
      { id: "x-bacon", n: "19 - X-BACON", p: 24, d: "Hambúrguer, bacon, queijo, maionese e ketchup." },
      { id: "x-salada", n: "20 - X-SALADA", p: 20, d: "Hambúrguer, queijo, alface, tomate, maionese e ketchup." },
      { id: "x-tudo", n: "21 - X-TUDO", p: 28, d: "Hambúrguer, calabresa, bacon, salame, queijo, presunto, ovo e salada." }
    ]
  },
  mclanches: {
    label: "Mc / Prato",
    items: [
      { id: "mc-frango", n: "22 - MC FRANGO", p: 24, d: "Frango desfiado, catupiry, alface, queijo, maionese e pão de hambúrguer." },
      { id: "mc-cheddar", n: "23 - MC CHEDDAR", p: 27, d: "Hambúrguer, ovo, alface, tomate, cheddar e refrigerante." },
      { id: "mc-catupiry", n: "24 - MC CATUPIRY", p: 23, d: "Hambúrguer, presunto, queijo, alface, catupiry e pão de hambúrguer." },
      { id: "mc-dogao", n: "25 - MC DOGÃO", p: 23, d: "Hambúrguer, salsicha, salame, presunto, queijo, maionese e ketchup." },
      { id: "mc-tonny-feliz", n: "26 - MC TONNY FELIZ", p: 35, d: "Hambúrguer, queijo, alface, salame, milho, surpresa e refrigerante lata." },
      { id: "mc-milho", n: "27 - MC MILHO", p: 20, d: "Hambúrguer, queijo, milho, maionese, ketchup e pão de hambúrguer." },
      { id: "super-mc-tonny", n: "28 - SUPER MC TONNY", p: 25, d: "2 hambúrgueres, alface, queijo, salame, bacon, maionese e ketchup." },
      { id: "mc-salame", n: "29 - MC SALAME", p: 25, d: "Hambúrguer, salame, queijo, ovo, alface, tomate, maionese e ketchup." },
      { id: "mc-titan", n: "30 - MC TITAN", p: 90, d: "Gigante: 3 carnes, bacon, calabresa, salame, 3 ovos, fritas e Kuat 2L." },
      { id: "x-tudo-prato", n: "34 - X-TUDO NO PRATO", p: 35, d: "Hambúrguer, calabresa, bacon, ovo, queijo, salame, salada e fritas." },
      { id: "americano-prato", n: "35 - AMERICANO NO PRATO", p: 32, d: "Hambúrguer, ovo, queijo, presunto, alface, tomate e fritas." },
      { id: "super-mc-prato", n: "36 - SUPER MC NO PRATO", p: 35, d: "2 hambúrgueres, bacon, salame, queijo, alface, tomate e fritas." }
    ]
  },
  beirutes: {
    label: "Beirutes",
    items: [
      { id: "beirute-hamburguer", n: "31 - BEIRUTE HAMBÚRGUER", p: 40, d: "Hambúrguer, calabresa, bacon, ovo, salame, salada e queijo." },
      { id: "beirute-contrafile", n: "32 - BEIRUTE CONTRAFILÉ", p: 48, d: "Contrafilé, calabresa, bacon, ovo, alface, tomate e queijo." },
      { id: "beirute-frango", n: "33 - BEIRUTE FRANGO", p: 38, d: "Frango desfiado, queijo, presunto, alface, tomate e maionese." }
    ]
  },
  combos: {
    label: "Combos",
    items: [
      { id: "mc-burguer-duplo", n: "37 - MC BURGUER DUPLO", p: 40, d: "2 carnes, cheddar, bacon, salada, fritas e refrigerante lata." },
      { id: "mc-burguer-triplo", n: "38 - MC BURGUER TRIPLO", p: 42, d: "3 carnes, cheddar, bacon, salada, fritas e refrigerante lata." },
      { id: "mc-salada-combo", n: "39 - MC SALADA COMBO", p: 40, d: "Carne, cheddar, bacon, ovo, cebola, salada, fritas e refrigerante lata." },
      { id: "chicken-tonny", n: "40 - CHICKEN TONNY", p: 45, d: "Frango empanado, mussarela, bacon, ovo, alface, fritas e refrigerante lata." },
      { id: "chicken-duplo", n: "41 - CHICKEN DUPLO", p: 51, d: "2 frangos empanados, bacon, ovo, alface, fritas e refrigerante lata." },
      { id: "vegetariano", n: "43 - VEGETARIANO", p: 28, d: "Alface, tomate, cebola, molho especial, queijo, fritas e refrigerante lata." }
    ]
  },
  porcoes: {
    label: "Porções",
    items: [
      { id: "mc-porcao", n: "44 - MC PORÇÃO", p: 65, d: "Batata frita, calabresa, bacon, cheddar e Kuat 2L." },
      { id: "batata-cheddar", n: "45 - BATATA CHEDDAR", p: 35, d: "Porção generosa de batata com cheddar." },
      { id: "calabresa-acebolada", n: "46 - CALABRESA ACEBOLADA", p: 40, d: "Calabresa fatiada com cebola." },
      { id: "contrafile-acebolado", n: "47 - CONTRAFILÉ ACEBOLADO", p: 50, d: "Contrafilé em tiras com cebola." }
    ]
  },
  bebidas: {
    label: "Bebidas",
    items: [
      { id: "coca-lata", n: "COCA-COLA LATA", p: 6, d: "Lata 350ml gelada." },
      { id: "coca-2l", n: "COCA-COLA 2L", p: 13, d: "Ideal para a família." },
      { id: "kuat-2l", n: "GUARANÁ KUAT 2L", p: 10, d: "Gelado." },
      { id: "fanta-lata", n: "FANTA LARANJA LATA", p: 6, d: "Lata 350ml." },
      { id: "agua-sem-gas", n: "ÁGUA SEM GÁS", p: 4, d: "Garrafa 500ml." },
      { id: "suco-laranja", n: "SUCO DE LARANJA", p: 8, d: "Copo 400ml natural." }
    ]
  }
};

export const WHATSAPP_NUMBER = "5511969155294";
