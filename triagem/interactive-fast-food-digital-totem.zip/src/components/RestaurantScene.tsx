// RestaurantScene SVG component

interface Props {
  isNight: boolean;
  playerPos: { x: number; y: number };
  npcs: Array<{ x: number; y: number; color: string; direction: number; type: string }>;
  cars: Array<{ x: number; color: string }>;
  motorcycle: { x: number; y: number; direction: number };
  totemGlow: boolean;
}

export default function RestaurantScene({ isNight, playerPos, npcs, cars, motorcycle, totemGlow }: Props) {
  const skyGradient = isNight
    ? ['#0a0e27', '#1a1a3e', '#2d1b4e']
    : ['#87CEEB', '#B0E0E6', '#E0F0FF'];

  const groundColor = isNight ? '#1a1a2e' : '#6B8E23';
  const roadColor = isNight ? '#222' : '#444';
  const buildingWall = isNight ? '#2a2a2a' : '#3a3a3a';
  const glassOpacity = isNight ? 0.7 : 0.3;
  const lightIntensity = isNight ? 1 : 0.3;
  // ambient light handled via overlays

  return (
    <svg
      viewBox="0 0 1200 700"
      className="w-full h-full"
      style={{ background: `linear-gradient(180deg, ${skyGradient[0]}, ${skyGradient[1]}, ${skyGradient[2]})` }}
    >
      <defs>
        {/* Glass reflection gradient */}
        <linearGradient id="glassGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={isNight ? '#1a3a5a' : '#87CEEB'} stopOpacity={glassOpacity} />
          <stop offset="50%" stopColor={isNight ? '#2a1a0a' : '#fff'} stopOpacity={glassOpacity * 0.5} />
          <stop offset="100%" stopColor={isNight ? '#3a2a1a' : '#B0E0E6'} stopOpacity={glassOpacity} />
        </linearGradient>
        
        {/* Interior light glow */}
        <radialGradient id="interiorGlow" cx="50%" cy="50%" r="60%">
          <stop offset="0%" stopColor="#ffcc44" stopOpacity={isNight ? 0.6 : 0.1} />
          <stop offset="100%" stopColor="#ff8800" stopOpacity={0} />
        </radialGradient>

        {/* Exterior light cone */}
        <radialGradient id="lightCone" cx="50%" cy="0%" r="80%">
          <stop offset="0%" stopColor="#ffdd66" stopOpacity={lightIntensity * 0.8} />
          <stop offset="100%" stopColor="#ffdd66" stopOpacity={0} />
        </radialGradient>

        {/* Neon glow filter */}
        <filter id="neonGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        <filter id="softGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="8" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>

        {/* Star twinkle */}
        <filter id="twinkle">
          <feGaussianBlur stdDeviation="1.5" />
        </filter>

        {/* Totem screen gradient */}
        <linearGradient id="totemScreen" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1a1a2e" />
          <stop offset="100%" stopColor="#0a0a1e" />
        </linearGradient>

        <linearGradient id="totemGlowGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffbc0d" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#db0007" stopOpacity="0.6" />
        </linearGradient>
      </defs>

      {/* Stars (night only) */}
      {isNight && Array.from({ length: 40 }).map((_, i) => (
        <circle
          key={`star-${i}`}
          cx={30 + (i * 29) % 1140}
          cy={10 + (i * 17) % 180}
          r={0.5 + (i % 3) * 0.5}
          fill="white"
          opacity={0.3 + (i % 5) * 0.15}
          filter="url(#twinkle)"
        >
          <animate
            attributeName="opacity"
            values={`${0.3 + (i % 5) * 0.15};${0.8};${0.3 + (i % 5) * 0.15}`}
            dur={`${2 + (i % 3)}s`}
            repeatCount="indefinite"
          />
        </circle>
      ))}

      {/* Moon (night) / Sun (day) */}
      {isNight ? (
        <g>
          <circle cx="1050" cy="80" r="35" fill="#f0e68c" opacity="0.9" filter="url(#softGlow)" />
          <circle cx="1040" cy="75" r="30" fill={skyGradient[0]} />
        </g>
      ) : (
        <g>
          <circle cx="150" cy="90" r="45" fill="#FFD700" opacity="0.9" filter="url(#softGlow)" />
          <circle cx="150" cy="90" r="38" fill="#FFF8DC" />
        </g>
      )}

      {/* Clouds */}
      {!isNight && (
        <g opacity="0.7">
          <ellipse cx="300" cy="80" rx="60" ry="20" fill="white" />
          <ellipse cx="330" cy="70" rx="40" ry="18" fill="white" />
          <ellipse cx="270" cy="75" rx="35" ry="15" fill="white" />

          <ellipse cx="800" cy="100" rx="50" ry="18" fill="white" />
          <ellipse cx="825" cy="90" rx="35" ry="15" fill="white" />

          <ellipse cx="550" cy="60" rx="45" ry="16" fill="white" />
          <ellipse cx="575" cy="52" rx="30" ry="13" fill="white" />
        </g>
      )}

      {/* Ground */}
      <rect x="0" y="420" width="1200" height="280" fill={groundColor} />
      
      {/* Grass patches */}
      {!isNight && (
        <g opacity="0.3">
          {Array.from({ length: 20 }).map((_, i) => (
            <ellipse
              key={`grass-${i}`}
              cx={10 + (i * 61) % 1180}
              cy={430 + (i * 13) % 60}
              rx={15 + (i % 3) * 5}
              ry={3}
              fill="#4CAF50"
            />
          ))}
        </g>
      )}
      
      {/* Parking lot / Road */}
      <rect x="0" y="520" width="1200" height="180" fill={roadColor} />
      
      {/* Road texture */}
      {Array.from({ length: 8 }).map((_, i) => (
        <line
          key={`roadtex-${i}`}
          x1="0"
          y1={530 + i * 20}
          x2="1200"
          y2={530 + i * 20}
          stroke={isNight ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.05)'}
          strokeWidth="1"
        />
      ))}
      
      {/* Road lines */}
      {Array.from({ length: 15 }).map((_, i) => (
        <rect
          key={`line-${i}`}
          x={20 + i * 82}
          y="605"
          width="50"
          height="4"
          fill="#FFD700"
          opacity="0.6"
          rx="2"
        />
      ))}

      {/* Sidewalk */}
      <rect x="0" y="500" width="1200" height="25" fill={isNight ? '#444' : '#999'} />
      <rect x="0" y="498" width="1200" height="4" fill={isNight ? '#555' : '#bbb'} />

      {/* === BUILDING === */}
      <g>
        {/* Main building body */}
        <rect x="200" y="260" width="700" height="240" fill={buildingWall} rx="4" />
        
        {/* Building top trim */}
        <rect x="195" y="255" width="710" height="12" fill="#555" rx="3" />
        
        {/* Red accent pillar left */}
        <rect x="200" y="260" width="30" height="240" fill="#c00" />
        <rect x="200" y="260" width="30" height="240" fill="url(#interiorGlow)" opacity="0.3" />
        
        {/* Tower element */}
        <rect x="195" y="180" width="45" height="82" fill="#3a3a3a" rx="3" />
        <rect x="198" y="185" width="39" height="72" fill="#8B0000" rx="2" />
        
        {/* BRAND on tower - McTonny logo arch */}
        <g transform="translate(217, 210)" filter={isNight ? "url(#neonGlow)" : ""}>
          <path d="M-10 25 Q0 -5 10 25" stroke="#ffbc0d" strokeWidth="4" fill="none" />
          <path d="M-5 25 Q5 0 15 25" stroke="#ffbc0d" strokeWidth="4" fill="none" />
        </g>

        {/* Wood paneling section */}
        <rect x="230" y="340" width="200" height="160" fill={isNight ? '#3d2b1a' : '#8B6914'} />
        {Array.from({ length: 8 }).map((_, i) => (
          <rect key={`wood-${i}`} x="230" y={340 + i * 20} width="200" height="1" fill="rgba(0,0,0,0.2)" />
        ))}

        {/* Glass windows - main large ones */}
        <g>
          {/* Window 1 */}
          <rect x="240" y="270" width="140" height="65" fill="url(#glassGrad)" rx="2" />
          <rect x="240" y="270" width="140" height="65" fill="url(#interiorGlow)" />
          {/* Glass frame */}
          <rect x="240" y="270" width="140" height="65" fill="none" stroke={isNight ? '#555' : '#888'} strokeWidth="2" rx="2" />
          <line x1="310" y1="270" x2="310" y2="335" stroke={isNight ? '#555' : '#888'} strokeWidth="1.5" />
          
          {/* Reflection lines */}
          <line x1="250" y1="280" x2="260" y2="330" stroke="rgba(255,255,255,0.15)" strokeWidth="1" />
          <line x1="350" y1="275" x2="365" y2="325" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
        </g>

        {/* Window 2 */}
        <g>
          <rect x="440" y="270" width="160" height="180" fill="url(#glassGrad)" rx="2" />
          <rect x="440" y="270" width="160" height="180" fill="url(#interiorGlow)" />
          <rect x="440" y="270" width="160" height="180" fill="none" stroke={isNight ? '#555' : '#888'} strokeWidth="2" rx="2" />
          <line x1="520" y1="270" x2="520" y2="450" stroke={isNight ? '#555' : '#888'} strokeWidth="1.5" />
          
          {/* Interior visible - tables, people, lights */}
          <g opacity={isNight ? 0.5 : 0.2}>
            {/* Table 1 */}
            <rect x="458" y="410" width="24" height="3" fill="#8B6914" rx="1" />
            <rect x="468" y="413" width="4" height="18" fill="#666" />
            {/* Table 2 */}
            <rect x="530" y="405" width="24" height="3" fill="#8B6914" rx="1" />
            <rect x="540" y="408" width="4" height="20" fill="#666" />
            {/* People silhouettes */}
            <circle cx="465" cy="398" r="5" fill="#ffd" />
            <rect x="462" y="403" width="6" height="10" fill="#ffd" rx="2" />
            <circle cx="545" cy="393" r="5" fill="#ffd" />
            <rect x="542" y="398" width="6" height="10" fill="#ffd" rx="2" />
            {/* Ceiling lights */}
            {isNight && (
              <>
                <circle cx="480" cy="280" r="3" fill="#ffdd88" opacity="0.6" />
                <circle cx="550" cy="280" r="3" fill="#ffdd88" opacity="0.6" />
              </>
            )}
          </g>
          
          {/* Reflections */}
          <line x1="450" y1="280" x2="460" y2="440" stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
          <line x1="580" y1="275" x2="595" y2="430" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
        </g>

        {/* Window 3 */}
        <g>
          <rect x="620" y="270" width="140" height="180" fill="url(#glassGrad)" rx="2" />
          <rect x="620" y="270" width="140" height="180" fill="url(#interiorGlow)" />
          <rect x="620" y="270" width="140" height="180" fill="none" stroke={isNight ? '#555' : '#888'} strokeWidth="2" rx="2" />
          <line x1="690" y1="270" x2="690" y2="450" stroke={isNight ? '#555' : '#888'} strokeWidth="1.5" />
          
          <line x1="630" y1="280" x2="640" y2="440" stroke="rgba(255,255,255,0.12)" strokeWidth="1" />
          
          {/* Interior - counter/register */}
          <g opacity={isNight ? 0.4 : 0.15}>
            <rect x="635" y="380" width="50" height="5" fill="#555" rx="1" />
            {/* Cash register */}
            <rect x="650" y="370" width="15" height="12" fill="#444" rx="2" />
            <rect x="652" y="372" width="11" height="6" fill="#2a5a2a" rx="1" />
            {/* Worker behind counter */}
            <circle cx="700" cy="370" r="5" fill="#ffd" />
            <rect x="697" y="375" width="6" height="12" fill="#db0007" rx="2" />
            {/* Menu boards on wall */}
            <rect x="630" y="285" width="25" height="18" fill="#222" rx="1" />
            <rect x="660" y="285" width="25" height="18" fill="#222" rx="1" />
            <rect x="690" y="285" width="25" height="18" fill="#222" rx="1" />
            {isNight && (
              <circle cx="670" cy="275" r="3" fill="#ffdd88" opacity="0.5" />
            )}
          </g>
        </g>

        {/* Door */}
        <g>
          <rect x="780" y="310" width="80" height="190" fill="url(#glassGrad)" rx="3" />
          <rect x="780" y="310" width="80" height="190" fill="url(#interiorGlow)" opacity="0.5" />
          <rect x="780" y="310" width="80" height="190" fill="none" stroke={isNight ? '#666' : '#999'} strokeWidth="2" rx="3" />
          <line x1="820" y1="310" x2="820" y2="500" stroke={isNight ? '#666' : '#999'} strokeWidth="1.5" />
          {/* Door handle */}
          <rect x="810" y="400" width="3" height="20" fill="#ccc" rx="1" />
          <rect x="827" y="400" width="3" height="20" fill="#ccc" rx="1" />
        </g>

        {/* Building sign - MCTONNY */}
        <g filter={isNight ? "url(#neonGlow)" : ""}>
          <rect x="380" y="258" width="280" height="40" fill={buildingWall} rx="2" />
          <text
            x="520"
            y="285"
            textAnchor="middle"
            fill={isNight ? '#fff' : '#eee'}
            fontSize="26"
            fontWeight="900"
            fontFamily="Arial, sans-serif"
            letterSpacing="8"
          >
            McTONNY
          </text>
        </g>

        {/* Right side café section */}
        <rect x="870" y="350" width="80" height="150" fill={isNight ? '#4a2020' : '#8B0000'} rx="3" />
        <text
          x="910"
          y="430"
          textAnchor="middle"
          fill={isNight ? '#ffcc88' : '#ffd'}
          fontSize="14"
          fontWeight="bold"
          fontFamily="cursive"
          filter={isNight ? "url(#neonGlow)" : ""}
        >
          Café
        </text>

        {/* Roof overhang with lights */}
        <rect x="190" y="250" width="720" height="8" fill="#333" />
        
        {/* Under-roof lights */}
        {isNight && Array.from({ length: 12 }).map((_, i) => (
          <circle
            key={`rooflight-${i}`}
            cx={220 + i * 58}
            cy="255"
            r="3"
            fill="#ffdd88"
            filter="url(#neonGlow)"
            opacity="0.8"
          />
        ))}

        {/* Light cones on ground (night) */}
        {isNight && (
          <g>
            <ellipse cx="400" cy="500" rx="120" ry="15" fill="#ffdd66" opacity="0.08" />
            <ellipse cx="600" cy="500" rx="120" ry="15" fill="#ffdd66" opacity="0.08" />
            <ellipse cx="800" cy="500" rx="100" ry="12" fill="#ffdd66" opacity="0.06" />
          </g>
        )}
      </g>

      {/* === TOTEM (Interactive kiosk) === */}
      <g transform="translate(170, 420)">
        {/* Totem body */}
        <rect x="-20" y="-80" width="40" height="80" fill="#333" rx="4" />
        <rect x="-18" y="-76" width="36" height="55" fill="url(#totemScreen)" rx="3" />
        
        {/* Totem screen content */}
        <rect x="-16" y="-74" width="32" height="51" fill="#111" rx="2" />
        <text x="0" y="-60" textAnchor="middle" fill="#ffbc0d" fontSize="5" fontWeight="bold">McTONNY</text>
        <text x="0" y="-52" textAnchor="middle" fill="#fff" fontSize="3.5">PEÇA AQUI</text>
        <rect x="-12" y="-46" width="24" height="3" fill="#ffbc0d" rx="1" opacity="0.6" />
        <rect x="-12" y="-40" width="24" height="3" fill="#db0007" rx="1" opacity="0.6" />
        <rect x="-12" y="-34" width="24" height="3" fill="#ffbc0d" rx="1" opacity="0.6" />
        
        {/* Totem base */}
        <rect x="-15" y="0" width="30" height="8" fill="#444" rx="2" />
        
        {/* Totem glow effect */}
        {totemGlow && (
          <g>
            <rect x="-22" y="-82" width="44" height="84" fill="none" stroke="#ffbc0d" strokeWidth="2" rx="5" opacity="0.8" filter="url(#neonGlow)">
              <animate attributeName="opacity" values="0.5;1;0.5" dur="1.5s" repeatCount="indefinite" />
            </rect>
            <text x="0" y="-90" textAnchor="middle" fill="#ffbc0d" fontSize="6" fontWeight="bold" filter="url(#neonGlow)">
              INTERAGIR [E]
            </text>
          </g>
        )}
      </g>

      {/* === DRIVE THRU AREA === */}
      <g>
        {/* Drive thru sign */}
        <rect x="960" y="440" width="100" height="30" fill="#db0007" rx="5" />
        <text x="1010" y="460" textAnchor="middle" fill="white" fontSize="11" fontWeight="bold">Drive Thru</text>
        <rect x="1005" y="470" width="8" height="40" fill="#666" />
        
        {/* Drive thru lane marking */}
        <path d="M 900 500 Q 950 520 1000 540 Q 1100 580 1200 580" fill="none" stroke="#ffcc00" strokeWidth="2" strokeDasharray="8 6" opacity="0.5" />
        
        {/* Arrow on ground */}
        <polygon points="1100,570 1120,575 1100,580" fill="#ffcc00" opacity="0.4" />
      </g>

      {/* === CARS IN DRIVE THRU === */}
      {cars.map((car, i) => (
        <g key={`car-${i}`} transform={`translate(${car.x}, ${555 + i * 5})`}>
          {/* Car body */}
          <rect x="-30" y="-15" width="60" height="22" fill={car.color} rx="6" />
          {/* Car roof */}
          <rect x="-18" y="-25" width="36" height="14" fill={car.color} rx="5" opacity="0.9" />
          {/* Windshield */}
          <rect x="-16" y="-23" width="15" height="10" fill={isNight ? '#223' : '#89CFF0'} rx="2" opacity="0.7" />
          <rect x="2" y="-23" width="12" height="10" fill={isNight ? '#223' : '#89CFF0'} rx="2" opacity="0.7" />
          {/* Wheels */}
          <circle cx="-18" cy="7" r="5" fill="#222" />
          <circle cx="-18" cy="7" r="2.5" fill="#555" />
          <circle cx="18" cy="7" r="5" fill="#222" />
          <circle cx="18" cy="7" r="2.5" fill="#555" />
          {/* Headlights */}
          <rect x="28" y="-8" width="4" height="5" fill={isNight ? '#FFD700' : '#fff'} rx="1" opacity={isNight ? 0.9 : 0.5} />
          {/* Tail lights */}
          <rect x="-34" y="-8" width="4" height="5" fill="#ff3333" rx="1" opacity="0.7" />
          {/* Headlight beam (night) */}
          {isNight && (
            <polygon points="32,-10 80,-20 80,5 32,0" fill="#FFD700" opacity="0.06" />
          )}
        </g>
      ))}

      {/* === DELIVERY MOTORCYCLE === */}
      <g transform={`translate(${motorcycle.x}, ${motorcycle.y}) scale(${motorcycle.direction}, 1)`}>
        {/* Motorcycle body */}
        <rect x="-15" y="-8" width="30" height="12" fill="#db0007" rx="3" />
        {/* Delivery box */}
        <rect x="-18" y="-20" width="16" height="14" fill="#db0007" rx="2" />
        <text x="-10" y="-11" textAnchor="middle" fill="#ffbc0d" fontSize="5" fontWeight="bold">MT</text>
        {/* Rider */}
        <circle cx="5" cy="-18" r="5" fill="#ffd" />
        <rect x="2" y="-13" width="6" height="8" fill="#333" rx="2" />
        {/* Helmet */}
        <path d="M0,-23 Q5,-28 10,-23 Q10,-17 5,-16 Q0,-17 0,-23Z" fill="#222" />
        {/* Wheels */}
        <circle cx="-10" cy="6" r="5" fill="#222" />
        <circle cx="-10" cy="6" r="2" fill="#666" />
        <circle cx="12" cy="6" r="5" fill="#222" />
        <circle cx="12" cy="6" r="2" fill="#666" />
        {/* Exhaust */}
        {isNight && (
          <g opacity="0.3">
            <circle cx="-22" cy="2" r="2" fill="#aaa">
              <animate attributeName="cx" values="-22;-35;-50" dur="1s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.3;0.1;0" dur="1s" repeatCount="indefinite" />
              <animate attributeName="r" values="2;4;6" dur="1s" repeatCount="indefinite" />
            </circle>
          </g>
        )}
      </g>

      {/* === NPCs === */}
      {npcs.map((npc, i) => (
        <g key={`npc-${i}`} transform={`translate(${npc.x}, ${npc.y})`}>
          {/* Shadow */}
          <ellipse cx="0" cy="22" rx="8" ry="3" fill="rgba(0,0,0,0.3)" />
          {/* Body */}
          <rect x="-5" y="2" width="10" height="18" fill={npc.color} rx="3" />
          {/* Head */}
          <circle cx="0" cy="-4" r="7" fill="#ffd" />
          {/* Eyes */}
          <circle cx={npc.direction > 0 ? 2 : -2} cy="-5" r="1.2" fill="#333" />
          <circle cx={npc.direction > 0 ? 5 : 1} cy="-5" r="1.2" fill="#333" />
          {/* Hair */}
          <path
            d={`M-6,-8 Q0,-14 6,-8`}
            fill={npc.type === 'worker' ? '#8B4513' : '#333'}
            stroke="none"
          />
          {/* Arms */}
          <line x1="-5" y1="6" x2="-9" y2="14" stroke={npc.color} strokeWidth="3" strokeLinecap="round" />
          <line x1="5" y1="6" x2="9" y2="14" stroke={npc.color} strokeWidth="3" strokeLinecap="round" />
          {/* Legs walking animation represented by slight offset */}
          <line x1="-3" y1="20" x2="-4" y2="28" stroke="#336" strokeWidth="3" strokeLinecap="round" />
          <line x1="3" y1="20" x2="4" y2="28" stroke="#336" strokeWidth="3" strokeLinecap="round" />
          {/* Shoes */}
          <ellipse cx="-4" cy="29" rx="4" ry="2" fill="#333" />
          <ellipse cx="4" cy="29" rx="4" ry="2" fill="#333" />
          
          {/* Worker hat */}
          {npc.type === 'worker' && (
            <g>
              <rect x="-8" y="-12" width="16" height="4" fill="#db0007" rx="2" />
              <rect x="-5" y="-15" width="10" height="5" fill="#db0007" rx="2" />
            </g>
          )}
        </g>
      ))}

      {/* === PLAYER CHARACTER === */}
      <g transform={`translate(${playerPos.x}, ${playerPos.y})`}>
        {/* Shadow */}
        <ellipse cx="0" cy="24" rx="10" ry="4" fill="rgba(0,0,0,0.4)" />
        {/* Body */}
        <rect x="-7" y="0" width="14" height="22" fill="#2196F3" rx="4" />
        {/* Head */}
        <circle cx="0" cy="-7" r="9" fill="#FFE0BD" />
        {/* Eyes */}
        <circle cx="-3" cy="-8" r="1.5" fill="#333" />
        <circle cx="3" cy="-8" r="1.5" fill="#333" />
        {/* Mouth */}
        <path d="M-3,-3 Q0,0 3,-3" fill="none" stroke="#333" strokeWidth="1" />
        {/* Hair */}
        <path d="M-8,-12 Q0,-20 8,-12" fill="#4a2800" stroke="none" />
        {/* Arms */}
        <line x1="-7" y1="5" x2="-12" y2="16" stroke="#2196F3" strokeWidth="4" strokeLinecap="round" />
        <line x1="7" y1="5" x2="12" y2="16" stroke="#2196F3" strokeWidth="4" strokeLinecap="round" />
        {/* Legs */}
        <line x1="-4" y1="22" x2="-5" y2="32" stroke="#1565C0" strokeWidth="4" strokeLinecap="round" />
        <line x1="4" y1="22" x2="5" y2="32" stroke="#1565C0" strokeWidth="4" strokeLinecap="round" />
        {/* Shoes */}
        <ellipse cx="-5" cy="33" rx="5" ry="3" fill="#333" />
        <ellipse cx="5" cy="33" rx="5" ry="3" fill="#333" />
        
        {/* Player indicator */}
        <polygon points="-5,-28 0,-35 5,-28" fill="#ffbc0d" opacity="0.8">
          <animate attributeName="opacity" values="0.5;1;0.5" dur="1.5s" repeatCount="indefinite" />
          <animateTransform attributeName="transform" type="translate" values="0,0;0,-3;0,0" dur="1.5s" repeatCount="indefinite" />
        </polygon>
      </g>

      {/* === STREET LIGHTS === */}
      {[100, 500, 900, 1150].map((x, i) => (
        <g key={`streetlight-${i}`}>
          <rect x={x - 2} y="420" width="4" height="90" fill="#555" />
          <rect x={x - 10} y="415" width="20" height="8" fill="#444" rx="3" />
          <circle cx={x} cy="412" r="5" fill={isNight ? '#FFD700' : '#888'} opacity={isNight ? 0.9 : 0.4} filter={isNight ? "url(#neonGlow)" : ""} />
          {isNight && (
            <ellipse cx={x} cy="510" rx="40" ry="10" fill="#FFD700" opacity="0.05" />
          )}
        </g>
      ))}

      {/* === TREES === */}
      {[40, 130, 950, 1060, 1130].map((tx, i) => (
        <g key={`tree-${i}`} transform={`translate(${tx}, 410)`}>
          <rect x="-4" y="0" width="8" height="25" fill={isNight ? '#3d2b1a' : '#5D4037'} />
          <ellipse cx="0" cy="-8" rx={14 + (i % 3) * 4} ry={16 + (i % 2) * 5} fill={isNight ? '#1a3a1a' : '#2E7D32'} />
          <ellipse cx="-5" cy="-15" rx={10 + (i % 2) * 3} ry={12 + (i % 3) * 3} fill={isNight ? '#1f4a1f' : '#388E3C'} />
          <ellipse cx="5" cy="-12" rx={8 + (i % 2) * 2} ry={10 + (i % 3) * 2} fill={isNight ? '#245a24' : '#43A047'} />
        </g>
      ))}

      {/* === BUSHES === */}
      {[190, 870, 950].map((bx, i) => (
        <g key={`bush-${i}`}>
          <ellipse cx={bx} cy={498} rx={20 + i * 5} ry={8} fill={isNight ? '#1a3a1a' : '#2E7D32'} />
          <ellipse cx={bx - 8} cy={495} rx={12} ry={6} fill={isNight ? '#1f4a1f' : '#388E3C'} />
        </g>
      ))}

      {/* === TRASH CANS === */}
      {[155, 870].map((cx, i) => (
        <g key={`trash-${i}`} transform={`translate(${cx}, 488)`}>
          <rect x="-5" y="-12" width="10" height="14" fill={isNight ? '#444' : '#666'} rx="2" />
          <rect x="-6" y="-14" width="12" height="3" fill={isNight ? '#555' : '#777'} rx="1" />
          <rect x="-3" y="-13" width="6" height="1" fill={isNight ? '#333' : '#555'} />
        </g>
      ))}

      {/* === BENCH === */}
      <g transform="translate(130, 478)">
        <rect x="-15" y="0" width="30" height="3" fill={isNight ? '#5d3a1a' : '#8D6E63'} rx="1" />
        <rect x="-13" y="3" width="3" height="8" fill={isNight ? '#4a2a10' : '#795548'} />
        <rect x="10" y="3" width="3" height="8" fill={isNight ? '#4a2a10' : '#795548'} />
        <rect x="-15" y="-6" width="30" height="2" fill={isNight ? '#5d3a1a' : '#8D6E63'} rx="1" />
        <rect x="-14" y="-6" width="2" height="6" fill={isNight ? '#4a2a10' : '#795548'} />
        <rect x="12" y="-6" width="2" height="6" fill={isNight ? '#4a2a10' : '#795548'} />
      </g>

      {/* Parking spots */}
      {Array.from({ length: 6 }).map((_, i) => (
        <g key={`parking-${i}`}>
          <rect x={60 + i * 120} y="530" width="80" height="40" fill="none" stroke="white" strokeWidth="1.5" opacity="0.3" rx="2" />
        </g>
      ))}

      {/* === PARKED CARS === */}
      <g transform="translate(100, 548)">
        <rect x="-25" y="-12" width="50" height="18" fill={isNight ? '#1a3a5a' : '#3498db'} rx="5" />
        <rect x="-15" y="-20" width="30" height="11" fill={isNight ? '#1a3a5a' : '#3498db'} rx="4" />
        <rect x="-13" y="-18" width="12" height="8" fill={isNight ? '#112' : '#89CFF0'} rx="2" opacity="0.6" />
        <circle cx="-15" cy="6" r="4" fill="#222" />
        <circle cx="15" cy="6" r="4" fill="#222" />
      </g>

      <g transform="translate(340, 548)">
        <rect x="-25" y="-12" width="50" height="18" fill={isNight ? '#3a1a1a' : '#e74c3c'} rx="5" />
        <rect x="-15" y="-20" width="30" height="11" fill={isNight ? '#3a1a1a' : '#e74c3c'} rx="4" />
        <rect x="-13" y="-18" width="12" height="8" fill={isNight ? '#112' : '#89CFF0'} rx="2" opacity="0.6" />
        <circle cx="-15" cy="6" r="4" fill="#222" />
        <circle cx="15" cy="6" r="4" fill="#222" />
      </g>

      {/* === MENU BOARD outside === */}
      <g transform="translate(860, 440)">
        <rect x="-2" y="0" width="4" height="35" fill="#555" />
        <rect x="-25" y="-25" width="50" height="30" fill={isNight ? '#222' : '#333'} rx="3" />
        <rect x="-22" y="-22" width="44" height="24" fill={isNight ? '#111' : '#222'} rx="2" />
        <text x="0" y="-10" textAnchor="middle" fill="#ffbc0d" fontSize="6" fontWeight="bold">CARDÁPIO</text>
        <text x="0" y="0" textAnchor="middle" fill="#fff" fontSize="4" opacity="0.6">Do dia</text>
      </g>

      {/* Ambient overlay for night */}
      {isNight && (
        <rect x="0" y="0" width="1200" height="700" fill="rgba(0,0,40,0.15)" />
      )}

      {/* Ground reflection at night */}
      {isNight && (
        <g opacity="0.04">
          <rect x="200" y="520" width="700" height="3" fill="#ffcc44" />
        </g>
      )}
    </svg>
  );
}
