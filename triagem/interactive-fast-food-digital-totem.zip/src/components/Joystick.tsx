import { useRef, useCallback, useEffect } from 'react';

interface Props {
  onMove: (dx: number, dy: number) => void;
  onInteract: () => void;
}

export default function Joystick({ onMove, onInteract }: Props) {
  const padRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef(false);
  const centerRef = useRef({ x: 0, y: 0 });
  const moveIntervalRef = useRef<number | null>(null);
  const currentDirRef = useRef({ dx: 0, dy: 0 });

  const startMoving = useCallback(() => {
    if (moveIntervalRef.current) return;
    moveIntervalRef.current = window.setInterval(() => {
      const { dx, dy } = currentDirRef.current;
      if (dx !== 0 || dy !== 0) {
        onMove(dx, dy);
      }
    }, 30);
  }, [onMove]);

  const stopMoving = useCallback(() => {
    if (moveIntervalRef.current) {
      clearInterval(moveIntervalRef.current);
      moveIntervalRef.current = null;
    }
    currentDirRef.current = { dx: 0, dy: 0 };
  }, []);

  const handleStart = useCallback((clientX: number, clientY: number) => {
    if (!padRef.current) return;
    activeRef.current = true;
    const rect = padRef.current.getBoundingClientRect();
    centerRef.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    handleMove(clientX, clientY);
    startMoving();
  }, [startMoving]);

  const handleMove = useCallback((clientX: number, clientY: number) => {
    if (!activeRef.current || !knobRef.current || !padRef.current) return;
    const rect = padRef.current.getBoundingClientRect();
    const maxR = rect.width / 2 - 15;
    let dx = clientX - centerRef.current.x;
    let dy = clientY - centerRef.current.y;
    const dist = Math.sqrt(dx * dx + dy * dy);
    if (dist > maxR) {
      dx = (dx / dist) * maxR;
      dy = (dy / dist) * maxR;
    }
    knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
    
    const normDx = dx / maxR;
    const normDy = dy / maxR;
    currentDirRef.current = {
      dx: Math.abs(normDx) > 0.2 ? normDx * 3 : 0,
      dy: Math.abs(normDy) > 0.2 ? normDy * 2 : 0
    };
  }, []);

  const handleEnd = useCallback(() => {
    activeRef.current = false;
    if (knobRef.current) knobRef.current.style.transform = 'translate(0,0)';
    stopMoving();
  }, [stopMoving]);

  useEffect(() => {
    const onTouchMove = (e: TouchEvent) => {
      if (activeRef.current) {
        e.preventDefault();
        handleMove(e.touches[0].clientX, e.touches[0].clientY);
      }
    };
    const onTouchEnd = () => handleEnd();
    const onMouseMove = (e: MouseEvent) => handleMove(e.clientX, e.clientY);
    const onMouseUp = () => handleEnd();

    window.addEventListener('touchmove', onTouchMove, { passive: false });
    window.addEventListener('touchend', onTouchEnd);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);

    return () => {
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      stopMoving();
    };
  }, [handleMove, handleEnd, stopMoving]);

  return (
    <div className="fixed bottom-4 left-0 right-0 z-50 flex items-end justify-between px-4 pointer-events-none">
      {/* Joystick pad */}
      <div
        ref={padRef}
        className="pointer-events-auto w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-black/40 border-2 border-white/20 backdrop-blur-md flex items-center justify-center cursor-grab active:cursor-grabbing touch-none"
        onMouseDown={(e) => handleStart(e.clientX, e.clientY)}
        onTouchStart={(e) => {
          e.preventDefault();
          handleStart(e.touches[0].clientX, e.touches[0].clientY);
        }}
      >
        <div
          ref={knobRef}
          className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/30 border-2 border-white/50 backdrop-blur-sm transition-transform duration-75 shadow-lg"
          style={{ willChange: 'transform' }}
        />
      </div>

      {/* Action buttons */}
      <div className="pointer-events-auto flex flex-col gap-2 items-center">
        <button
          onClick={onInteract}
          className="w-16 h-16 sm:w-18 sm:h-18 rounded-full bg-yellow-400/80 border-2 border-yellow-300 text-black font-black text-lg shadow-lg shadow-yellow-500/30 hover:bg-yellow-300 active:scale-90 transition backdrop-blur-sm flex items-center justify-center"
        >
          E
        </button>
        <span className="text-white/50 text-[10px] font-bold">INTERAGIR</span>
      </div>
    </div>
  );
}
