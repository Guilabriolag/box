import { useState, useMemo } from 'react';
import { cardapio, WHATSAPP_NUMBER } from '../data/cardapio';
import type { MenuItem } from '../data/cardapio';

const money = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });

interface CartItem extends MenuItem {
  qty: number;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function TotemMenu({ isOpen, onClose }: Props) {
  const [category, setCategory] = useState('lanches');
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [mode, setMode] = useState<'retirar' | 'delivery'>('retirar');
  const [endereco, setEndereco] = useState('');
  const [bairro, setBairro] = useState('0');
  const [pagamento, setPagamento] = useState('');
  const [troco, setTroco] = useState('');
  const [obs, setObs] = useState('');
  const [showCart, setShowCart] = useState(false);
  const [toast, setToast] = useState('');

  const normalize = (t: string) => t.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

  const items = useMemo(() => {
    const q = normalize(search.trim());
    const base = q
      ? Object.values(cardapio).flatMap(c => c.items)
      : cardapio[category]?.items || [];
    if (!q) return base;
    return base.filter(i => normalize(`${i.n} ${i.d}`).includes(q));
  }, [category, search]);

  const deliveryFee = mode === 'delivery' ? Number(bairro) || 0 : 0;
  const subtotal = cart.reduce((s, i) => s + i.p * i.qty, 0);
  const total = subtotal + deliveryFee;
  const itemCount = cart.reduce((s, i) => s + i.qty, 0);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2000);
  };

  const addItem = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(c => c.id === item.id);
      if (existing) return prev.map(c => c.id === item.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { ...item, qty: 1 }];
    });
    showToast(`${item.n} adicionado!`);
  };

  const changeQty = (id: string, delta: number) => {
    setCart(prev => {
      const updated = prev.map(c => c.id === id ? { ...c, qty: c.qty + delta } : c);
      return updated.filter(c => c.qty > 0);
    });
  };

  const sendOrder = () => {
    if (!cart.length) { showToast("Adicione pelo menos um item."); return; }
    if (mode === 'delivery' && !endereco.trim()) { showToast("Informe o endereço."); return; }
    if (mode === 'delivery' && !Number(bairro)) { showToast("Selecione o bairro."); return; }
    if (!pagamento) { showToast("Escolha a forma de pagamento."); return; }

    const lines = ["*MCTONNY - PEDIDO*", "", "*ITENS:*"];
    cart.forEach(i => lines.push(`${i.qty}x ${i.n} - ${money.format(i.p * i.qty)}`));
    lines.push("", `*PRODUTOS:* ${money.format(subtotal)}`);
    if (deliveryFee > 0) lines.push(`*ENTREGA:* ${money.format(deliveryFee)}`);
    lines.push(`*TOTAL:* ${money.format(total)}`);
    if (obs.trim()) lines.push(`*OBS:* ${obs}`);
    if (mode === 'delivery') {
      lines.push("", "*MODALIDADE:* Delivery", `*ENDEREÇO:* ${endereco}`, `*BAIRRO:* ${bairro}`);
    } else {
      lines.push("", "*MODALIDADE:* Retirada no local");
    }
    lines.push(`*PAGAMENTO:* ${pagamento}`);
    if (pagamento === 'Dinheiro' && troco.trim()) lines.push(`*TROCO:* ${troco}`);

    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(lines.join("\n"))}`;
    window.open(url, "_blank");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-2 sm:p-4">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />

      {/* Totem Frame */}
      <div className="relative w-full max-w-2xl h-[90vh] flex flex-col rounded-3xl overflow-hidden border-4 border-yellow-500 shadow-2xl shadow-yellow-500/20">
        {/* Totem header */}
        <div className="bg-gradient-to-r from-red-700 via-red-600 to-red-700 px-4 py-3 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-yellow-400 flex items-center justify-center">
              <span className="text-xl">🍔</span>
            </div>
            <div>
              <h2 className="text-white font-black text-lg tracking-wider">McTONNY</h2>
              <p className="text-yellow-300 text-xs font-bold">TOTEM DIGITAL</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCart(!showCart)}
              className="relative bg-yellow-400 text-black px-3 py-2 rounded-full font-black text-sm hover:bg-yellow-300 transition"
            >
              🛒 {itemCount}
              {itemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-[10px] flex items-center justify-center font-bold animate-pulse">
                  {itemCount}
                </span>
              )}
            </button>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-black/30 text-white font-bold text-lg hover:bg-black/60 transition flex items-center justify-center"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Toast */}
        {toast && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-white text-black px-4 py-2 rounded-xl font-bold text-sm shadow-lg animate-bounce">
            {toast}
          </div>
        )}

        {showCart ? (
          /* Cart View */
          <div className="flex-1 bg-gray-950 flex flex-col overflow-hidden">
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.length === 0 ? (
                <div className="text-center py-12 text-white/50">
                  <p className="text-4xl mb-2">🛒</p>
                  <p className="font-bold text-lg text-white">Carrinho vazio</p>
                  <p className="text-sm">Adicione itens do cardápio</p>
                </div>
              ) : (
                <>
                  {cart.map(item => (
                    <div key={item.id} className="bg-white/5 border border-white/10 rounded-2xl p-3">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-black text-yellow-400 text-sm">{item.n}</p>
                          <p className="text-white/50 text-xs">{money.format(item.p)} cada</p>
                        </div>
                        <p className="font-black text-white">{money.format(item.p * item.qty)}</p>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <div className="flex items-center gap-1 bg-black rounded-full border border-white/10 p-1">
                          <button onClick={() => changeQty(item.id, -1)} className="w-7 h-7 rounded-full bg-white/10 text-white font-bold text-sm hover:bg-red-500 transition">-</button>
                          <span className="w-8 text-center font-black text-white text-sm">{item.qty}</span>
                          <button onClick={() => changeQty(item.id, 1)} className="w-7 h-7 rounded-full bg-white/10 text-white font-bold text-sm hover:bg-green-500 transition">+</button>
                        </div>
                        <button onClick={() => setCart(prev => prev.filter(c => c.id !== item.id))} className="text-xs text-red-400 font-bold hover:text-red-300">Remover</button>
                      </div>
                    </div>
                  ))}

                  {/* Order options */}
                  <div className="space-y-3 mt-4">
                    <textarea
                      value={obs}
                      onChange={e => setObs(e.target.value)}
                      placeholder="Observações (ex: sem cebola...)"
                      className="w-full bg-black border border-white/10 rounded-xl px-3 py-2 text-white text-sm resize-none outline-none focus:border-yellow-500 placeholder:text-white/30"
                      rows={2}
                    />
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setMode('retirar')}
                        className={`py-2 rounded-xl font-black text-sm border transition ${mode === 'retirar' ? 'bg-red-600 text-white border-yellow-400' : 'bg-transparent text-white/60 border-white/10'}`}
                      >
                        Retirar
                      </button>
                      <button
                        onClick={() => setMode('delivery')}
                        className={`py-2 rounded-xl font-black text-sm border transition ${mode === 'delivery' ? 'bg-red-600 text-white border-yellow-400' : 'bg-transparent text-white/60 border-white/10'}`}
                      >
                        Delivery
                      </button>
                    </div>
                    {mode === 'delivery' && (
                      <>
                        <input
                          value={endereco}
                          onChange={e => setEndereco(e.target.value)}
                          placeholder="Endereço completo"
                          className="w-full bg-black border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none focus:border-yellow-500 placeholder:text-white/30"
                        />
                        <select
                          value={bairro}
                          onChange={e => setBairro(e.target.value)}
                          className="w-full bg-black border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none focus:border-yellow-500"
                        >
                          <option value="0">Selecione o bairro</option>
                          <option value="3">CENTRO - R$ 3,00</option>
                          <option value="3">JD BOM JESUS - R$ 3,00</option>
                          <option value="4">MORRO BRANCO - R$ 4,00</option>
                          <option value="10">GREEN HILLS - R$ 10,00</option>
                          <option value="3">VILA NOVA - R$ 3,00</option>
                          <option value="7">PAIOL / KM 50 - R$ 7,00</option>
                        </select>
                      </>
                    )}
                    <select
                      value={pagamento}
                      onChange={e => setPagamento(e.target.value)}
                      className="w-full bg-black border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none focus:border-yellow-500"
                    >
                      <option value="">Forma de pagamento</option>
                      <option value="Pix">Pix</option>
                      <option value="Cartão">Cartão</option>
                      <option value="Dinheiro">Dinheiro</option>
                    </select>
                    {pagamento === 'Dinheiro' && (
                      <input
                        value={troco}
                        onChange={e => setTroco(e.target.value)}
                        placeholder="Troco para quanto?"
                        className="w-full bg-black border border-white/10 rounded-xl px-3 py-2 text-white text-sm outline-none focus:border-yellow-500 placeholder:text-white/30"
                      />
                    )}
                  </div>
                </>
              )}
            </div>

            {/* Cart footer */}
            <div className="border-t border-white/10 bg-black/80 p-4 shrink-0">
              <div className="space-y-1 text-sm mb-3">
                <div className="flex justify-between text-white/60"><span>Produtos</span><span>{money.format(subtotal)}</span></div>
                {deliveryFee > 0 && <div className="flex justify-between text-white/60"><span>Entrega</span><span>{money.format(deliveryFee)}</span></div>}
                <div className="flex justify-between text-xl font-black text-white"><span>Total</span><span className="text-yellow-400">{money.format(total)}</span></div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => { setCart([]); showToast("Pedido limpo!"); }} className="py-3 rounded-xl border border-white/10 font-black text-white/70 text-sm hover:bg-white hover:text-black transition">
                  Limpar
                </button>
                <button onClick={sendOrder} className="py-3 rounded-xl bg-green-500 font-black text-white text-sm hover:bg-green-400 transition flex items-center justify-center gap-2">
                  <span>📱</span> Finalizar
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Menu View */
          <div className="flex-1 bg-gray-950 flex flex-col overflow-hidden">
            {/* Search */}
            <div className="p-3 shrink-0">
              <div className="relative">
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="🔍 Buscar item..."
                  className="w-full bg-black border border-white/10 rounded-full px-4 py-2.5 text-white text-sm outline-none focus:border-yellow-500 placeholder:text-white/30"
                />
              </div>
            </div>

            {/* Category tabs */}
            <div className="px-3 shrink-0 overflow-x-auto flex gap-2 pb-2" style={{ scrollbarWidth: 'none' }}>
              {Object.entries(cardapio).map(([key, cat]) => (
                <button
                  key={key}
                  onClick={() => { setCategory(key); setSearch(''); }}
                  className={`whitespace-nowrap px-3 py-1.5 rounded-full text-xs font-black transition border ${
                    category === key && !search
                      ? 'bg-yellow-400 text-black border-yellow-400'
                      : 'bg-transparent text-white/60 border-white/10 hover:border-yellow-400/50'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Items grid */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              <p className="text-white/40 text-xs font-semibold mb-1">{items.length} item(ns)</p>
              {items.map(item => (
                <div
                  key={item.id}
                  className="bg-gradient-to-r from-white/5 to-white/[0.02] border border-white/10 rounded-2xl p-3 hover:border-yellow-500/40 transition group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-black text-yellow-400 text-sm leading-tight">{item.n}</h3>
                      <p className="text-white/50 text-xs mt-1 leading-relaxed">{item.d}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-black text-white text-lg">{money.format(item.p)}</p>
                      <button
                        onClick={() => addItem(item)}
                        className="mt-1 bg-yellow-400 text-black px-3 py-1.5 rounded-full text-xs font-black hover:bg-white transition transform hover:scale-105"
                      >
                        + Adicionar
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Totem footer strip */}
        <div className="bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-500 h-1 shrink-0" />
      </div>
    </div>
  );
}
