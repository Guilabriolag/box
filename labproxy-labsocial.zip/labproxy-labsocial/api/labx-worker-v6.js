/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  LAB-X v6 — Cloudflare Worker                                       ║
 * ║  Motor de Data Intelligence — LABRIOLAG Holding                     ║
 * ║  labriolag.shop · Auth + Créditos + Cache + Motor 16D               ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * BINDINGS NECESSÁRIOS (wrangler.toml):
 *   [[kv_namespaces]]
 *   binding = "LABX_KV"       ← armazena auth, créditos, cache, análises
 *
 * VARIÁVEIS DE AMBIENTE (Cloudflare Dashboard → Settings → Variables):
 *   LABX_ADMIN_SECRET  ← senha para criar/revogar API Keys (não vai no código)
 *   ALLOWED_ORIGIN     ← ex: https://labriolag.shop  (evitar CORS aberto)
 *
 * DEPLOY:
 *   wrangler deploy
 *
 * ─── ENDPOINTS PÚBLICOS ────────────────────────────────────────────────
 *   GET  /health                  → Status do worker
 *   GET  /feed                    → Feed macroeconômico BCB (SELIC, IPCA, IBC-Br)
 *
 * ─── ENDPOINTS AUTENTICADOS (Header: X-API-Key: sk_lab_...) ───────────
 *   GET  /me                      → Saldo e perfil da chave atual
 *   GET  /ibge/:codMunicipio      → Dados municipais IBGE (consome 0 créditos, cacheado)
 *   POST /calcular                → Motor 16D + Rating MSCL (consome 1 crédito)
 *   POST /salvar                  → Salva análise no KV
 *   GET  /historico               → Lista análises da chave
 *   GET  /analise/:id             → Busca análise por ID
 *   DELETE /analise/:id           → Exclui análise
 *
 * ─── ENDPOINTS ADMIN (Header: X-Admin-Secret: ...) ────────────────────
 *   POST /admin/keys              → Cria nova API Key
 *   GET  /admin/keys              → Lista todas as chaves
 *   PATCH /admin/keys/:key        → Atualiza créditos ou tier
 *   DELETE /admin/keys/:key       → Revoga chave
 *   GET  /admin/stats             → Estatísticas de uso
 */

// ─── CORS ──────────────────────────────────────────────────────────────────
function corsHeaders(env, request) {
  const allowed = env.ALLOWED_ORIGIN || '*';
  const origin  = request.headers.get('Origin') || '';
  const useOrigin = (allowed === '*') ? '*' : (origin === allowed ? origin : allowed);
  return {
    'Access-Control-Allow-Origin':  useOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-API-Key, X-Admin-Secret',
    'Content-Type': 'application/json',
  };
}

// ─── TTL ───────────────────────────────────────────────────────────────────
const TTL = {
  BCB:      60 * 60 * 4,        // 4h  — dados macro BCB
  IBGE:     60 * 60 * 24,       // 24h — dados IBGE CEMPRE
  ANALISE:  60 * 60 * 24 * 90,  // 90d — análises salvas
  RATE:     60,                  // 60s — janela de rate limiting
};

// ─── BCB SERIES IDS ────────────────────────────────────────────────────────
const BCB = { SELIC: 11, IPCA: 433, IBCBR: 24363, CAMBIO: 1 };

// ─── BOUNDS para Min-Max Scaling (histórico BR 2002-2025) ─────────────────
const BOUNDS = {
  SELIC:        { min: 2.0,   max: 15.0  },
  IPCA:         { min: 0.0,   max: 1.5   },
  IBCBR:        { min: 95.0,  max: 145.0 },
  empresas_pop: { min: 0.005, max: 0.12  },
};

// ─── HELPERS ───────────────────────────────────────────────────────────────
const minmax = (v, min, max) => Math.max(0, Math.min(1, (v - min) / (max - min)));
const clamp  = v => Math.max(0, Math.min(10, v));
const r2     = v => Number(v.toFixed(2));
const avg    = arr => arr.reduce((s, v) => s + v, 0) / arr.length;

function ok(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data, null, 2), { status, headers });
}
function err(message, status = 400, headers = {}) {
  return new Response(JSON.stringify({ error: message }), { status, headers });
}

// ─── FETCH BCB ─────────────────────────────────────────────────────────────
async function fetchBCB(serie) {
  const url = `https://api.bcb.gov.br/dados/serie/bcdata.sgs.${serie}/dados/ultimos/1?formato=json`;
  const r = await fetch(url, { cf: { cacheTtl: TTL.BCB, cacheEverything: true } });
  if (!r.ok) throw new Error(`BCB ${serie}: ${r.status}`);
  const d = await r.json();
  return d[d.length - 1]; // { data, valor }
}

// ─── FETCH IBGE ────────────────────────────────────────────────────────────
async function fetchIBGEEmpresas(cod) {
  const url = `https://apisidra.ibge.gov.br/values/t/6321/n6/${cod}/v/allxp/p/last%201/f/u`;
  const r = await fetch(url, { cf: { cacheTtl: TTL.IBGE, cacheEverything: true } });
  if (!r.ok) throw new Error(`IBGE Empresas: ${r.status}`);
  const d = await r.json();
  const row = d.find(x => x.V && x.V !== '-') || d[1];
  return row ? parseInt(row.V.replace(/\./g, ''), 10) || 0 : 0;
}

async function fetchIBGEPessoal(cod) {
  const url = `https://apisidra.ibge.gov.br/values/t/6579/n6/${cod}/v/allxp/p/last%201/f/u`;
  const r = await fetch(url, { cf: { cacheTtl: TTL.IBGE, cacheEverything: true } });
  if (!r.ok) throw new Error(`IBGE Pessoal: ${r.status}`);
  const d = await r.json();
  const row = d.find(x => x.V && x.V !== '-') || d[1];
  return row ? parseInt(row.V.replace(/\./g, ''), 10) || 0 : 0;
}

async function fetchIBGEPopulacao(cod) {
  const r = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/municipios/${cod}`);
  if (!r.ok) return { nome: 'Município', pop: 50000 };
  const m = await r.json();
  return { nome: m.nome || 'Município', pop: 50000 }; // pop estimada; IBGE v3 para série real
}

// ─── MOTOR VETORIAL 16D ────────────────────────────────────────────────────
function calcularVetores({ renda, cnpjs, populacao, pib, modo = 1.0, bcbData = {}, ibgeData = {} }) {
  const { selic = 10.5, ipca = 0.44, ibcbr = 118 } = bcbData;

  const rN = Math.min(renda / 5000, 1);
  const dN = Math.min(cnpjs / 200, 1);
  const pN = Math.min(populacao / 500000, 1);
  const gN = Math.min(pib / 200, 1);

  const selicN = minmax(selic, BOUNDS.SELIC.min, BOUNDS.SELIC.max);
  const ipcaN  = minmax(ipca,  0, 1.5);
  const ibcN   = minmax(ibcbr, BOUNDS.IBCBR.min, BOUNDS.IBCBR.max);

  const sat = dN > 0.7 ? (dN - 0.7) * 3 : 0;
  const liq = (rN + gN) / 2;
  const inovFator = ibcN > 0.5 ? 1.1 : 0.9;

  // Cardinais
  const N = clamp((gN * 8 + pN * 2) * modo);
  const S = clamp((dN * 5 + (ibgeData.pessoal ? Math.min(ibgeData.pessoal / 50000, 1) : dN) * 3 + rN * 2) * modo);
  const L = clamp(((1 - sat) * 6 + liq * 3 + ibcN * 1) * modo);
  const O = clamp((rN * 4 + gN * 4 + (1 - selicN) * 2) * modo);

  // Colaterais
  const NE = clamp(((N + L) / 2 * 0.9) * modo);
  const SE = clamp((gN * 6 + ibcN * 2 + rN * 2) * 0.9 * modo);
  const SO = clamp((sat * 4 + selicN * 4 + (1 - liq) * 2) * 0.8 * modo);
  const NO = clamp(((N + O) / 2 * 0.9) * modo);

  // Subcolaterais
  const NNE = clamp(((NE + N) / 2 * 0.85) * modo);
  const ENE = clamp((liq * 6 + pN * 2 + (1 - ipcaN) * 2) * 0.8 * modo);
  const ESE = clamp((dN * 4 + rN * 3 + ibcN * 3) * 0.8 * modo);
  const SSE = clamp(((ibcN * 7 + (1 - ipcaN) * 3) * 0.85) * modo);
  const SSO = clamp((selicN * 5 + sat * 3 + (1 - gN) * 2) * 0.8 * modo);
  const OSO = clamp((sat * 8 + dN * 2) * 0.8 * modo);
  const ONO = clamp(((NO + NE) / 2 * inovFator * 0.85) * modo);
  const NNO = clamp(((N * 0.5 + pN * 3 + ibcN * 1.5) * 0.8) * modo);

  const vetores = {
    N: r2(N), S: r2(S), L: r2(L), O: r2(O),
    NE: r2(NE), SE: r2(SE), SO: r2(SO), NO: r2(NO),
    NNE: r2(NNE), ENE: r2(ENE), ESE: r2(ESE), SSE: r2(SSE),
    SSO: r2(SSO), OSO: r2(OSO), ONO: r2(ONO), NNO: r2(NNO),
  };

  const card = [N, S, L, O];
  const cola = [NE, SE, SO, NO];
  const sub  = [NNE, ENE, ESE, SSE, SSO, OSO, ONO, NNO];
  const iac  = r2(avg(card) * 0.5 + avg(cola) * 0.3 + avg(sub) * 0.2);

  const entries  = Object.entries(vetores);
  const dom      = [...entries].sort((a, b) => b[1] - a[1])[0][0];
  const neg      = entries.filter(([, v]) => v < 4).map(([k]) => k);
  const crit     = entries.filter(([k, v]) => ['N','S','L','O','NE','SE','SO','NO'].includes(k) && v < 5).map(([k]) => k);
  const mediaGeral = r2(avg(Object.values(vetores)));

  // Rating MSCL
  const rating = calcularRating({
    empresas: ibgeData.empresas || cnpjs * 50,
    populacao, rendaMedia: renda, selic, ipca, ibcbr, iac,
  });

  return {
    vetores, iac, rating,
    diagnostico: {
      dominante: dom, negligenciadas: neg, criticas: crit, mediaGeral,
      score: iac >= 7 ? 'FORTE' : iac >= 4 ? 'EQUILIBRIO' : 'RISCO',
    },
    fontes: { selic: r2(selic), ipca: r2(ipca), ibcbr: r2(ibcbr),
              empresas: ibgeData.empresas || null, pessoal: ibgeData.pessoal || null, populacao },
    parametros: { renda, cnpjs, populacao, pib, modo },
    timestamp: new Date().toISOString(),
    engine: 'LAB-X v6 · Motor 16D · MSCL',
  };
}

// ─── RATING MSCL ───────────────────────────────────────────────────────────
function calcularRating({ empresas, populacao, rendaMedia, selic, ipca, ibcbr, iac }) {
  const densEmp    = empresas / Math.max(populacao, 1);
  const densNorm   = minmax(densEmp, BOUNDS.empresas_pop.min, BOUNDS.empresas_pop.max);
  const ibcbrNorm  = minmax(ibcbr || 120, BOUNDS.IBCBR.min, BOUNDS.IBCBR.max);
  const fatCrescimento = ibcbrNorm > 0.5 ? 1.15 : 1.0;
  const pilarTracao = clamp(densNorm * 10 * fatCrescimento);

  const rendaReal  = rendaMedia / (1 + (ipca || 0.5) / 100);
  const selicPenalty = minmax(selic || 10, BOUNDS.SELIC.min, BOUNDS.SELIC.max);
  const fatorSELIC = 1 - (selicPenalty * 0.4);
  const pilarLiquidez = clamp((rendaReal / 5000) * fatorSELIC * 10);
  const pilarIAC = clamp(iac);

  const score = r2(pilarTracao * 0.40 + pilarLiquidez * 0.35 + pilarIAC * 0.25);

  let rating, desc;
  if      (score >= 9.0) { rating = 'AAA'; desc = 'Oceano Azul — Alta renda, baixa saturação'; }
  else if (score >= 8.0) { rating = 'AA';  desc = 'Expansão qualificada — Mercado receptivo'; }
  else if (score >= 7.0) { rating = 'A';   desc = 'Mercado em maturação — Ótimo para consolidação'; }
  else if (score >= 6.0) { rating = 'B';   desc = 'Mercado competitivo — Nicho necessário'; }
  else if (score >= 5.0) { rating = 'C';   desc = 'Saturação moderada — Renda estagnada'; }
  else if (score >= 3.0) { rating = 'D';   desc = 'Risco elevado — Baixa liquidez territorial'; }
  else                   { rating = 'E';   desc = 'Risco crítico — Não recomendado no momento'; }

  return {
    rating, desc, score,
    pilares: { tracao: r2(pilarTracao), liquidez: r2(pilarLiquidez), iac: r2(pilarIAC) },
    fatores: {
      densidadeEmpresas: r2(densEmp * 1000),
      fatCrescimento: r2(fatCrescimento),
      fatorSELIC: r2(fatorSELIC),
      rendaReal: Math.round(rendaReal),
    },
  };
}

// ─── AUTH: valida API Key e retorna perfil ─────────────────────────────────
async function getAuth(env, apiKey) {
  if (!apiKey) return null;
  const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
  if (!raw) return null;
  return JSON.parse(raw);
}

// ─── RATE LIMITING: max 30 req/min por chave ──────────────────────────────
async function checkRateLimit(env, apiKey) {
  const rateKey = `rate:${apiKey}:${Math.floor(Date.now() / 60000)}`; // janela de 1 min
  const raw = await env.LABX_KV.get(rateKey).catch(() => null);
  const count = raw ? parseInt(raw) : 0;
  if (count >= 30) return false;
  await env.LABX_KV.put(rateKey, String(count + 1), { expirationTtl: TTL.RATE });
  return true;
}

// ─── GERAR API KEY ─────────────────────────────────────────────────────────
function gerarApiKey() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let key = 'sk_lab_';
  for (let i = 0; i < 24; i++) key += chars[Math.floor(Math.random() * chars.length)];
  return key;
}

// ─── ADMIN: valida secret ──────────────────────────────────────────────────
function isAdmin(request, env) {
  const secret = request.headers.get('X-Admin-Secret');
  return secret && secret === env.LABX_ADMIN_SECRET;
}

// ══════════════════════════════════════════════════════════════════════════
//  ROUTER PRINCIPAL
// ══════════════════════════════════════════════════════════════════════════
export default {
  async fetch(request, env) {
    const url    = new URL(request.url);
    const CH     = corsHeaders(env, request);

    // Preflight CORS
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CH });
    }

    // ── GET /health ────────────────────────────────────────────────────────
    if (url.pathname === '/health') {
      return ok({
        status: 'online',
        version: '6.0',
        engine: 'LAB-X Data Intelligence · LABRIOLAG Holding',
        domain: 'labriolag.shop',
        ts: new Date().toISOString(),
      }, 200, CH);
    }

    // ── GET /feed — público, cacheado 4h ──────────────────────────────────
    if (url.pathname === '/feed') {
      const cacheKey = 'feed:macro:v6';
      if (env.LABX_KV) {
        const cached = await env.LABX_KV.get(cacheKey).catch(() => null);
        if (cached) return ok(JSON.parse(cached), 200, CH);
      }
      try {
        const [sR, iR, bR, cR] = await Promise.allSettled([
          fetchBCB(BCB.SELIC), fetchBCB(BCB.IPCA), fetchBCB(BCB.IBCBR), fetchBCB(BCB.CAMBIO),
        ]);
        const feed = {
          selic:  sR.status === 'fulfilled' ? sR.value : { data: '-', valor: '10.50' },
          ipca:   iR.status === 'fulfilled' ? iR.value : { data: '-', valor: '0.44'  },
          ibcbr:  bR.status === 'fulfilled' ? bR.value : { data: '-', valor: '118.0' },
          cambio: cR.status === 'fulfilled' ? cR.value : { data: '-', valor: '5.20'  },
          capturedAt: new Date().toISOString(),
        };
        if (env.LABX_KV) await env.LABX_KV.put(cacheKey, JSON.stringify(feed), { expirationTtl: TTL.BCB });
        return ok(feed, 200, CH);
      } catch {
        return ok({ error: 'BCB indisponível', fallback: true }, 200, CH);
      }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ROTAS ADMIN  (X-Admin-Secret)
    // ══════════════════════════════════════════════════════════════════════
    if (url.pathname.startsWith('/admin/')) {
      if (!isAdmin(request, env)) return err('Acesso negado', 403, CH);

      // POST /admin/keys — cria nova chave
      if (url.pathname === '/admin/keys' && request.method === 'POST') {
        const body = await request.json().catch(() => ({}));
        const key  = gerarApiKey();
        const profile = {
          owner:     body.owner     || 'Usuário LAB-X',
          tier:      body.tier      || 'starter',   // starter | pro | enterprise
          credits:   body.credits   ?? 10,
          createdAt: new Date().toISOString(),
          active:    true,
          usageTotal: 0,
        };
        await env.LABX_KV.put(`auth:${key}`, JSON.stringify(profile), { expirationTtl: 60 * 60 * 24 * 365 });
        await env.LABX_KV.put(`keyindex:${Date.now()}`, key); // índice para listar
        return ok({ ok: true, key, profile }, 201, CH);
      }

      // GET /admin/keys — lista chaves (via índice)
      if (url.pathname === '/admin/keys' && request.method === 'GET') {
        const list = await env.LABX_KV.list({ prefix: 'keyindex:' });
        const keys = await Promise.all(
          list.keys.map(async k => {
            const apiKey = await env.LABX_KV.get(k.name).catch(() => null);
            if (!apiKey) return null;
            const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
            if (!raw) return null;
            return { key: apiKey, ...JSON.parse(raw) };
          })
        );
        return ok({ total: keys.filter(Boolean).length, keys: keys.filter(Boolean) }, 200, CH);
      }

      // PATCH /admin/keys/:key — atualiza créditos ou tier
      if (url.pathname.startsWith('/admin/keys/') && request.method === 'PATCH') {
        const apiKey = url.pathname.replace('/admin/keys/', '');
        const raw    = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
        if (!raw) return err('Chave não encontrada', 404, CH);
        const profile = JSON.parse(raw);
        const body    = await request.json().catch(() => ({}));
        if (body.credits  !== undefined) profile.credits  = Number(body.credits);
        if (body.tier     !== undefined) profile.tier     = body.tier;
        if (body.active   !== undefined) profile.active   = Boolean(body.active);
        profile.updatedAt = new Date().toISOString();
        await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: 60 * 60 * 24 * 365 });
        return ok({ ok: true, apiKey, profile }, 200, CH);
      }

      // DELETE /admin/keys/:key — revoga chave
      if (url.pathname.startsWith('/admin/keys/') && request.method === 'DELETE') {
        const apiKey = url.pathname.replace('/admin/keys/', '');
        await env.LABX_KV.delete(`auth:${apiKey}`);
        return ok({ ok: true, revoked: apiKey }, 200, CH);
      }

      // GET /admin/stats — uso total
      if (url.pathname === '/admin/stats') {
        const list = await env.LABX_KV.list({ prefix: 'keyindex:' });
        let totalCreditsUsed = 0, totalKeys = 0, activeKeys = 0;
        await Promise.all(list.keys.map(async k => {
          const apiKey = await env.LABX_KV.get(k.name).catch(() => null);
          if (!apiKey) return;
          const raw = await env.LABX_KV.get(`auth:${apiKey}`).catch(() => null);
          if (!raw) return;
          const p = JSON.parse(raw);
          totalKeys++;
          if (p.active) activeKeys++;
          totalCreditsUsed += p.usageTotal || 0;
        }));
        return ok({ totalKeys, activeKeys, totalCreditsUsed, ts: new Date().toISOString() }, 200, CH);
      }

      return err('Rota admin não encontrada', 404, CH);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ROTAS AUTENTICADAS  (X-API-Key)
    // ══════════════════════════════════════════════════════════════════════
    const apiKey = request.headers.get('X-API-Key');
    const profile = await getAuth(env, apiKey);

    if (!profile)         return err('API Key inválida ou ausente. Obtenha sua chave em labriolag.shop', 401, CH);
    if (!profile.active)  return err('API Key revogada. Entre em contato com a Labriolag Holding.', 403, CH);

    // Rate limiting
    const withinLimit = await checkRateLimit(env, apiKey);
    if (!withinLimit) return err('Rate limit: máximo 30 requisições/minuto por chave.', 429, CH);

    // ── GET /me ────────────────────────────────────────────────────────────
    if (url.pathname === '/me') {
      return ok({
        owner:      profile.owner,
        tier:       profile.tier,
        credits:    profile.credits,
        usageTotal: profile.usageTotal || 0,
        active:     profile.active,
        // nunca devolver a key em si na resposta
      }, 200, CH);
    }

    // ── GET /ibge/:codMunicipio — sem custo de crédito, resultado cacheado ─
    if (url.pathname.startsWith('/ibge/') && request.method === 'GET') {
      const cod = url.pathname.replace('/ibge/', '').trim();
      if (!/^\d{7}$/.test(cod)) return err('Código IBGE inválido (7 dígitos)', 400, CH);

      const cacheKey = `ibge:${cod}`;
      if (env.LABX_KV) {
        const cached = await env.LABX_KV.get(cacheKey).catch(() => null);
        if (cached) return ok({ ...JSON.parse(cached), cached: true }, 200, CH);
      }

      try {
        const [empR, pesR, popR] = await Promise.allSettled([
          fetchIBGEEmpresas(cod), fetchIBGEPessoal(cod), fetchIBGEPopulacao(cod),
        ]);
        const data = {
          codMunicipio: cod,
          nome:      popR.status === 'fulfilled' ? popR.value.nome : 'Município',
          populacao: popR.status === 'fulfilled' ? popR.value.pop  : 50000,
          empresas:  empR.status === 'fulfilled' ? empR.value : null,
          pessoal:   pesR.status === 'fulfilled' ? pesR.value : null,
          fonte: 'IBGE CEMPRE/SIDRA',
          capturedAt: new Date().toISOString(),
        };
        if (env.LABX_KV) await env.LABX_KV.put(cacheKey, JSON.stringify(data), { expirationTtl: TTL.IBGE });
        return ok(data, 200, CH);
      } catch (e) {
        return err('IBGE SIDRA indisponível: ' + e.message, 503, CH);
      }
    }

    // ── POST /calcular — consome 1 crédito ────────────────────────────────
    if (url.pathname === '/calcular' && request.method === 'POST') {
      // Verifica créditos antes de processar
      if (profile.credits <= 0) {
        return err(
          `Créditos esgotados. Tier atual: ${profile.tier}. Adquira mais créditos em labriolag.shop`,
          402, CH
        );
      }

      const body = await request.json().catch(() => ({}));
      const { renda = 0, cnpjs = 0, populacao = 50000, pib = 35, modo = 1.0, codMunicipio } = body;

      // Busca dados externos em paralelo
      let bcbData = {}, ibgeData = {};
      const [bcbRes, ibgeRes] = await Promise.allSettled([
        (async () => {
          const c = await env.LABX_KV.get('feed:macro:v6').catch(() => null);
          if (c) {
            const d = JSON.parse(c);
            return { selic: +d.selic.valor, ipca: +d.ipca.valor, ibcbr: +d.ibcbr.valor };
          }
          const [s, i, b] = await Promise.all([
            fetchBCB(BCB.SELIC), fetchBCB(BCB.IPCA), fetchBCB(BCB.IBCBR),
          ]);
          return { selic: +s.valor, ipca: +i.valor, ibcbr: +b.valor };
        })(),
        codMunicipio && /^\d{7}$/.test(codMunicipio) ? (async () => {
          const c = await env.LABX_KV.get(`ibge:${codMunicipio}`).catch(() => null);
          if (c) return JSON.parse(c);
          const [empR, pesR] = await Promise.allSettled([
            fetchIBGEEmpresas(codMunicipio), fetchIBGEPessoal(codMunicipio),
          ]);
          return {
            empresas: empR.status === 'fulfilled' ? empR.value : null,
            pessoal:  pesR.status === 'fulfilled' ? pesR.value : null,
          };
        })() : Promise.resolve({}),
      ]);

      if (bcbRes.status  === 'fulfilled') bcbData  = bcbRes.value;
      if (ibgeRes.status === 'fulfilled') ibgeData = ibgeRes.value;

      const resultado = calcularVetores({
        renda: Number(renda), cnpjs: Number(cnpjs),
        populacao: Number(populacao), pib: Number(pib),
        modo: Number(modo), bcbData, ibgeData,
      });

      // Debitar 1 crédito e registrar uso
      profile.credits    -= 1;
      profile.usageTotal  = (profile.usageTotal || 0) + 1;
      profile.lastUsedAt  = new Date().toISOString();
      await env.LABX_KV.put(`auth:${apiKey}`, JSON.stringify(profile), { expirationTtl: 60 * 60 * 24 * 365 });

      // Adicionar saldo restante na resposta
      resultado.creditsRestantes = profile.credits;

      return ok(resultado, 200, CH);
    }

    // ── POST /salvar ───────────────────────────────────────────────────────
    if (url.pathname === '/salvar' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}));
      const id   = body.id || `LAB-${Date.now().toString(36).toUpperCase()}`;
      // Namespaced por chave: cada usuário só acessa suas análises
      const kvKey = `analise:${apiKey}:${id}`;
      const record = { ...body, id, savedAt: new Date().toISOString() };
      await env.LABX_KV.put(kvKey, JSON.stringify(record), { expirationTtl: TTL.ANALISE });
      return ok({ ok: true, id }, 200, CH);
    }

    // ── GET /historico ────────────────────────────────────────────────────
    if (url.pathname === '/historico') {
      const list = await env.LABX_KV.list({ prefix: `analise:${apiKey}:` });
      const ids  = list.keys.map(k => k.name.replace(`analise:${apiKey}:`, ''));
      const meta = await Promise.all(
        ids.slice(0, 50).map(async id => {
          const raw = await env.LABX_KV.get(`analise:${apiKey}:${id}`).catch(() => null);
          if (!raw) return null;
          const d = JSON.parse(raw);
          return { id: d.id, name: d.name, timestamp: d.timestamp, results: d.results };
        })
      );
      return ok({ total: ids.length, analyses: meta.filter(Boolean) }, 200, CH);
    }

    // ── GET /analise/:id ──────────────────────────────────────────────────
    if (url.pathname.startsWith('/analise/') && request.method === 'GET') {
      const id  = url.pathname.replace('/analise/', '');
      const raw = await env.LABX_KV.get(`analise:${apiKey}:${id}`).catch(() => null);
      if (!raw) return err('Análise não encontrada', 404, CH);
      return ok(JSON.parse(raw), 200, CH);
    }

    // ── DELETE /analise/:id ───────────────────────────────────────────────
    if (url.pathname.startsWith('/analise/') && request.method === 'DELETE') {
      const id = url.pathname.replace('/analise/', '');
      await env.LABX_KV.delete(`analise:${apiKey}:${id}`);
      return ok({ ok: true, deleted: id }, 200, CH);
    }

    return err('Rota não encontrada', 404, CH);
  },
};
