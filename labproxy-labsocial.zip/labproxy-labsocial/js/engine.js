/**
 * engine.js — Loop principal, player, câmera
 * Labriolag OS · labriolag.shop
 */

window.Engine = (function () {
  const CANVAS   = document.getElementById('world-canvas');
  const CTX      = CANVAS.getContext('2d');
  const MINIMAP  = document.getElementById('minimap');
  const MM_CTX   = MINIMAP?.getContext('2d');

  const WORLD_W  = 4000;
  const WORLD_H  = 4000;
  const TILE     = 60;

  // Biomas por região
  const BIOMES = [
    { x: 0,    y: 0,    w: 2000, h: 2000, name: 'Praça Zero',     color: '#1a2a1a', accent: '#2d4a1a' },
    { x: 2000, y: 0,    w: 2000, h: 2000, name: 'Neon District',  color: '#0d1a2e', accent: '#1a2840' },
    { x: 0,    y: 2000, w: 2000, h: 2000, name: 'Market Square',  color: '#2a1a0e', accent: '#3a2a10' },
    { x: 2000, y: 2000, w: 2000, h: 2000, name: 'Finance Tower',  color: '#1a0e2e', accent: '#2e1040' },
  ];

  const POIS = [
    { x: 400,  y: 380,  icon: '🏛️', name: 'Hub Central',    type: 'hub',      color: '#D4AF37', r: 40 },
    { x: 800,  y: 600,  icon: '⚔️', name: 'Mission Board',   type: 'missions', color: '#FF2D78', r: 35 },
    { x: 300,  y: 900,  icon: '🏪', name: 'Marketplace',     type: 'shop',     color: '#00C8FF', r: 35 },
    { x: 1200, y: 400,  icon: '📊', name: 'LAB-X Terminal',  type: 'labx',     color: '#00FFB2', r: 35 },
    { x: 600,  y: 1100, icon: '👥', name: 'Guild Hall',      type: 'guild',    color: '#F7931A', r: 35 },
    { x: 1500, y: 700,  icon: '🏆', name: 'Ranking Arena',   type: 'ranking',  color: '#B36CFF', r: 35 },
    { x: 2200, y: 300,  icon: '🌆', name: 'Neon Gate',       type: 'district', color: '#00C8FF', r: 40 },
    { x: 300,  y: 2300, icon: '🛒', name: 'Market District', type: 'district', color: '#F7931A', r: 40 },
    { x: 2300, y: 2200, icon: '🏦', name: 'Finance Hub',     type: 'district', color: '#B36CFF', r: 40 },
  ];

  const DECORATIONS = []; // geradas proceduralmente no init

  let player = {
    x: 400, y: 380,
    r: 18, speed: 240,
    xp: 0, sats: 0,
    dir: 0, moving: false,
    trail: [],
  };

  let cam = { x: 0, y: 0 };
  let lastTime = 0;
  let currentZone = 'Praça Zero';

  // ── Geração Procedural ──────────────────────────────
  function _genDecorations() {
    const rng = (n) => Math.floor(Math.random() * n);
    const TREES  = ['🌲','🌳','🌴','🌵'];
    const ROCKS  = ['⬛','🪨'];
    const LIGHTS = ['💡','🔆'];
    for (let i = 0; i < 200; i++) {
      const x = rng(WORLD_W);
      const y = rng(WORLD_H);
      // Não gerar em cima de POIs
      const near = POIS.some(p => Math.hypot(p.x - x, p.y - y) < 120);
      if (near) continue;
      DECORATIONS.push({
        x, y,
        icon: [...TREES, ...ROCKS, ...LIGHTS][rng(TREES.length + ROCKS.length + LIGHTS.length)],
        size: 20 + rng(14),
        solid: rng(3) > 0, // maioria solid
      });
    }
  }

  // ── Resize ──────────────────────────────────────────
  function _resize() {
    CANVAS.width  = window.innerWidth;
    CANVAS.height = window.innerHeight;
  }

  // ── Câmera ──────────────────────────────────────────
  function _updateCam() {
    const W = CANVAS.width, H = CANVAS.height;
    cam.x = Math.max(0, Math.min(WORLD_W - W, player.x - W / 2));
    cam.y = Math.max(0, Math.min(WORLD_H - H, player.y - H / 2));
  }

  // ── Player Update ────────────────────────────────────
  function _updatePlayer(dt) {
    const joy = Joystick?.velocity || { x: 0, y: 0 };
    if (joy.x === 0 && joy.y === 0) { player.moving = false; return; }

    const nx = player.x + joy.x * player.speed * dt;
    const ny = player.y + joy.y * player.speed * dt;

    if (!Collision.check(nx, ny, player.r)) {
      player.x = Math.max(player.r, Math.min(WORLD_W - player.r, nx));
      player.y = Math.max(player.r, Math.min(WORLD_H - player.r, ny));
      player.moving = true;
      player.dir = Math.atan2(joy.y, joy.x);

      // Trail
      player.trail.push({ x: player.x, y: player.y, t: Date.now() });
      if (player.trail.length > 12) player.trail.shift();
    }
  }

  // ── Zone Detection ───────────────────────────────────
  function _detectZone() {
    for (const b of BIOMES) {
      if (player.x >= b.x && player.x < b.x + b.w &&
          player.y >= b.y && player.y < b.y + b.h) {
        if (currentZone !== b.name) {
          currentZone = b.name;
          const el = document.getElementById('hud-zone');
          if (el) el.textContent = 'ZYRO · ' + b.name;
        }
        return;
      }
    }
  }

  // ── Interaction Check ─────────────────────────────────
  function _checkInteraction() {
    let nearest = null, nearDist = Infinity;
    for (const p of POIS) {
      const d = Math.hypot(p.x - player.x, p.y - player.y);
      if (d < p.r + 60 && d < nearDist) { nearest = p; nearDist = d; }
    }
    const prompt = document.getElementById('interact-prompt');
    const label  = document.getElementById('interact-label');
    if (nearest && prompt) {
      prompt.classList.remove('hidden');
      if (label) label.textContent = `⬆ ${nearest.name}`;
      Engine._nearPOI = nearest;
    } else {
      prompt?.classList.add('hidden');
      Engine._nearPOI = null;
    }
  }

  // ── Draw World ───────────────────────────────────────
  function _drawWorld() {
    const W = CANVAS.width, H = CANVAS.height;

    // Background tiles
    for (const b of BIOMES) {
      const sx = b.x - cam.x, sy = b.y - cam.y;
      if (sx + b.w < 0 || sx > W || sy + b.h < 0 || sy > H) continue;
      CTX.fillStyle = b.color;
      CTX.fillRect(Math.max(0, sx), Math.max(0, sy),
        Math.min(b.w, W - Math.max(0, sx)),
        Math.min(b.h, H - Math.max(0, sy)));
    }

    // Grid
    CTX.strokeStyle = 'rgba(255,255,255,0.04)';
    CTX.lineWidth = 1;
    const startX = Math.floor(cam.x / TILE) * TILE;
    const startY = Math.floor(cam.y / TILE) * TILE;
    for (let gx = startX; gx < cam.x + W; gx += TILE) {
      CTX.beginPath(); CTX.moveTo(gx - cam.x, 0); CTX.lineTo(gx - cam.x, H); CTX.stroke();
    }
    for (let gy = startY; gy < cam.y + H; gy += TILE) {
      CTX.beginPath(); CTX.moveTo(0, gy - cam.y); CTX.lineTo(W, gy - cam.y); CTX.stroke();
    }
  }

  // ── Draw Decorations ──────────────────────────────────
  function _drawDecorations() {
    const W = CANVAS.width, H = CANVAS.height;
    for (const d of DECORATIONS) {
      const sx = d.x - cam.x, sy = d.y - cam.y;
      if (sx < -40 || sx > W + 40 || sy < -40 || sy > H + 40) continue;
      CTX.font = d.size + 'px serif';
      CTX.textAlign = 'center';
      CTX.textBaseline = 'middle';
      CTX.fillText(d.icon, sx, sy);
    }
  }

  // ── Draw POIs ─────────────────────────────────────────
  function _drawPOIs() {
    const W = CANVAS.width, H = CANVAS.height;
    const pulse = (Math.sin(Date.now() / 600) + 1) / 2;
    for (const p of POIS) {
      const sx = p.x - cam.x, sy = p.y - cam.y;
      if (sx < -80 || sx > W + 80 || sy < -80 || sy > H + 80) continue;

      // Glow ring
      CTX.beginPath();
      CTX.arc(sx, sy, p.r + 6 + pulse * 4, 0, Math.PI * 2);
      CTX.strokeStyle = p.color + '44';
      CTX.lineWidth = 1.5;
      CTX.stroke();

      // Circle
      CTX.beginPath();
      CTX.arc(sx, sy, p.r, 0, Math.PI * 2);
      CTX.fillStyle = p.color + '22';
      CTX.fill();
      CTX.strokeStyle = p.color + 'AA';
      CTX.lineWidth = 2;
      CTX.stroke();

      // Icon
      CTX.font = '22px serif';
      CTX.textAlign = 'center';
      CTX.textBaseline = 'middle';
      CTX.fillText(p.icon, sx, sy);

      // Label (on hover / nearby)
      const dist = Math.hypot(p.x - player.x, p.y - player.y);
      if (dist < 200) {
        CTX.font = "10px 'Share Tech Mono', monospace";
        CTX.fillStyle = p.color + 'CC';
        CTX.textBaseline = 'top';
        CTX.fillText(p.name, sx, sy + p.r + 6);
      }
    }
  }

  // ── Draw Player Trail ─────────────────────────────────
  function _drawTrail() {
    const now = Date.now();
    for (let i = 0; i < player.trail.length; i++) {
      const t = player.trail[i];
      const age = (now - t.t) / 600;
      if (age > 1) continue;
      const alpha = (1 - age) * 0.25;
      const size  = player.r * 0.5 * (1 - age);
      CTX.beginPath();
      CTX.arc(t.x - cam.x, t.y - cam.y, size, 0, Math.PI * 2);
      CTX.fillStyle = `rgba(0,255,178,${alpha})`;
      CTX.fill();
    }
  }

  // ── Draw Player ───────────────────────────────────────
  function _drawPlayer() {
    const sx = player.x - cam.x;
    const sy = player.y - cam.y;
    const p = Auth.getProfile();
    const ava = p.avatar || '🧑‍💼';

    // Shadow
    CTX.beginPath();
    CTX.ellipse(sx, sy + player.r + 3, player.r * 0.7, player.r * 0.25, 0, 0, Math.PI * 2);
    CTX.fillStyle = 'rgba(0,0,0,0.35)';
    CTX.fill();

    // Glow
    const gradient = CTX.createRadialGradient(sx, sy, 0, sx, sy, player.r * 1.4);
    gradient.addColorStop(0, 'rgba(0,255,178,0.3)');
    gradient.addColorStop(1, 'rgba(0,255,178,0)');
    CTX.beginPath();
    CTX.arc(sx, sy, player.r * 1.4, 0, Math.PI * 2);
    CTX.fillStyle = gradient;
    CTX.fill();

    // Body circle
    CTX.beginPath();
    CTX.arc(sx, sy, player.r, 0, Math.PI * 2);
    CTX.fillStyle = '#0E1220';
    CTX.fill();
    CTX.strokeStyle = 'rgba(0,255,178,0.8)';
    CTX.lineWidth = 2;
    CTX.stroke();

    // Avatar emoji
    CTX.font = `${player.r * 1.1}px serif`;
    CTX.textAlign = 'center';
    CTX.textBaseline = 'middle';
    CTX.fillText(ava, sx, sy);

    // Direction indicator
    if (player.moving) {
      const dx = Math.cos(player.dir) * (player.r + 10);
      const dy = Math.sin(player.dir) * (player.r + 10);
      CTX.beginPath();
      CTX.arc(sx + dx, sy + dy, 3, 0, Math.PI * 2);
      CTX.fillStyle = 'rgba(0,255,178,0.8)';
      CTX.fill();
    }

    // Name
    const name = (p.name || 'YOU').toUpperCase();
    CTX.font = "8px 'Share Tech Mono', monospace";
    CTX.fillStyle = 'rgba(212,175,55,0.7)';
    CTX.textAlign = 'center';
    CTX.textBaseline = 'bottom';
    CTX.fillText(name, sx, sy - player.r - 3);
  }

  // ── Draw Minimap ──────────────────────────────────────
  function _drawMinimap() {
    if (!MM_CTX || !MINIMAP) return;
    const MW = MINIMAP.width, MH = MINIMAP.height;
    MM_CTX.clearRect(0, 0, MW, MH);

    // BG
    MM_CTX.fillStyle = 'rgba(5,7,10,0.95)';
    MM_CTX.fillRect(0, 0, MW, MH);

    // Scale
    const scaleX = MW / WORLD_W;
    const scaleY = MH / WORLD_H;

    // Biomes
    for (const b of BIOMES) {
      MM_CTX.fillStyle = b.accent + '44';
      MM_CTX.fillRect(b.x * scaleX, b.y * scaleY, b.w * scaleX, b.h * scaleY);
    }

    // POIs
    for (const p of POIS) {
      MM_CTX.beginPath();
      MM_CTX.arc(p.x * scaleX, p.y * scaleY, 2.5, 0, Math.PI * 2);
      MM_CTX.fillStyle = p.color + 'CC';
      MM_CTX.fill();
    }

    // Player
    MM_CTX.beginPath();
    MM_CTX.arc(player.x * scaleX, player.y * scaleY, 3.5, 0, Math.PI * 2);
    MM_CTX.fillStyle = '#00FFB2';
    MM_CTX.fill();
    MM_CTX.strokeStyle = '#fff';
    MM_CTX.lineWidth = 1;
    MM_CTX.stroke();

    // Viewport rect
    const vx = cam.x * scaleX, vy = cam.y * scaleY;
    const vw = CANVAS.width * scaleX, vh = CANVAS.height * scaleY;
    MM_CTX.strokeStyle = 'rgba(212,175,55,0.25)';
    MM_CTX.lineWidth = 0.8;
    MM_CTX.strokeRect(vx, vy, vw, vh);

    // Border
    MM_CTX.strokeStyle = 'rgba(212,175,55,0.2)';
    MM_CTX.lineWidth = 1;
    MM_CTX.strokeRect(0, 0, MW, MH);
  }

  // ── Main Loop ─────────────────────────────────────────
  function _loop(ts) {
    const dt = Math.min((ts - lastTime) / 1000, 0.05);
    lastTime = ts;

    _updatePlayer(dt);
    _updateCam();
    _detectZone();
    _checkInteraction();

    CTX.clearRect(0, 0, CANVAS.width, CANVAS.height);
    _drawWorld();
    _drawDecorations();
    _drawPOIs();
    _drawTrail();
    _drawPlayer();
    _drawMinimap();

    requestAnimationFrame(_loop);
  }

  // ── Button Actions ────────────────────────────────────
  function _bindButtons() {
    document.getElementById('btn-a')?.addEventListener('click', () => {
      if (Engine._nearPOI) UI.openPOI(Engine._nearPOI);
    });
    document.getElementById('btn-b')?.addEventListener('click', () => UI.togglePanel('mission-panel'));
    document.getElementById('btn-c')?.addEventListener('click', () => Missions.showPanel());
    document.getElementById('btn-d')?.addEventListener('click', () => window.location.href = 'labx.html');
  }

  function init() {
    _resize();
    window.addEventListener('resize', _resize);
    _genDecorations();
    Collision.buildMap(DECORATIONS.filter(d => d.solid), POIS);
    _bindButtons();

    // Update HUD
    const p = Auth.getProfile();
    const hXP  = document.getElementById('hud-xp');
    const hCR  = document.getElementById('hud-credits');
    if (hXP)  hXP.textContent  = player.xp;
    if (hCR)  hCR.textContent  = p.credits ?? '—';

    lastTime = performance.now();
    requestAnimationFrame(_loop);
  }

  function addXP(amount) {
    player.xp += amount;
    const el = document.getElementById('hud-xp');
    if (el) el.textContent = player.xp;
  }

  return { init, addXP, player, POIS, WORLD_W, WORLD_H };
})();

// ── UI Helper ─────────────────────────────────────────
window.UI = {
  openPOI(poi) {
    const panel = document.getElementById('interact-panel');
    const title = document.getElementById('ip-title');
    const content = document.getElementById('ip-content');
    if (!panel || !title || !content) return;

    title.textContent = poi.icon + ' ' + poi.name;

    const actions = {
      hub:      `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Bem-vindo ao Hub Central da LabCity.</p><a href="index.html" class="mc-btn launch">🌐 Portal</a>`,
      missions: `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Quadro de missões ativas.</p><button class="mc-btn launch" onclick="Missions.showPanel();UI.closePanel('interact-panel')">⚔️ Ver Missões</button>`,
      shop:     `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Marketplace de itens e distritos.</p><a href="shop.html" class="mc-btn launch">🏪 Ir à Loja</a>`,
      labx:     `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Terminal de análise LAB-X 16D.</p><a href="labx.html" class="mc-btn launch">📊 Abrir LAB-X</a>`,
      guild:    `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Guild Hall — membros ativos.</p><button class="mc-btn launch" onclick="UI.closePanel('interact-panel')">👥 Ver Guilda</button>`,
      ranking:  `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Ranking geral da LabCity.</p><button class="mc-btn launch" onclick="UI.closePanel('interact-panel')">🏆 Ver Ranking</button>`,
      district: `<p style="color:rgba(255,255,255,.5);font-size:11px;margin-bottom:12px">Distrito disponível para exploração.</p><button class="mc-btn launch" onclick="UI.closePanel('interact-panel')">🗺️ Explorar</button>`,
    };
    content.innerHTML = `<div style="padding:14px 16px;display:flex;flex-direction:column;gap:10px">${actions[poi.type] || ''}</div>`;
    panel.classList.remove('hidden');
  },

  closePanel(id) {
    document.getElementById(id)?.classList.add('hidden');
  },

  togglePanel(id) {
    const el = document.getElementById(id);
    if (el) el.classList.toggle('hidden');
  },
};
