/**
 * events.js — Eventos dinâmicos do mundo
 * Labriolag OS · labriolag.shop
 */

window.Events = (function () {
  const EVENTS = [
    { id:'ev1', icon:'⚡', name:'SURGE DE XP',    desc:'+50% XP por 5 minutos!',     duration: 5 * 60 },
    { id:'ev2', icon:'💰', name:'CHUVA DE SATS',  desc:'Colete Sats espalhados!',    duration: 3 * 60 },
    { id:'ev3', icon:'🔥', name:'RAID ESPECIAL',   desc:'Boss apareceu na arena!',    duration: 10 * 60 },
    { id:'ev4', icon:'🌟', name:'EVENTO RARO',     desc:'Item único disponível.',     duration: 2 * 60 },
  ];

  let activeEvent = null;
  let timer = null;

  function start() {
    // Dispara evento aleatório a cada 2-5 minutos
    _schedule();
  }

  function _schedule() {
    const delay = (120 + Math.random() * 180) * 1000;
    setTimeout(_triggerRandom, delay);
  }

  function _triggerRandom() {
    if (activeEvent) { _schedule(); return; }
    activeEvent = { ...EVENTS[Math.floor(Math.random() * EVENTS.length)] };
    _showEvent();
    timer = setTimeout(_endEvent, activeEvent.duration * 1000);
    _schedule();
  }

  function _showEvent() {
    if (!activeEvent) return;
    const msg = document.getElementById('msg-overlay');
    if (msg) {
      msg.textContent = `${activeEvent.icon} ${activeEvent.name} — ${activeEvent.desc}`;
      msg.classList.remove('hidden');
      setTimeout(() => msg.classList.add('hidden'), 4000);
    }
    if (typeof toast !== 'undefined') toast(`${activeEvent.icon} ${activeEvent.name}!`, 'ok');
  }

  function _endEvent() {
    activeEvent = null;
    clearTimeout(timer);
  }

  function getActive() { return activeEvent; }

  return { start, getActive };
})();


/**
 * npc.js — NPCs do mundo
 * Labriolag OS · labriolag.shop
 */

window.NPC = (function () {
  const NPCS_DEF = [
    { id:'npc1', x:500,  y:500,  icon:'🧙', name:'MAGO',    speed:30,  dialog:'Bem-vindo à LabCity, viajante!',    r:14 },
    { id:'npc2', x:900,  y:400,  icon:'🛒', name:'TRADER',  speed:20,  dialog:'Tenho itens raros no estoque.',     r:14 },
    { id:'npc3', x:700,  y:800,  icon:'🕵️', name:'AGENTE',  speed:40,  dialog:'Tenho informações sobre o Setor 7.',r:14 },
    { id:'npc4', x:1100, y:600,  icon:'🤖', name:'BOT',     speed:0,   dialog:'CONEXÃO LAB-X ATIVA. ANALISANDO...', r:14 },
    { id:'npc5', x:350,  y:700,  icon:'👷', name:'WORKER',  speed:50,  dialog:'Entrega #47 prestes a sair.',        r:14 },
  ];

  let npcs = NPCS_DEF.map(n => ({ ...n, vx: (Math.random() - .5), vy: (Math.random() - .5) }));

  function spawn() {
    // NPCs já definidos; movimento acontece no tick do engine
    setInterval(_tick, 100);
  }

  function _tick() {
    for (const n of npcs) {
      if (!n.speed) continue;
      n.x += n.vx * (n.speed / 10) * 0.5;
      n.y += n.vy * (n.speed / 10) * 0.5;
      // Bounce nos limites
      if (n.x < 100 || n.x > 1800) n.vx *= -1;
      if (n.y < 100 || n.y > 1800) n.vy *= -1;
    }
  }

  function getAll()  { return npcs; }
  function findNear(px, py, radius) {
    return npcs.filter(n => Math.hypot(n.x - px, n.y - py) < radius);
  }

  return { spawn, getAll, findNear };
})();


/**
 * gps.js — Integração GPS Real
 * Labriolag OS · labriolag.shop
 *
 * Mapeia coordenadas GPS reais para o mundo virtual.
 * Opcional — o jogo funciona sem GPS.
 */

window.GPS = (function () {
  let enabled  = false;
  let watching = null;

  // Centro de referência (São Paulo - pode ser configurado)
  const REF_LAT = -23.5505;
  const REF_LNG = -46.6333;
  const SCALE   = 80000; // graus → pixels do mundo

  function init() {
    if (!navigator.geolocation) return;

    // Pergunta permissão de forma não bloqueante
    navigator.geolocation.getCurrentPosition(
      pos => {
        enabled = true;
        _updatePosition(pos);
        _startWatch();
        if (typeof toast !== 'undefined') toast('📍 GPS ativo', 'ok');
      },
      () => { /* sem GPS — modo manual */ },
      { timeout: 8000, maximumAge: 60000 }
    );
  }

  function _startWatch() {
    watching = navigator.geolocation.watchPosition(
      _updatePosition,
      null,
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 }
    );
  }

  function _updatePosition(pos) {
    if (!Engine?.player) return;
    const dLat = pos.coords.latitude  - REF_LAT;
    const dLng = pos.coords.longitude - REF_LNG;
    const wx = Engine.WORLD_W / 2 + dLng * SCALE;
    const wy = Engine.WORLD_H / 2 - dLat * SCALE;
    // Suaviza movimento
    Engine.player.x = Engine.player.x * 0.7 + wx * 0.3;
    Engine.player.y = Engine.player.y * 0.7 + wy * 0.3;
  }

  function stop() {
    if (watching !== null) navigator.geolocation.clearWatch(watching);
    enabled = false;
  }

  function isEnabled() { return enabled; }

  return { init, stop, isEnabled };
})();
