/**
 * gps.js — Integração GPS Real → Mundo Virtual
 * Labriolag OS · labriolag.shop
 *
 * Mapeia coordenadas GPS reais para o canvas do mundo.
 * Totalmente opcional — o jogo funciona sem permissão de GPS.
 */

window.GPS = (function () {
  let enabled  = false;
  let watchId  = null;

  // Ponto de referência central (São Paulo).
  // Altere para o centro da sua cidade-alvo.
  const REF_LAT =  -23.5505;
  const REF_LNG =  -46.6333;

  // Escala: quantos pixels do mundo por grau de lat/lng
  // 80 000 ≈ ~8 km de raio cobre o mundo inteiro
  const SCALE   = 80000;

  function init() {
    if (!navigator.geolocation) return;

    navigator.geolocation.getCurrentPosition(
      pos => {
        enabled = true;
        _apply(pos);
        _watch();
        if (typeof toast === 'function') toast('📍 GPS ativo', 'ok');
      },
      () => { /* sem permissão — modo manual, sem aviso */ },
      { timeout: 8000, maximumAge: 60000 }
    );
  }

  function _watch() {
    watchId = navigator.geolocation.watchPosition(
      _apply,
      null,
      { enableHighAccuracy: true, maximumAge: 4000, timeout: 10000 }
    );
  }

  function _apply(pos) {
    if (!window.Engine?.player) return;
    const dLat = pos.coords.latitude  - REF_LAT;
    const dLng = pos.coords.longitude - REF_LNG;

    const wx = Engine.WORLD_W / 2 + dLng * SCALE;
    const wy = Engine.WORLD_H / 2 - dLat * SCALE;

    // Clamp dentro do mundo
    const px = Math.max(20, Math.min(Engine.WORLD_W - 20, wx));
    const py = Math.max(20, Math.min(Engine.WORLD_H - 20, wy));

    // Lerp suave para evitar teleport brusco
    Engine.player.x = Engine.player.x * 0.75 + px * 0.25;
    Engine.player.y = Engine.player.y * 0.75 + py * 0.25;
  }

  function stop() {
    if (watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      watchId = null;
    }
    enabled = false;
  }

  function isEnabled() { return enabled; }

  return { init, stop, isEnabled };
})();
