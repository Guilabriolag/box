/**
 * auth.js — Autenticação via API Key
 * Labriolag OS · labriolag.shop
 */

window.Auth = (function () {
  const KEY_STORAGE = 'labx_api_key';
  const PROFILE_STORAGE = 'labx_profile';

  let _apiKey = null;
  let _profile = {};

  function getKey()      { return _apiKey || localStorage.getItem(KEY_STORAGE) || ''; }
  function getProfile()  { try { return JSON.parse(localStorage.getItem(PROFILE_STORAGE) || '{}'); } catch { return {}; } }
  function getCredits()  { return _profile.credits ?? getProfile().credits ?? '—'; }
  function setCredits(v) { _profile.credits = v; const p = getProfile(); p.credits = v; localStorage.setItem(PROFILE_STORAGE, JSON.stringify(p)); }

  function updateProfile(data) {
    const p = getProfile();
    Object.assign(p, data);
    _profile = p;
    localStorage.setItem(PROFILE_STORAGE, JSON.stringify(p));
  }

  function saveKey(key) {
    _apiKey = key;
    localStorage.setItem(KEY_STORAGE, key);
  }

  function clearAuth() {
    _apiKey = null;
    _profile = {};
    localStorage.removeItem(KEY_STORAGE);
    localStorage.removeItem(PROFILE_STORAGE);
  }

  async function login() {
    const input = document.getElementById('api-key-input');
    if (!input) return;
    const key = input.value.trim();
    if (!key.startsWith('sk_lab_')) {
      document.getElementById('ag-error')?.classList.remove('hidden');
      return;
    }

    // Valida com /me
    const btn = input.nextElementSibling;
    if (btn) { btn.textContent = '...'; btn.disabled = true; }

    try {
      const r = await fetch(window.API?.BASE + '/me', {
        headers: { 'X-API-Key': key }
      });
      if (!r.ok) throw new Error('invalid');
      const data = await r.json();

      saveKey(key);
      _profile = { ...getProfile(), ...data, apiKey: key };
      localStorage.setItem(PROFILE_STORAGE, JSON.stringify(_profile));

      document.getElementById('ag-error')?.classList.add('hidden');
      _showMenu(data);
    } catch {
      document.getElementById('ag-error')?.classList.remove('hidden');
    } finally {
      if (btn) { btn.textContent = 'ENTRAR'; btn.disabled = false; }
    }
  }

  function logout() {
    clearAuth();
    window.location.href = 'index.html';
  }

  function _showMenu(data) {
    document.getElementById('auth-gate')?.classList.add('hidden');
    const menu = document.getElementById('main-menu');
    if (menu) {
      menu.classList.remove('hidden');
      // Preenche dados
      const p = getProfile();
      document.getElementById('pc-name').textContent     = (p.name || p.owner || 'OPERADOR').toUpperCase();
      document.getElementById('pc-tier').textContent     = (data.tier || 'starter').toUpperCase();
      document.getElementById('pc-credits').textContent  = data.credits ?? '—';
      document.getElementById('pc-avatar').textContent   = p.avatar || '🧑‍💼';

      // Oculta admin link se não for admin
      const adminLink = document.getElementById('admin-link');
      if (adminLink && data.tier !== 'enterprise') {
        // Mantém visível para enterprise; esconde para outros (opcional)
      }
    }
  }

  function init() {
    const key = getKey();
    if (!key) return; // Mostra gate normalmente

    // Auto-login se já tem chave
    const stored = getProfile();
    if (stored.credits !== undefined) {
      _apiKey = key;
      _profile = stored;
      _showMenu(stored);
      // Busca créditos frescos em background
      fetch((window.API?.BASE || '') + '/me', { headers: { 'X-API-Key': key } })
        .then(r => r.json())
        .then(d => {
          setCredits(d.credits);
          const el = document.getElementById('pc-credits');
          if (el) el.textContent = d.credits;
        })
        .catch(() => {});
      return;
    }

    // Chave salva mas sem cache → tenta logar
    const input = document.getElementById('api-key-input');
    if (input) input.value = key;
    login();
  }

  function requireAuth(cb) {
    const key = getKey();
    if (!key) {
      window.location.href = 'index.html';
      return;
    }
    _apiKey = key;
    _profile = getProfile();
    cb();
  }

  return { init, login, logout, getKey, getProfile, getCredits, setCredits, updateProfile, requireAuth };
})();

// ── Toast global (disponível em todas as páginas) ─────
let _toastTimer;
window.toast = function(msg, type = '') {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className   = 'vis ' + type;
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => t.className = '', 3200);
};
