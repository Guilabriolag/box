/**
 * economy.js — LAB Token / Sats / XP
 * Labriolag OS · labriolag.shop
 */

window.Economy = (function () {
  const KEY_SATS = 'labx_sats';
  const KEY_XP   = 'labx_xp';

  let sats = 0;
  let xp   = 0;

  function init() {
    sats = parseInt(localStorage.getItem(KEY_SATS) || '1000');
    xp   = parseInt(localStorage.getItem(KEY_XP)   || '0');
    _updateHUD();
  }

  function getSats() { return sats; }
  function getXP()   { return xp; }

  function earn(amount, type = 'sats') {
    if (type === 'xp') {
      xp += amount;
      localStorage.setItem(KEY_XP, xp);
      Engine?.addXP(amount);
    } else {
      sats += amount;
      localStorage.setItem(KEY_SATS, sats);
    }
    _updateHUD();
  }

  function spend(amount) {
    if (sats < amount) return false;
    sats -= amount;
    localStorage.setItem(KEY_SATS, sats);
    _updateHUD();
    return true;
  }

  function _updateHUD() {
    const el = document.getElementById('hud-xp');
    if (el) el.textContent = xp;
  }

  return { init, getSats, getXP, earn, spend };
})();
