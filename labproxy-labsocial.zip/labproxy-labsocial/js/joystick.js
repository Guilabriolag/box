/**
 * joystick.js — Controle touch e teclado
 * Labriolag OS · labriolag.shop
 */

window.Joystick = (function () {
  const joystick = document.getElementById('joystick');
  const stick    = document.getElementById('stick');
  if (!joystick || !stick) return { velocity: { x: 0, y: 0 } };

  let velocity = { x: 0, y: 0 };
  let active   = false;
  let origin   = { x: 0, y: 0 };
  let touchId  = null;

  const RADIUS = joystick.offsetWidth / 2 || 60;
  const DEADZONE = 0.08;

  function _setStick(dx, dy) {
    const dist  = Math.hypot(dx, dy);
    const clamp = Math.min(dist, RADIUS);
    const angle = Math.atan2(dy, dx);
    const cx = Math.cos(angle) * clamp;
    const cy = Math.sin(angle) * clamp;
    stick.style.transform = `translate(calc(-50% + ${cx}px), calc(-50% + ${cy}px))`;
    const norm = clamp / RADIUS;
    const nx = Math.cos(angle) * norm;
    const ny = Math.sin(angle) * norm;
    velocity.x = Math.abs(nx) > DEADZONE ? nx : 0;
    velocity.y = Math.abs(ny) > DEADZONE ? ny : 0;
  }

  function _reset() {
    active = false; touchId = null;
    stick.style.transform = 'translate(-50%,-50%)';
    velocity.x = 0; velocity.y = 0;
  }

  // Touch events
  joystick.addEventListener('touchstart', e => {
    e.preventDefault();
    if (active) return;
    const t = e.changedTouches[0];
    touchId = t.identifier;
    const rect = joystick.getBoundingClientRect();
    origin = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    active = true;
  }, { passive: false });

  document.addEventListener('touchmove', e => {
    if (!active) return;
    e.preventDefault();
    for (const t of e.changedTouches) {
      if (t.identifier === touchId) {
        _setStick(t.clientX - origin.x, t.clientY - origin.y);
        break;
      }
    }
  }, { passive: false });

  document.addEventListener('touchend', e => {
    for (const t of e.changedTouches) {
      if (t.identifier === touchId) { _reset(); break; }
    }
  });

  // Keyboard fallback (WASD / arrows)
  const keys = {};
  document.addEventListener('keydown', e => { keys[e.key] = true; _handleKeys(); });
  document.addEventListener('keyup',   e => { keys[e.key] = false; _handleKeys(); });

  function _handleKeys() {
    const L = keys['ArrowLeft']  || keys['a'] || keys['A'];
    const R = keys['ArrowRight'] || keys['d'] || keys['D'];
    const U = keys['ArrowUp']    || keys['w'] || keys['W'];
    const D = keys['ArrowDown']  || keys['s'] || keys['S'];
    velocity.x = L ? -1 : R ? 1 : 0;
    velocity.y = U ? -1 : D ? 1 : 0;
    // Normalize diagonal
    if (velocity.x && velocity.y) {
      const f = 1 / Math.SQRT2;
      velocity.x *= f; velocity.y *= f;
    }
  }

  return { velocity };
})();
