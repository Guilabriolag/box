/**
 * multiplayer.js — Stub de Multiplayer via WebSocket
 * Labriolag OS · labriolag.shop
 *
 * Estrutura pronta para conectar a um Cloudflare Durable Object
 * ou qualquer servidor WebSocket (Supabase Realtime, Ably, Partykit…).
 *
 * Para ativar: substitua WS_URL pelo endpoint real e chame Multiplayer.connect().
 */

window.Multiplayer = (function () {
  const WS_URL = 'wss://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/ws'; // ajuste após deploy

  let socket    = null;
  let connected = false;
  let peers     = {};   // { playerId: { x, y, avatar, name } }

  function connect() {
    if (connected) return;

    try {
      socket = new WebSocket(WS_URL + '?key=' + (Auth?.getKey() || ''));

      socket.onopen = () => {
        connected = true;
        if (typeof toast === 'function') toast('🌐 Multiplayer conectado', 'ok');
        _broadcast({ type: 'JOIN', ...Auth?.getProfile() });
      };

      socket.onmessage = ({ data }) => {
        try {
          const msg = JSON.parse(data);
          _handleMessage(msg);
        } catch {}
      };

      socket.onclose = () => {
        connected = false;
        peers = {};
        setTimeout(connect, 5000); // reconnect
      };

      socket.onerror = () => {
        // Silencioso — multiplayer é opcional
        socket?.close();
      };

    } catch {
      // WebSocket não disponível — modo single player
    }
  }

  function disconnect() {
    socket?.close();
    connected = false;
    peers = {};
  }

  // Envia posição do player local a cada frame (throttle interno)
  let _lastSend = 0;
  function sendPosition(x, y) {
    const now = Date.now();
    if (!connected || now - _lastSend < 100) return; // 10 fps max
    _lastSend = now;
    _broadcast({ type: 'MOVE', x: Math.round(x), y: Math.round(y) });
  }

  function _broadcast(obj) {
    if (socket?.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(obj));
    }
  }

  function _handleMessage(msg) {
    switch (msg.type) {
      case 'MOVE':
        if (msg.id) peers[msg.id] = { ...peers[msg.id], x: msg.x, y: msg.y };
        break;
      case 'JOIN':
        if (msg.id) peers[msg.id] = { avatar: msg.avatar || '🧑‍💼', name: msg.name || '?', x: 400, y: 400 };
        break;
      case 'LEAVE':
        if (msg.id) delete peers[msg.id];
        break;
      case 'MISSION_COMPLETE':
        if (typeof toast === 'function') toast(`🏆 ${msg.name} completou ${msg.mission}!`, 'ok');
        break;
    }
  }

  function getPeers() { return peers; }
  function isConnected() { return connected; }

  return { connect, disconnect, sendPosition, getPeers, isConnected };
})();
