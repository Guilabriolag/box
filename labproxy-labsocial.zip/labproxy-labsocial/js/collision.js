/**
 * collision.js — Sistema de colisão AABB + Circle
 * Labriolag OS · labriolag.shop
 */

window.Collision = (function () {
  let colliders = []; // { x, y, r } circles

  function buildMap(decorations, pois) {
    colliders = [];
    // Decorações sólidas
    for (const d of decorations) {
      colliders.push({ x: d.x, y: d.y, r: 14 });
    }
    // Bordas do mundo
    // Serão verificadas inline no engine
  }

  function check(nx, ny, pr) {
    // Limites do mundo
    if (nx - pr < 0 || nx + pr > Engine.WORLD_W) return true;
    if (ny - pr < 0 || ny + pr > Engine.WORLD_H) return true;

    // Colisão com decorações
    for (const c of colliders) {
      const dist = Math.hypot(c.x - nx, c.y - ny);
      if (dist < c.r + pr - 4) return true;
    }
    return false;
  }

  return { buildMap, check };
})();
