/**
 * npc.js — NPCs do mundo
 * Labriolag OS · labriolag.shop
 */

window.NPC = (function () {
  const NPCS_DEF = [
    { id:'npc1', x:500,  y:500,  icon:'🧙', name:'MAGO',   speed:30, dialog:'Bem-vindo à LabCity, viajante!',      r:14 },
    { id:'npc2', x:900,  y:400,  icon:'🛒', name:'TRADER', speed:20, dialog:'Tenho itens raros no estoque.',       r:14 },
    { id:'npc3', x:700,  y:800,  icon:'🕵️', name:'AGENTE', speed:40, dialog:'Informações sobre o Setor 7.',        r:14 },
    { id:'npc4', x:1100, y:600,  icon:'🤖', name:'BOT',    speed:0,  dialog:'CONEXÃO LAB-X ATIVA. ANALISANDO...', r:14 },
    { id:'npc5', x:350,  y:700,  icon:'👷', name:'WORKER', speed:50, dialog:'Entrega #47 prestes a sair.',         r:14 },
  ];

  let npcs = NPCS_DEF.map(n => ({
    ...n,
    vx: (Math.random() - 0.5) * 2,
    vy: (Math.random() - 0.5) * 2,
  }));

  function spawn() {
    setInterval(_tick, 120);
  }

  function _tick() {
    for (const n of npcs) {
      if (!n.speed) continue;
      n.x += n.vx * (n.speed / 10) * 0.5;
      n.y += n.vy * (n.speed / 10) * 0.5;
      if (n.x < 100 || n.x > 1800) n.vx *= -1;
      if (n.y < 100 || n.y > 1800) n.vy *= -1;
    }
  }

  function getAll()          { return npcs; }
  function findNear(px, py, r) {
    return npcs.filter(n => Math.hypot(n.x - px, n.y - py) < r);
  }

  return { spawn, getAll, findNear };
})();
