/**
 * api.js — Cliente para o LAB-X Worker v6
 * Labriolag OS · labriolag.shop
 *
 * Todos os métodos retornam null em caso de erro
 * e disparam toast automático.
 */

window.API = (function () {
  // Substitua após o deploy pelo URL real do worker
  const BASE = 'https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev';

  function _key() { return Auth.getKey(); }

  function _headers(extra = {}) {
    return {
      'Content-Type': 'application/json',
      'X-API-Key': _key(),
      ...extra,
    };
  }

  async function _get(path) {
    try {
      const r = await fetch(BASE + path, { headers: _headers() });
      if (!r.ok) {
        const e = await r.json().catch(() => ({ error: r.statusText }));
        toast(e.error || 'Erro ' + r.status, 'err');
        return null;
      }
      return r.json();
    } catch (err) {
      toast('Sem conexão com o servidor', 'err');
      return null;
    }
  }

  async function _post(path, body) {
    try {
      const r = await fetch(BASE + path, {
        method: 'POST',
        headers: _headers(),
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        const e = await r.json().catch(() => ({ error: r.statusText }));
        toast(e.error || 'Erro ' + r.status, 'err');
        return null;
      }
      return r.json();
    } catch (err) {
      toast('Sem conexão com o servidor', 'err');
      return null;
    }
  }

  async function _delete(path) {
    try {
      const r = await fetch(BASE + path, { method: 'DELETE', headers: _headers() });
      return r.json().catch(() => null);
    } catch { return null; }
  }

  // ── Endpoints Públicos ───────────────────────────────
  async function getFeed() {
    try {
      const r = await fetch(BASE + '/feed');
      if (!r.ok) return null;
      return r.json();
    } catch { return null; }
  }

  async function getHealth() {
    try {
      const r = await fetch(BASE + '/health');
      return r.json();
    } catch { return null; }
  }

  // ── Endpoints Autenticados ───────────────────────────
  async function getMe()              { return _get('/me'); }
  async function getIBGE(cod)         { return _get('/ibge/' + cod); }
  async function calcular(body)       { return _post('/calcular', body); }
  async function salvar(body)         { return _post('/salvar', body); }
  async function historico()          { return _get('/historico'); }
  async function getAnalise(id)       { return _get('/analise/' + id); }
  async function deleteAnalise(id)    { return _delete('/analise/' + id); }

  return {
    BASE,
    getFeed, getHealth,
    getMe, getIBGE, calcular, salvar, historico, getAnalise, deleteAnalise,
  };
})();
