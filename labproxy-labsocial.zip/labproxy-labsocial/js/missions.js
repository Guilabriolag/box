/**
 * missions.js — Sistema de Missões
 * Labriolag OS · labriolag.shop
 */

window.Missions = (function () {
  const POOL = [
    { id:'m1', icon:'📦', name:'ENTREGA NEON',     desc:'Entregue o pacote ao Distrito Sul.',       xp:120, sats:200, time:20, type:'delivery', target:{ x:800, y:600 } },
    { id:'m2', icon:'⚔️', name:'RAID ALPHA',        desc:'Complete o raid no Setor 7.',              xp:200, sats:350, time:30, type:'raid',     target:{ x:1500, y:700 } },
    { id:'m3', icon:'📍', name:'CHECK-IN STADIUM',  desc:'Faça check-in no Estádio Central.',        xp:80,  sats:120, time:10, type:'checkin',  target:{ x:300, y:900 } },
    { id:'m4', icon:'💎', name:'DROP ESPECIAL',      desc:'Colete o item raro no Estádio Neon.',     xp:300, sats:500, time:0,  type:'drop',     target:{ x:1200, y:400 } },
    { id:'m5', icon:'🔥', name:'SPRINT TOTAL',       desc:'Alcance velocidade máxima por 60s.',      xp:60,  sats:100, time:5,  type:'sprint',   target:null },
    { id:'m6', icon:'🛡️', name:'PATRULHA GUILDA',    desc:'Proteja o HUB Central durante 20min.',   xp:150, sats:280, time:20, type:'raid',     target:{ x:400, y:380 } },
  ];

  let active = [...POOL.slice(0, 2)];

  function load() {
    const saved = localStorage.getItem('labx_missions');
    if (saved) {
      try { active = JSON.parse(saved); } catch {}
    }
    _renderPanel();
  }

  function _save() {
    localStorage.setItem('labx_missions', JSON.stringify(active));
  }

  function showPanel() {
    const panel = document.getElementById('mission-panel');
    if (panel) {
      panel.classList.remove('hidden');
      _renderPanel();
    }
  }

  function _renderPanel() {
    const list = document.getElementById('mission-list');
    if (!list) return;
    if (!active.length) {
      list.innerHTML = '<div style="padding:12px;font-family:Share Tech Mono,monospace;font-size:10px;color:#333">Nenhuma missão ativa.</div>';
      return;
    }
    list.innerHTML = active.map((m, i) => `
      <div style="padding:12px 16px;border-bottom:1px solid rgba(255,255,255,.04)">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
          <span style="font-size:18px">${m.icon}</span>
          <span style="font-family:'Press Start 2P',monospace;font-size:7px;color:#fff">${m.name}</span>
        </div>
        <div style="font-size:10px;color:rgba(255,255,255,.4);margin-bottom:8px;line-height:1.5">${m.desc}</div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">
          <span style="font-family:'Share Tech Mono',monospace;font-size:9px;padding:2px 7px;border-radius:4px;background:rgba(179,108,255,.12);color:#B36CFF;border:1px solid rgba(179,108,255,.2)">+${m.xp} XP</span>
          <span style="font-family:'Share Tech Mono',monospace;font-size:9px;padding:2px 7px;border-radius:4px;background:rgba(247,147,26,.12);color:#F7931A;border:1px solid rgba(247,147,26,.2)">+${m.sats} Sats</span>
          ${m.time ? `<span style="font-family:'Share Tech Mono',monospace;font-size:9px;padding:2px 7px;border-radius:4px;background:rgba(0,200,255,.08);color:#00C8FF;border:1px solid rgba(0,200,255,.2)">⏱ ${m.time}min</span>` : ''}
        </div>
        <div style="display:flex;gap:8px">
          <button class="mc-btn launch" style="font-family:'Share Tech Mono',monospace;font-size:9px;letter-spacing:.1em;padding:6px 12px;border-radius:6px;background:rgba(0,255,178,.1);border:1px solid rgba(0,255,178,.25);color:#00FFB2;cursor:pointer" onclick="Missions.complete(${i})">✓ COMPLETAR</button>
          ${m.target ? `<button class="mc-btn dismiss" style="font-family:'Share Tech Mono',monospace;font-size:9px;padding:6px 12px;border-radius:6px;background:transparent;border:1px solid rgba(255,255,255,.1);color:rgba(255,255,255,.3);cursor:pointer" onclick="Missions.navigate(${i})">🗺️ NAVEGAR</button>` : ''}
        </div>
      </div>`).join('');
  }

  function complete(i) {
    const m = active[i];
    if (!m) return;
    active.splice(i, 1);
    Economy.earn(m.xp, 'xp');
    Economy.earn(m.sats, 'sats');
    _save(); _renderPanel();
    if (typeof toast !== 'undefined') toast(`🏆 +${m.xp}XP +${m.sats}Sats`, 'xp');

    // Respawn com nova missão
    const available = POOL.filter(p => !active.find(a => a.id === p.id));
    if (available.length) {
      setTimeout(() => {
        active.push({ ...available[Math.floor(Math.random() * available.length)] });
        _save(); _renderPanel();
      }, 3000);
    }
  }

  function navigate(i) {
    const m = active[i];
    if (!m?.target) return;
    // Mover câmera / player para perto do target (simula waypoint)
    if (typeof toast !== 'undefined') toast(`🗺️ Navegando para ${m.name}`, 'ok');
    UI.closePanel('mission-panel');
  }

  return { load, showPanel, complete, navigate };
})();
