/**
 * sw.js — Service Worker / PWA Cache
 * Labriolag OS · labriolag.shop
 *
 * Estratégia: Cache-first para assets estáticos,
 * Network-first para chamadas de API.
 */

const CACHE_NAME  = 'labos-v6';
const CACHE_SHELL = 'labos-shell-v6';

const SHELL_ASSETS = [
  '/',
  '/index.html',
  '/game.html',
  '/labx.html',
  '/shop.html',
  '/avatar.html',
  '/admin.html',
  '/css/style.css',
  '/css/game.css',
  '/js/auth.js',
  '/js/api.js',
  '/js/engine.js',
  '/js/joystick.js',
  '/js/collision.js',
  '/js/economy.js',
  '/js/missions.js',
  '/js/events.js',
  '/js/npc.js',
  '/js/gps.js',
  '/js/multiplayer.js',
  '/manifest.json',
];

// ── Install: pré-cacheia o shell ─────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_SHELL).then(cache => cache.addAll(SHELL_ASSETS))
  );
  self.skipWaiting();
});

// ── Activate: limpa caches antigos ───────────────────
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys
          .filter(k => k !== CACHE_SHELL && k !== CACHE_NAME)
          .map(k => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

// ── Fetch: estratégia por tipo de request ────────────
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // API requests → Network-first, sem cache
  if (url.hostname.includes('workers.dev') ||
      url.pathname.startsWith('/calcular') ||
      url.pathname.startsWith('/me') ||
      url.pathname.startsWith('/ibge') ||
      url.pathname.startsWith('/admin')) {
    event.respondWith(fetch(event.request).catch(() => new Response(
      JSON.stringify({ error: 'offline' }), { headers: { 'Content-Type': 'application/json' } }
    )));
    return;
  }

  // APIs externas (BCB, IBGE) → Network-first
  if (url.hostname.includes('bcb.gov.br') ||
      url.hostname.includes('ibge.gov.br') ||
      url.hostname.includes('fonts.googleapis.com')) {
    event.respondWith(
      fetch(event.request)
        .then(r => {
          const clone = r.clone();
          caches.open(CACHE_NAME).then(c => c.put(event.request, clone));
          return r;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // Shell assets → Cache-first
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(r => {
        if (r.ok) {
          const clone = r.clone();
          caches.open(CACHE_SHELL).then(c => c.put(event.request, clone));
        }
        return r;
      });
    })
  );
});
