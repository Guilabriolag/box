# labproxy-labsocial

**Labriolag OS — Hub Econômico Gamificado**
`labriolag.shop` · Cloudflare Pages + Workers · v6.0

---

## 🏗️ Estrutura do Projeto

```
labproxy-labsocial/
│
├── index.html          ← Portal de entrada (auth gate + menu)
├── game.html           ← Mundo aberto (canvas 2D + joystick)
├── labx.html           ← Motor LAB-X 16D + Rating MSCL
├── shop.html           ← Marketplace (distritos, itens, créditos)
├── avatar.html         ← Customização de perfil
├── admin.html          ← Painel admin (gestão de API Keys)
│
├── css/
│   ├── style.css       ← Design system global (tokens, componentes)
│   └── game.css        ← Estilos exclusivos do modo jogo
│
├── js/
│   ├── auth.js         ← Autenticação via API Key (localStorage)
│   ├── api.js          ← Cliente HTTP para o Worker v6
│   ├── engine.js       ← Game loop, player, câmera, minimap
│   ├── joystick.js     ← Controle touch + teclado WASD
│   ├── collision.js    ← AABB + circle collision
│   ├── economy.js      ← LAB Token / Sats / XP
│   ├── missions.js     ← Sistema de missões
│   ├── events.js       ← Eventos dinâmicos do mundo
│   ├── npc.js          ← NPCs com movimento autônomo
│   ├── gps.js          ← GPS real → posição no mapa virtual
│   └── multiplayer.js  ← WebSocket stub (Cloudflare DO / Partykit)
│
├── assets/
│   ├── avatars/        ← Sprites de avatar (PNG/SVG)
│   ├── icons/          ← favicon.svg, icon-192.png, icon-512.png
│   └── map/            ← Tiles de mapa (futuro)
│
├── api/                ← (opcional) scripts auxiliares
│   └── labx-worker-v6.js ← Cloudflare Worker (deploy separado)
│
├── manifest.json       ← PWA manifest
├── sw.js               ← Service Worker (cache offline)
├── _headers            ← Cloudflare Pages security headers
├── _redirects          ← Cloudflare Pages redirects
├── wrangler.toml       ← Config do Worker
└── .gitignore
```

---

## 🚀 Deploy em 5 Passos

### 1. Instalar Wrangler

```bash
npm install -g wrangler
wrangler login
```

### 2. Criar KV Namespace

```bash
wrangler kv:namespace create "LABX_KV"
# Copie o id gerado e cole no wrangler.toml
```

### 3. Configurar Secrets

```bash
# Gera um secret forte
openssl rand -hex 32

# Salva no Cloudflare (criptografado, não aparece em logs)
wrangler secret put LABX_ADMIN_SECRET
```

### 4. Deploy do Worker

```bash
# Coloque o worker em /api/
wrangler deploy api/labx-worker-v6.js
# Output: https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev
```

### 5. Atualizar URL do Worker no Frontend

Em `js/api.js`, linha 8:
```js
const BASE = 'https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev';
```

Em `js/multiplayer.js`, linha 10:
```js
const WS_URL = 'wss://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/ws';
```

---

## 🌐 Deploy do Frontend (Cloudflare Pages)

### Via GitHub

1. Crie o repo: `labproxy-labsocial`
2. Push dos arquivos
3. Cloudflare Dashboard → Pages → Connect to Git
4. Build: **None** (static site)
5. Output directory: `/` (raiz)

### Domínio Customizado

No Cloudflare DNS:
```
Type:   CNAME
Name:   @
Target: labproxy-labsocial.pages.dev
Proxy:  ✅ (laranja — CDN + proteção ativa)
```

Resultado:
- `https://labriolag.shop` → Portal
- `https://labriolag.shop/game.html` → Mundo
- `https://labriolag.shop/labx.html` → Motor LAB-X

---

## 🔑 Criar Primeira API Key

```bash
curl -X POST https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/admin/keys \
  -H "X-Admin-Secret: SEU_SECRET" \
  -H "Content-Type: application/json" \
  -d '{ "owner": "Admin", "tier": "enterprise", "credits": 1000 }'
```

Resposta:
```json
{
  "ok": true,
  "key": "sk_lab_abc123...",
  "profile": { "owner": "Admin", "tier": "enterprise", "credits": 1000 }
}
```

Cole essa chave no campo de entrada do portal para acessar o sistema.

---

## 📱 PWA — Instalar como App

O `manifest.json` e `sw.js` já estão configurados.

Para ativar o Service Worker, adicione no `index.html` antes do `</body>`:

```html
<script>
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js');
}
</script>
```

---

## 🔐 Segurança — Checklist

- [x] API Key nunca exposta no código
- [x] Admin secret via `wrangler secret` (criptografado)
- [x] Rate limiting: 30 req/min por chave
- [x] CORS restrito ao domínio `labriolag.shop`
- [x] CSP configurado no `_headers`
- [x] `.gitignore` protege arquivos sensíveis
- [ ] Configurar `ALLOWED_ORIGIN` no Dashboard do Cloudflare
- [ ] Ativar Cloudflare WAF
- [ ] Configurar alertas de uso no Cloudflare Analytics

---

## 🗺️ Roadmap

| Feature                        | Status     |
|-------------------------------|------------|
| Portal + Auth Gate            | ✅ Pronto  |
| Mundo Aberto (Canvas 2D)      | ✅ Pronto  |
| Motor LAB-X 16D + MSCL        | ✅ Pronto  |
| Marketplace                   | ✅ Pronto  |
| Avatar Editor                 | ✅ Pronto  |
| Admin Panel                   | ✅ Pronto  |
| GPS Real → Mapa Virtual       | ✅ Pronto  |
| PWA Instalável                | ✅ Pronto  |
| Multiplayer WebSocket         | 🔧 Stub   |
| Banco de dados de progresso   | 🔧 Planej |
| Sprites & Tilemap             | 🔧 Planej |
| Modo offline completo         | 🔧 Planej |

---

**LABRIOLAG Holding · labriolag.shop**
