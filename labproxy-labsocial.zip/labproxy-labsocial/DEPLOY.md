# LAB-X v6 — Guia de Deploy e Uso
## labriolag.shop · LABRIOLAG Holding

---

## 1. PRÉ-REQUISITOS

```bash
npm install -g wrangler
wrangler login
```

---

## 2. CRIAR O KV NAMESPACE

```bash
# Produção
wrangler kv:namespace create "LABX_KV"
# Vai retornar algo como: id = "abc123..."
# Cole esse id no wrangler.toml
```

---

## 3. CONFIGURAR SEGREDOS (NÃO use o wrangler.toml para isso)

```bash
# Gerar um secret forte
openssl rand -hex 32

# Salvar como variável secreta no Cloudflare (não aparece em logs)
wrangler secret put LABX_ADMIN_SECRET
# Cole o valor gerado acima quando solicitado
```

---

## 4. DEPLOY

```bash
wrangler deploy
# Output: https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev
```

---

## 5. CRIAR A PRIMEIRA API KEY (via admin)

```bash
curl -X POST https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/admin/keys \
  -H "X-Admin-Secret: SEU_ADMIN_SECRET" \
  -H "Content-Type: application/json" \
  -d '{
    "owner": "Labriolag Interno",
    "tier": "enterprise",
    "credits": 1000
  }'

# Resposta:
# {
#   "ok": true,
#   "key": "sk_lab_abc123xyz...",
#   "profile": { "owner": "...", "tier": "enterprise", "credits": 1000 }
# }
```

---

## 6. USAR A API

### Verificar saldo
```bash
curl https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/me \
  -H "X-API-Key: sk_lab_SUA_CHAVE"
```

### Rodar análise (consome 1 crédito)
```bash
curl -X POST https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/calcular \
  -H "X-API-Key: sk_lab_SUA_CHAVE" \
  -H "Content-Type: application/json" \
  -d '{
    "renda": 3200,
    "cnpjs": 95,
    "populacao": 180000,
    "pib": 42,
    "modo": 1.0,
    "codMunicipio": "3539400"
  }'
```

### Feed macroeconômico (público, sem chave)
```bash
curl https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/feed
```

---

## 7. GESTÃO DE CHAVES

### Adicionar créditos a uma chave
```bash
curl -X PATCH https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/admin/keys/sk_lab_ABC \
  -H "X-Admin-Secret: SEU_ADMIN_SECRET" \
  -H "Content-Type: application/json" \
  -d '{ "credits": 50 }'
```

### Revogar chave
```bash
curl -X DELETE https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/admin/keys/sk_lab_ABC \
  -H "X-Admin-Secret: SEU_ADMIN_Secret"
```

### Ver estatísticas de uso
```bash
curl https://labx-worker-v6.SEU-SUBDOMINIO.workers.dev/admin/stats \
  -H "X-Admin-Secret: SEU_ADMIN_SECRET"
```

---

## 8. TIERS SUGERIDOS (defina conforme seu modelo de negócio)

| Tier       | Créditos iniciais | Uso sugerido                        |
|------------|:-----------------:|-------------------------------------|
| starter    | 5                 | Teste / avaliação                   |
| basic      | 20                | Consultor autônomo                  |
| pro        | 100               | Pequena empresa / lojista ativo     |
| enterprise | ilimitado*        | Parceiros da Holding / white-label  |

*Para enterprise, ajuste a verificação de créditos no código para tier = 'enterprise'

---

## 9. CONECTAR AO FRONTEND (labx-v5.html)

No frontend, substitua:
```js
const TOKEN = 'labx2026'; // REMOVER
```

Por:
```js
const API_KEY = localStorage.getItem('labx_api_key') || '';
// e nas chamadas:
headers: { 'X-API-Key': API_KEY }
```

Adicione uma tela de "Enter sua API Key" no primeiro acesso.

---

## 10. SEGURANÇA — CHECKLIST

- [x] Token admin nunca no código-fonte
- [x] API Keys com créditos — sem crédito, sem acesso
- [x] Rate limiting: 30 req/min por chave
- [x] Análises isoladas por chave (namespace no KV)
- [x] CORS restrito ao domínio labriolag.shop
- [ ] Configurar ALLOWED_ORIGIN no Dashboard (não deixar '*')
- [ ] Ativar Cloudflare WAF no domínio labriolag.shop
- [ ] Configurar alertas de uso no Cloudflare Analytics
